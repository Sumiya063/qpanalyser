# VIVA Preparation & Comprehensive Question Bank
**Course:** CSE203 Object-Oriented Programming using Java  
**Project:** AI Question Paper Difficulty Analyzer

This guide equips every student on the team to explain and defend every major architectural layer, design pattern, and algorithm during the project viva examination.

---

## 1. Object-Oriented Programming & Architecture

### Q1: Why did you make `Question` an abstract class instead of an interface or concrete class?
**Answer:** `Question` contains shared common state (such as `id`, `questionNumber`, `questionText`, `marks`, `section`, `bloomLevel`, `difficultyScore`) along with concrete getter/setter logic that all questions inherit. An abstract class allows us to share this code while forcing subclasses (`McqQuestion`, `ProblemQuestion`, etc.) to provide polymorphic implementations of `getQuestionType()` and `estimateAnsweringTimeMinutes()`.

### Q2: Where is the Strategy Pattern utilized in this application?
**Answer:** We use the Strategy Pattern in multiple components to adhere to the Open-Closed Principle:
1. **Document Parsing:** The [`DocumentParser`](file:///c:/Projects/qp-analyser/src/main/java/com/qpanalyser/service/parser/DocumentParser.java) interface has distinct strategies: `PlainTextParser`, `PdfDocumentParser`, and `DocxDocumentParser`.
2. **Bloom Classification:** The [`BloomClassifier`](file:///c:/Projects/qp-analyser/src/main/java/com/qpanalyser/analyzer/BloomClassifier.java) interface is implemented by `TrieBloomClassifier` and `KeywordBloomClassifier`.
3. **Difficulty Scoring:** The [`DifficultyScorer`](file:///c:/Projects/qp-analyser/src/main/java/com/qpanalyser/analyzer/DifficultyScorer.java) interface is implemented by `WeightedDifficultyScorer` and `LinearDifficultyScorer`.
4. **Report Exporting:** The [`ReportExporter`](file:///c:/Projects/qp-analyser/src/main/java/com/qpanalyser/report/ReportExporter.java) interface provides CSV, Text, and PDF export strategies.

### Q3: How did you implement thread safety in the Database Connection Manager?
**Answer:** In [`DatabaseConnection.java`](file:///c:/Projects/qp-analyser/src/main/java/com/qpanalyser/db/DatabaseConnection.java), we applied the **Singleton Pattern with Double-Checked Locking**. The `instance` variable is marked `volatile` to prevent CPU instruction reordering. The first null check avoids synchronization overhead once initialized, while the synchronized block ensures that only one thread can instantiate the singleton.

---

## 2. Data Structures & Custom Algorithms

### Q4: Why did you implement a custom `BloomTrie` instead of using a standard `HashMap`?
**Answer:** A standard `HashMap` requires knowing the exact words or extracting every possible $N$-gram in advance. A prefix Trie allows us to perform fast, streaming prefix lookups in $O(M)$ time (where $M$ is the length of the verb) regardless of how many verbs are stored. Furthermore, our `BloomTrie` handles multi-word phrases and case-insensitive matching while resolving ties to the highest cognitive level.

### Q5: How does the hand-written `UndoStack` work, and why not use `java.util.Stack`?
**Answer:** `java.util.Stack` is a legacy Java 1.0 class extending `Vector` with synchronized overhead on every call. Our [`UndoStack<T>`](file:///c:/Projects/qp-analyser/src/main/java/com/qpanalyser/dsa/UndoStack.java) is a custom generic singly-linked list node structure. Pushing, popping, and peeking operate in strict $O(1)$ constant time. We also implemented capacity limiting using a tail pointer to drop oldest operations if the stack exceeds 50 steps, avoiding memory leaks.

### Q6: What is the Big-O time and space complexity of your Merge Sort?
**Answer:** 
- **Time Complexity:** $O(N \log N)$ in all cases (best, average, and worst). It recursively divides the array of questions into halves ($O(\log N)$ levels) and merges them in linear $O(N)$ time.
- **Space Complexity:** $O(N)$ auxiliary space because merging requires temporary sub-arrays to store elements before copying back into the target list.

### Q7: How does near-duplicate question detection work?
**Answer:** [`DuplicateDetector.java`](file:///c:/Projects/qp-analyser/src/main/java/com/qpanalyser/dsa/DuplicateDetector.java) uses **Dynamic Programming (Levenshtein Distance)**. It computes the minimum number of single-character edits (insertions, deletions, substitutions) required to transform one question string into another in $O(M \times N)$ time and space. We then normalize the score:
$$\text{Similarity} = 1.0 - \frac{\text{Distance}}{\max(\text{Length}_A, \text{Length}_B)}$$
If similarity exceeds 0.75, the pair is flagged as a duplicate.

---

## 3. Database & System Integration

### Q8: How does the application prevent SQL Injection?
**Answer:** We strictly use `PreparedStatement` across all DAO classes (`UserDAO`, `PaperDAO`, `QuestionDAO`, `BloomVerbDAO`, `SettingsDAO`) with parameterized placeholders (`?`). No SQL statements are constructed using string concatenation.

### Q9: How do you prevent the JavaFX UI from freezing when parsing large PDF files or running AI analysis?
**Answer:** We run long-running I/O and processing tasks on background threads using `javafx.concurrent.Task<T>`. When the task completes, JavaFX automatically executes `setOnSucceeded()` on the JavaFX Application Thread to update the UI components safely.

### Q10: How are user passwords secured?
**Answer:** In [`PasswordUtil.java`](file:///c:/Projects/qp-analyser/src/main/java/com/qpanalyser/util/PasswordUtil.java), passwords are not stored in plaintext. We generate a 16-byte cryptographically secure random salt (`SecureRandom`) and hash the combined salt and password using **SHA-256**. For validation, we use constant-time byte comparison (`MessageDigest.isEqual`) to protect against timing attacks.
