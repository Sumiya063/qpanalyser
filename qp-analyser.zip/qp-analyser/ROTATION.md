# Team Roles & Rotation Matrix

**Course:** CSE203 - Object-Oriented Programming using Java  
**Project:** AI Question Paper Difficulty Analyzer  
**Team Structure:** 4 Members  

---

## 1. Primary Role Definitions

| Role | Core Responsibilities | Typical Packages / Artifacts |
| :--- | :--- | :--- |
| **Member 1: Team Coordinator** | Project scaffolding, Maven `pom.xml`, application lifecycle launcher, application configuration, utility classes, report/export management, Git workflows, integration test runner. | `com.qpanalyser.app`, `com.qpanalyser.util`, `com.qpanalyser.report`, `README.md`, `pom.xml` |
| **Member 2: JavaFX Lead** | User interface design, FXML views, CSS design systems, UI event handling, controller binding, UI responsiveness, chart visualizations. | `com.qpanalyser.ui.controller`, `com.qpanalyser.ui.view`, `style.css` |
| **Member 3: Core Java & OOP Lead** | Domain model hierarchy (inheritance, polymorphism, abstraction), business service layer, NLP rule engine interfaces & implementations, custom exceptions. | `com.qpanalyser.model`, `com.qpanalyser.service`, `com.qpanalyser.analyzer`, `com.qpanalyser.exception` |
| **Member 4: DSA & Database Lead** | Custom hand-written data structures (Trie, Stack, Sorting, DP), database design, SQL DDL/DML, JDBC connection pooling, DAO implementation with Generics. | `com.qpanalyser.dsa`, `com.qpanalyser.db`, `com.qpanalyser.dao`, `schema.sql` |

---

## 2. Phase-by-Phase Rotation Matrix

To ensure every student writes backend, frontend, database, and algorithmic code—and can confidently defend any component during the viva—responsibilities rotate across project milestones:

| Phase | Milestone | Team Coordinator | JavaFX Lead | Core Java & OOP Lead | DSA & Database Lead |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Phase 1** | **Skeleton, DB, Login** | Student 1 (`AppConfig`, `PasswordUtil`, `MainApp`) | Student 2 (`login.fxml`, `style.css`, `LoginController`) | Student 3 (`User`, `Role`, `AuthService`, Custom Exceptions) | Student 4 (`schema.sql`, `DatabaseConnection`, `DatabaseInitializer`, `Repository<T>`, `UserDAO`) |
| **Phase 2** | **OOP Models & File Loaders** | Student 4 (File size/type validation, Background JavaFX `Task` orchestration) | Student 1 (Upload dashboard wireframe, file picker dialog, progress indicators) | Student 2 (`Question` abstract class, `McqQuestion`, `ShortAnswerQuestion`, `LongAnswerQuestion`, `ProblemQuestion`, `Paper`) | Student 3 (Text reader, Apache PDFBox extractor, Apache POI DOCX extractor) |
| **Phase 3** | **Extraction & Review with Undo** | Student 3 (Extraction regex rules, numbering patterns, marks parsing) | Student 4 (Review screen TableView, editing cells, merge/split UI actions) | Student 1 (`QuestionExtractor` interface, Question factory pattern, split/merge service) | Student 2 (Hand-written `UndoStack`, Command pattern for question editing history) |
| **Phase 4** | **Analysis Engine (Bloom & Difficulty)** | Student 2 (Bloom weights config, technical-term density calculator) | Student 3 (Results preview cards, real-time score indicators) | Student 4 (`BloomClassifier`, `DifficultyScorer` strategy pattern, rule engine) | Student 1 (Hand-written `Trie` for verb lookup, `MergeSort` for difficulty ranking, `LevenshteinDistance` for duplicates) |
| **Phase 5** | **Results Screen & Visuals** | Student 1 (Balance verdict evaluator, rule-based suggestion generator) | Student 2 (JavaFX `PieChart` for Bloom, `BarChart` for Difficulty, color-coded grid) | Student 3 (`PaperReport` aggregation model, metrics calculator) | Student 4 (`AnalysisResultDAO`, batch persistence for questions and results) |
| **Phase 6** | **Paper Compare & Settings** | Student 4 (Settings persistence DAO, dynamic weight re-computation) | Student 1 (Comparison side-by-side view, Settings modal dialog) | Student 2 (`PaperComparisonService`, delta metrics calculation) | Student 3 (`ReportExporter` strategy, CSV exporter, formatted Text/PDF report exporter) |
| **Phase 7** | **Testing, Documentation & Viva Prep** | Student 3 (Git release tags, GitHub issues checklist, final test suite runner) | Student 4 (UI interaction tests, visual walkthrough screenshots in docs) | Student 1 (JUnit 5 test cases for classifiers, scorers, and models) | Student 2 (JUnit 5 test cases for custom DSA, `VIVA.md`, `EVALUATION.md`) |

---

## 3. Viva Defense Guarantee

By adhering to this rotation schedule, each team member directly authors:
1. At least one JavaFX Controller and FXML/CSS styling module.
2. At least one Core OOP class hierarchy with polymorphism.
3. At least one custom Data Structure or Algorithm written from scratch.
4. At least one JDBC DAO operation with parameterized queries and transactional integrity.
