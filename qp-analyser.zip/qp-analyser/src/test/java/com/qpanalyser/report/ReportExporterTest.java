// File: src/test/java/com/qpanalyser/report/ReportExporterTest.java
package com.qpanalyser.report;

import com.qpanalyser.model.AnalysisResult;
import com.qpanalyser.model.Paper;
import com.qpanalyser.model.Question;
import com.qpanalyser.model.QuestionFactory;
import com.qpanalyser.model.QuestionType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit Tests for Strategy Pattern: Report Exporters (CSV, Text, PDF)
 * Author: Team Coordinator
 */
public class ReportExporterTest {

    private Paper samplePaper;
    private AnalysisResult sampleResult;

    @BeforeEach
    void setUp() {
        samplePaper = new Paper("CSE203 Mid-Term", "CSE203", "2025-2026", "IV", 50.0, 1);
        List<Question> questions = new ArrayList<>();
        questions.add(QuestionFactory.createQuestion(QuestionType.SHORT_ANSWER, "Q1", "Define encapsulation and abstraction.", 5.0, "A"));
        questions.add(QuestionFactory.createQuestion(QuestionType.PROBLEM, "Q2", "Write a Java program demonstrating polymorphism.", 10.0, "B"));
        samplePaper.setQuestions(questions);

        sampleResult = new AnalysisResult(1, 45.0, 30.0, 50.0, 20.0, "Balanced Examination Paper", "Looks good.");
        sampleResult.setRememberCount(1);
        sampleResult.setApplyCount(1);
    }

    @Test
    @DisplayName("Strategy: CsvReportExporter creates valid non-empty CSV file")
    void testCsvReportExporter(@TempDir Path tempDir) throws IOException {
        File file = tempDir.resolve("report.csv").toFile();
        ReportExporter exporter = new CsvReportExporter();

        exporter.export(samplePaper, sampleResult, file);

        assertTrue(file.exists());
        assertTrue(file.length() > 0);
        String content = Files.readString(file.toPath());
        assertTrue(content.contains("Question No,Question Text,Type,Marks"));
        assertTrue(content.contains("Define encapsulation"));
    }

    @Test
    @DisplayName("Strategy: TextReportExporter creates formatted text summary")
    void testTextReportExporter(@TempDir Path tempDir) throws IOException {
        File file = tempDir.resolve("report.txt").toFile();
        ReportExporter exporter = new TextReportExporter();

        exporter.export(samplePaper, sampleResult, file);

        assertTrue(file.exists());
        assertTrue(file.length() > 0);
        String content = Files.readString(file.toPath());
        assertTrue(content.contains("AI QUESTION PAPER DIFFICULTY ANALYZER REPORT"));
        assertTrue(content.contains("Balanced Examination Paper"));
    }

    @Test
    @DisplayName("Strategy: PdfReportExporter generates valid PDF document via PDFBox")
    void testPdfReportExporter(@TempDir Path tempDir) throws IOException {
        File file = tempDir.resolve("report.pdf").toFile();
        ReportExporter exporter = new PdfReportExporter();

        exporter.export(samplePaper, sampleResult, file);

        assertTrue(file.exists());
        assertTrue(file.length() > 0);
        // Verify PDF Magic Bytes "%PDF-"
        byte[] bytes = Files.readAllBytes(file.toPath());
        assertTrue(bytes.length >= 4);
        assertEquals('%', (char) bytes[0]);
        assertEquals('P', (char) bytes[1]);
        assertEquals('D', (char) bytes[2]);
        assertEquals('F', (char) bytes[3]);
    }
}
