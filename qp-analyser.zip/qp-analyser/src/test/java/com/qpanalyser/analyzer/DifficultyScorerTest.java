// File: src/test/java/com/qpanalyser/analyzer/DifficultyScorerTest.java
package com.qpanalyser.analyzer;

import com.qpanalyser.model.BloomLevel;
import com.qpanalyser.model.DifficultyLevel;
import com.qpanalyser.model.Question;
import com.qpanalyser.model.QuestionFactory;
import com.qpanalyser.model.QuestionType;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit Tests for Difficulty Scorer (Strategy Pattern)
 * Author: Core Java & OOP Lead
 */
public class DifficultyScorerTest {

    private final WeightedDifficultyScorer scorer = new WeightedDifficultyScorer();
    private final FeatureExtractor featureExtractor = new FeatureExtractor();

    @Test
    @DisplayName("DifficultyScorer calculates multi-factor score and classifies Easy/Medium/Hard")
    void testDifficultyCalculation() {
        // Easy Question: Level 1 (Remember), 2 marks, 5 words, 0 subparts, low tech density
        Question easyQ = QuestionFactory.createQuestion(QuestionType.MCQ, "Q1", "Define class in Java.", 2.0, "A");
        easyQ.setBloomLevel(BloomLevel.REMEMBER);
        FeatureExtractor.QuestionFeatures easyFeat = featureExtractor.extractFeatures(easyQ.getQuestionText(), easyQ.getMarks(), 1);

        double easyScore = scorer.calculateDifficultyScore(easyQ, easyFeat);
        assertTrue(easyScore < 35.0, "Score should be < 35 for simple recall question, was: " + easyScore);
        assertEquals(DifficultyLevel.EASY, scorer.determineDifficultyLevel(easyScore));

        // Hard Question: Level 6 (Create), 15 marks, long text, 3 subparts, high technical density
        Question hardQ = QuestionFactory.createQuestion(QuestionType.PROBLEM, "Q2",
                "Design and implement a thread-safe distributed cache with generic memory allocation, " +
                "synchronization mutex locks, and custom eviction algorithms. Analyze time complexity. int x = 0;",
                15.0, "B");
        hardQ.setBloomLevel(BloomLevel.CREATE);
        hardQ.setSubPartCount(3);
        FeatureExtractor.QuestionFeatures hardFeat = featureExtractor.extractFeatures(hardQ.getQuestionText(), hardQ.getMarks(), 3);

        double hardScore = scorer.calculateDifficultyScore(hardQ, hardFeat);
        assertTrue(hardScore > 65.0, "Score should be > 65 for advanced synthesis question, was: " + hardScore);
        assertEquals(DifficultyLevel.HARD, scorer.determineDifficultyLevel(hardScore));
    }
}
