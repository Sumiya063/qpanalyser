// File: src/test/java/com/qpanalyser/analyzer/BloomClassifierTest.java
package com.qpanalyser.analyzer;

import com.qpanalyser.model.BloomLevel;
import com.qpanalyser.model.Question;
import com.qpanalyser.model.QuestionFactory;
import com.qpanalyser.model.QuestionType;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit Tests for Bloom Classifier (Strategy Pattern)
 * Author: Core Java & OOP Lead
 */
public class BloomClassifierTest {

    private final BloomClassifier trieClassifier = new TrieBloomClassifier();
    private final BloomClassifier keywordClassifier = new KeywordBloomClassifier();

    @Test
    @DisplayName("Bloom Classifier detects all 6 cognitive levels across action verbs")
    void testBloomLevelsClassification() {
        Question q1 = QuestionFactory.createQuestion(QuestionType.SHORT_ANSWER, "Q1", "Define polymorphism and encapsulation.", 5.0, "A");
        Question q2 = QuestionFactory.createQuestion(QuestionType.SHORT_ANSWER, "Q2", "Explain the working of Java garbage collection.", 5.0, "A");
        Question q3 = QuestionFactory.createQuestion(QuestionType.PROBLEM, "Q3", "Calculate the time complexity of bubble sort and solve recurrence relation.", 8.0, "B");
        Question q4 = QuestionFactory.createQuestion(QuestionType.SHORT_ANSWER, "Q4", "Compare and differentiate between ArrayList and LinkedList.", 6.0, "B");
        Question q5 = QuestionFactory.createQuestion(QuestionType.LONG_ANSWER, "Q5", "Evaluate and justify why immutability is preferred in multithreaded systems.", 10.0, "C");
        Question q6 = QuestionFactory.createQuestion(QuestionType.LONG_ANSWER, "Q6", "Design and create an e-commerce order processing microservice.", 15.0, "C");

        assertEquals(BloomLevel.REMEMBER, trieClassifier.classify(q1));
        assertEquals(BloomLevel.UNDERSTAND, trieClassifier.classify(q2));
        assertEquals(BloomLevel.APPLY, trieClassifier.classify(q3));
        assertEquals(BloomLevel.ANALYZE, trieClassifier.classify(q4));
        assertEquals(BloomLevel.EVALUATE, trieClassifier.classify(q5));
        assertEquals(BloomLevel.CREATE, trieClassifier.classify(q6));
    }

    @Test
    @DisplayName("OOP Concept: Strategy Pattern - Alternative KeywordBloomClassifier correctly resolves verbs")
    void testKeywordBloomClassifierStrategy() {
        Question q = QuestionFactory.createQuestion(QuestionType.SHORT_ANSWER, "Q1", "Define an abstract class.", 3.0, "A");
        assertEquals(BloomLevel.REMEMBER, keywordClassifier.classify(q));
        assertEquals("define", keywordClassifier.getIdentifiedVerb(q));
    }
}
