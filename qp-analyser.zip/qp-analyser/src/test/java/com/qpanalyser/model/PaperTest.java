// File: src/test/java/com/qpanalyser/model/PaperTest.java
package com.qpanalyser.model;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit Tests for Paper Model, Collection Management & Streams
 * Author: Core Java & OOP Lead
 */
public class PaperTest {

    @Test
    @DisplayName("OOP Concept: Composition - Adding questions to Paper updates count and list")
    void testPaperQuestionManagement() {
        Paper paper = new Paper("Midterm", "CSE203", "2025-26", "IV", 50.0, 1);
        assertEquals(0, paper.getQuestionCount());

        Question q1 = new ShortAnswerQuestion("Q1", "Explain Java JVM architecture.", 5.0, "A");
        Question q2 = new LongAnswerQuestion("Q2", "Describe garbage collection algorithms.", 10.0, "B");

        paper.addQuestion(q1);
        paper.addQuestion(q2);

        assertEquals(2, paper.getQuestionCount());
        assertTrue(paper.getQuestions().contains(q1));
        assertTrue(paper.getQuestions().contains(q2));

        paper.removeQuestion(q1);
        assertEquals(1, paper.getQuestionCount());
        assertFalse(paper.getQuestions().contains(q1));
    }

    @Test
    @DisplayName("OOP Concept: Lambdas & Streams - calculateActualTotalMarks aggregates marks")
    void testCalculateActualTotalMarks() {
        Paper paper = new Paper();
        paper.addQuestion(new McqQuestion("Q1", "Option A or B?", 2.0, "A"));
        paper.addQuestion(new ShortAnswerQuestion("Q2", "Define encapsulation.", 5.0, "A"));
        paper.addQuestion(new ProblemQuestion("Q3", "Write quicksort.", 15.0, "B"));

        double totalMarks = paper.calculateActualTotalMarks();
        assertEquals(22.0, totalMarks, 0.01, "Stream sum must equal 2 + 5 + 15 = 22");
    }

    @Test
    @DisplayName("OOP Concept: Polymorphism & Streams - calculateEstimatedExamDurationMinutes calls subclass heuristics")
    void testCalculateEstimatedExamDurationMinutes() {
        Paper paper = new Paper();
        // Mcq: 2 marks * 1.5 = 3 mins
        paper.addQuestion(new McqQuestion("Q1", "Option?", 2.0, "A"));
        // ShortAnswer: 5 marks * 2.0 = 10 mins
        paper.addQuestion(new ShortAnswerQuestion("Q2", "Short?", 5.0, "A"));

        double duration = paper.calculateEstimatedExamDurationMinutes();
        assertEquals(13.0, duration, 0.01, "Total estimated duration must be 3 + 10 = 13 minutes");
    }
}
