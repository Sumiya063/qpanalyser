// File: src/test/java/com/qpanalyser/model/QuestionHierarchyTest.java
package com.qpanalyser.model;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit Tests for OOP Question Class Hierarchy & Polymorphism
 * Author: Core Java & OOP Lead
 */
public class QuestionHierarchyTest {

    @Test
    @DisplayName("OOP Concept: Inheritance - Subclasses correctly extend Question base class")
    void testInheritanceHierarchy() {
        Question mcq = new McqQuestion();
        Question shortAns = new ShortAnswerQuestion();
        Question longAns = new LongAnswerQuestion();
        Question problem = new ProblemQuestion();

        assertTrue(mcq instanceof Question, "McqQuestion must inherit from Question");
        assertTrue(shortAns instanceof Question, "ShortAnswerQuestion must inherit from Question");
        assertTrue(longAns instanceof Question, "LongAnswerQuestion must inherit from Question");
        assertTrue(problem instanceof Question, "ProblemQuestion must inherit from Question");
    }

    @Test
    @DisplayName("OOP Concept: Polymorphism & Method Overriding - Subclasses return distinct QuestionType")
    void testPolymorphicQuestionType() {
        Question mcq = QuestionFactory.createQuestion(QuestionType.MCQ);
        Question shortAns = QuestionFactory.createQuestion(QuestionType.SHORT_ANSWER);
        Question longAns = QuestionFactory.createQuestion(QuestionType.LONG_ANSWER);
        Question problem = QuestionFactory.createQuestion(QuestionType.PROBLEM);

        assertEquals(QuestionType.MCQ, mcq.getQuestionType());
        assertEquals(QuestionType.SHORT_ANSWER, shortAns.getQuestionType());
        assertEquals(QuestionType.LONG_ANSWER, longAns.getQuestionType());
        assertEquals(QuestionType.PROBLEM, problem.getQuestionType());
    }

    @Test
    @DisplayName("OOP Concept: Polymorphism - calculateEstimatedAnsweringTimeMinutes computes specific timing heuristics")
    void testPolymorphicTimeEstimation() {
        // MCQ with 2 marks = max(1.0, 2 * 1.5) = 3.0 mins
        Question mcq = new McqQuestion("Q1", "Which of the following is not a primitive type?", 2.0, "Section A");
        assertEquals(3.0, mcq.calculateEstimatedAnsweringTimeMinutes(), 0.01);

        // Short Answer with 5 marks = max(3.0, 5 * 2.0) = 10.0 mins
        Question shortAns = new ShortAnswerQuestion("Q2", "Explain encapsulation.", 5.0, "Section A");
        assertEquals(10.0, shortAns.calculateEstimatedAnsweringTimeMinutes(), 0.01);

        // Long Answer with 10 marks and 2 sub-parts = max(10.0, 10 * 2.2 + (2-1)*2.0) = 24.0 mins
        LongAnswerQuestion longAns = new LongAnswerQuestion("Q3", "Design an ATM system.", 10.0, "Section B");
        longAns.setSubPartCount(2);
        assertEquals(24.0, longAns.calculateEstimatedAnsweringTimeMinutes(), 0.01);

        // Problem Question with 8 marks + numerical formula = 8 * 2.5 + 3.0 = 23.0 mins
        ProblemQuestion problem = new ProblemQuestion("Q4", "Compute Big-O of Dijkstra.", 8.0, "Section C");
        problem.setHasNumericalFormula(true);
        assertEquals(23.0, problem.calculateEstimatedAnsweringTimeMinutes(), 0.01);
    }

    @Test
    @DisplayName("OOP Concept: Factory Pattern - QuestionFactory creates correct instances")
    void testQuestionFactory() {
        Question q1 = QuestionFactory.createQuestion(QuestionType.MCQ, "1", "Pick one", 1.0, "A");
        assertInstanceOf(McqQuestion.class, q1);
        assertEquals("1", q1.getQuestionNumber());
        assertEquals(1.0, q1.getMarks());

        Question q2 = QuestionFactory.createQuestion(QuestionType.PROBLEM, "5", "Solve equation", 10.0, "B");
        assertInstanceOf(ProblemQuestion.class, q2);
        assertEquals(10.0, q2.getMarks());
    }

    @Test
    @DisplayName("Question word count helper calculates whitespace tokens")
    void testWordCount() {
        Question q = new ShortAnswerQuestion("Q1", "Define inheritance, polymorphism and abstraction in Java.", 5.0, "A");
        assertEquals(7, q.getWordCount());
    }
}
