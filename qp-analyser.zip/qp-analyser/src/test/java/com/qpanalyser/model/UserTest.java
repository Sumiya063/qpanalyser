// File: src/test/java/com/qpanalyser/model/UserTest.java
package com.qpanalyser.model;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit Tests for User domain entity
 * Author: Core Java & OOP Lead
 */
public class UserTest {

    @Test
    @DisplayName("User encapsulation and getters/setters verify correctly")
    void testUserEncapsulation() {
        User user = new User();
        user.setId(10);
        user.setUsername("prof_verma");
        user.setFullName("Prof. Verma");
        user.setEmail("verma@college.edu");
        user.setRole(Role.TEACHER);

        assertEquals(10, user.getId());
        assertEquals("prof_verma", user.getUsername());
        assertEquals("Prof. Verma", user.getFullName());
        assertEquals("verma@college.edu", user.getEmail());
        assertEquals(Role.TEACHER, user.getRole());
        assertFalse(user.isAdmin());

        user.setRole(Role.ADMIN);
        assertTrue(user.isAdmin());
    }

    @Test
    @DisplayName("Role enum string mapping is case-insensitive")
    void testRoleMapping() {
        assertEquals(Role.TEACHER, Role.fromString("TEACHER"));
        assertEquals(Role.TEACHER, Role.fromString("teacher"));
        assertEquals(Role.ADMIN, Role.fromString("ADMIN"));
        assertEquals(Role.ADMIN, Role.fromString("admin"));
        assertEquals(Role.TEACHER, Role.fromString(null));
        assertEquals(Role.TEACHER, Role.fromString("UNKNOWN"));
    }
}
