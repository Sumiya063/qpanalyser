// File: src/test/java/com/qpanalyser/util/PasswordUtilTest.java
package com.qpanalyser.util;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit Tests for PasswordUtil
 * Author: Team Coordinator
 */
public class PasswordUtilTest {

    @Test
    @DisplayName("Salt generation should return 32-character hexadecimal string")
    void testGenerateSaltLength() {
        String salt1 = PasswordUtil.generateSalt();
        String salt2 = PasswordUtil.generateSalt();

        assertNotNull(salt1);
        assertEquals(32, salt1.length());
        assertNotEquals(salt1, salt2, "Two randomly generated salts should be distinct");
    }

    @Test
    @DisplayName("Password hashing should produce 64-char SHA-256 hex string")
    void testHashPassword() {
        String salt = PasswordUtil.generateSalt();
        String rawPassword = "CSE203_SecretPassword!";
        String hash = PasswordUtil.hashPassword(rawPassword, salt);

        assertNotNull(hash);
        assertEquals(64, hash.length(), "SHA-256 output must be exactly 64 hex characters");
    }

    @Test
    @DisplayName("Password verification succeeds for correct password and fails for wrong password")
    void testVerifyPassword() {
        String salt = PasswordUtil.generateSalt();
        String correctPassword = "TeacherPassword2026";
        String wrongPassword = "WrongPassword123";

        String hash = PasswordUtil.hashPassword(correctPassword, salt);

        assertTrue(PasswordUtil.verifyPassword(correctPassword, salt, hash), "Password verification must pass for correct input");
        assertFalse(PasswordUtil.verifyPassword(wrongPassword, salt, hash), "Password verification must fail for incorrect input");
        assertFalse(PasswordUtil.verifyPassword(null, salt, hash), "Null password must return false");
        assertFalse(PasswordUtil.verifyPassword(correctPassword, null, hash), "Null salt must return false");
    }

    @Test
    @DisplayName("Identical passwords with different salts must produce different hashes")
    void testSaltingUniqueness() {
        String salt1 = PasswordUtil.generateSalt();
        String salt2 = PasswordUtil.generateSalt();
        String password = "CommonPassword123";

        String hash1 = PasswordUtil.hashPassword(password, salt1);
        String hash2 = PasswordUtil.hashPassword(password, salt2);

        assertNotEquals(hash1, hash2, "Different salts must produce distinct hashes (rainbow table defense)");
    }
}
