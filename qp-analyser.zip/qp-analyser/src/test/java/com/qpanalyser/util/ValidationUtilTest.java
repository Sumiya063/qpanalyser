// File: src/test/java/com/qpanalyser/util/ValidationUtilTest.java
package com.qpanalyser.util;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit Tests for ValidationUtil
 * Author: Team Coordinator
 */
public class ValidationUtilTest {

    @ParameterizedTest
    @ValueSource(strings = {"user@college.edu", "prof.sharma@domain.in", "faculty_123@sub.cse.org"})
    @DisplayName("Valid email formats should pass")
    void testValidEmails(String email) {
        assertTrue(ValidationUtil.isValidEmail(email));
    }

    @ParameterizedTest
    @ValueSource(strings = {"plainaddress", "missing@domain", "@nodomain.com", "spaces in@email.com", ""})
    @DisplayName("Invalid email formats should fail")
    void testInvalidEmails(String email) {
        assertFalse(ValidationUtil.isValidEmail(email));
    }

    @ParameterizedTest
    @ValueSource(strings = {"teacher", "admin_01", "profSharma", "cse203"})
    @DisplayName("Valid usernames should pass")
    void testValidUsernames(String username) {
        assertTrue(ValidationUtil.isValidUsername(username));
    }

    @ParameterizedTest
    @ValueSource(strings = {"ab", "user name", "user@special!", ""})
    @DisplayName("Invalid usernames should fail")
    void testInvalidUsernames(String username) {
        assertFalse(ValidationUtil.isValidUsername(username));
    }

    @Test
    @DisplayName("Password length check requires at least 6 characters")
    void testPasswordLength() {
        assertTrue(ValidationUtil.isValidPassword("123456"));
        assertTrue(ValidationUtil.isValidPassword("strongPassword2026"));
        assertFalse(ValidationUtil.isValidPassword("12345"));
        assertFalse(ValidationUtil.isValidPassword(""));
        assertFalse(ValidationUtil.isValidPassword(null));
    }
}
