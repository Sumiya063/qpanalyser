// File: src/test/java/com/qpanalyser/ui/DashboardLoadTest.java
package com.qpanalyser.ui;

import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.io.InputStream;
import java.net.URL;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicReference;

import static org.junit.jupiter.api.Assertions.*;

public class DashboardLoadTest {

    @BeforeAll
    static void initJavaFX() throws InterruptedException {
        CountDownLatch latch = new CountDownLatch(1);
        try {
            Platform.startup(latch::countDown);
        } catch (IllegalStateException e) {
            // Already started
            latch.countDown();
        }
        latch.await();
    }

    @Test
    @DisplayName("Verify all application FXML views can be loaded by FXMLLoader")
    void testLoadAllFXMLs() throws Exception {
        String[] views = {
                "/com/qpanalyser/ui/view/login.fxml",
                "/com/qpanalyser/ui/view/dashboard.fxml",
                "/com/qpanalyser/ui/view/review.fxml",
                "/com/qpanalyser/ui/view/results.fxml",
                "/com/qpanalyser/ui/view/settings.fxml",
                "/com/qpanalyser/ui/view/compare.fxml"
        };

        for (String view : views) {
            URL url = getClass().getResource(view);
            assertNotNull(url, view + " not found on classpath");

            AtomicReference<Throwable> errorRef = new AtomicReference<>();
            CountDownLatch latch = new CountDownLatch(1);

            Platform.runLater(() -> {
                try {
                    FXMLLoader loader = new FXMLLoader(url);
                    Parent root = loader.load();
                    assertNotNull(root);
                } catch (Throwable t) {
                    errorRef.set(t);
                    t.printStackTrace();
                } finally {
                    latch.countDown();
                }
            });

            latch.await();
            if (errorRef.get() != null) {
                fail("Failed to load " + view + ": " + errorRef.get().getMessage(), errorRef.get());
            }
        }
    }
}
