// File: src/test/java/com/qpanalyser/dsa/QuestionSortAndSearchTest.java
package com.qpanalyser.dsa;

import com.qpanalyser.model.Question;
import com.qpanalyser.model.QuestionFactory;
import com.qpanalyser.model.QuestionType;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit Tests for Hand-Written Merge Sort & Binary Search
 * Author: DSA & Database Lead
 */
public class QuestionSortAndSearchTest {

    @Test
    @DisplayName("DSA: Merge Sort orders questions by difficulty score in O(N log N) time")
    void testMergeSortAscendingAndDescending() {
        List<Question> questions = new ArrayList<>();

        Question q1 = QuestionFactory.createQuestion(QuestionType.SHORT_ANSWER, "Q1", "Text", 5.0, "A");
        q1.setDifficultyScore(45.0); // Medium

        Question q2 = QuestionFactory.createQuestion(QuestionType.SHORT_ANSWER, "Q2", "Text", 2.0, "A");
        q2.setDifficultyScore(18.0); // Easy

        Question q3 = QuestionFactory.createQuestion(QuestionType.LONG_ANSWER, "Q3", "Text", 15.0, "B");
        q3.setDifficultyScore(88.0); // Hard

        Question q4 = QuestionFactory.createQuestion(QuestionType.PROBLEM, "Q4", "Text", 10.0, "B");
        q4.setDifficultyScore(65.0); // Medium-Hard

        questions.add(q1);
        questions.add(q2);
        questions.add(q3);
        questions.add(q4);

        // Sort Ascending (0 -> 100)
        List<Question> sortedAsc = QuestionSort.mergeSort(questions, true);
        assertEquals(4, sortedAsc.size());
        assertEquals(18.0, sortedAsc.get(0).getDifficultyScore());
        assertEquals(45.0, sortedAsc.get(1).getDifficultyScore());
        assertEquals(65.0, sortedAsc.get(2).getDifficultyScore());
        assertEquals(88.0, sortedAsc.get(3).getDifficultyScore());

        // Sort Descending (100 -> 0)
        List<Question> sortedDesc = QuestionSort.mergeSort(questions, false);
        assertEquals(88.0, sortedDesc.get(0).getDifficultyScore());
        assertEquals(65.0, sortedDesc.get(1).getDifficultyScore());
        assertEquals(45.0, sortedDesc.get(2).getDifficultyScore());
        assertEquals(18.0, sortedDesc.get(3).getDifficultyScore());
    }

    @Test
    @DisplayName("DSA: Binary Search finds score boundary threshold in O(log N) time")
    void testBinarySearchThreshold() {
        List<Question> questions = new ArrayList<>();

        for (double score : new double[]{15.0, 25.0, 34.0, 48.0, 60.0, 72.0, 90.0}) {
            Question q = QuestionFactory.createQuestion(QuestionType.SHORT_ANSWER, "Q", "Text", 5.0, "A");
            q.setDifficultyScore(score);
            questions.add(q);
        }

        // Find boundary index for Hard threshold (>= 65.0) -> should be index 5 (score 72.0)
        int hardBoundaryIndex = QuestionSort.binarySearchThreshold(questions, 65.0);
        assertEquals(5, hardBoundaryIndex);
        assertEquals(72.0, questions.get(hardBoundaryIndex).getDifficultyScore());

        // Find boundary for Medium threshold (>= 35.0) -> should be index 3 (score 48.0)
        int medBoundaryIndex = QuestionSort.binarySearchThreshold(questions, 35.0);
        assertEquals(3, medBoundaryIndex);
        assertEquals(48.0, questions.get(medBoundaryIndex).getDifficultyScore());
    }
}
