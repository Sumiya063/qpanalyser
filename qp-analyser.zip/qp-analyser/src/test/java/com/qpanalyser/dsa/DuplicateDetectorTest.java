// File: src/test/java/com/qpanalyser/dsa/DuplicateDetectorTest.java
package com.qpanalyser.dsa;

import com.qpanalyser.model.Question;
import com.qpanalyser.model.QuestionFactory;
import com.qpanalyser.model.QuestionType;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit Tests for Dynamic Programming: Levenshtein Distance & Jaccard Similarity
 * Author: DSA & Database Lead
 */
public class DuplicateDetectorTest {

    @Test
    @DisplayName("DSA: DP Levenshtein distance computes minimum edit operations")
    void testLevenshteinDistance() {
        assertEquals(0, DuplicateDetector.computeLevenshteinDistance("kitten", "kitten"));
        assertEquals(3, DuplicateDetector.computeLevenshteinDistance("kitten", "sitting"));
        assertEquals(1, DuplicateDetector.computeLevenshteinDistance("Java", "Jav"));
        assertEquals(4, DuplicateDetector.computeLevenshteinDistance("", "test"));
    }

    @Test
    @DisplayName("DSA: Normalized similarity returns 1.0 for identical and near 0.0 for distinct")
    void testNormalizedSimilarity() {
        assertEquals(1.0, DuplicateDetector.computeSimilarity("What is polymorphism in Java?", "What is polymorphism in Java?"));
        assertTrue(DuplicateDetector.computeSimilarity("What is polymorphism in Java?", "What is polymorphism in Java programming?") > 0.70);
        assertTrue(DuplicateDetector.computeSimilarity("Explain quicksort", "Describe binary search algorithm") < 0.40);
    }

    @Test
    @DisplayName("DSA: findNearDuplicates detects high lexical similarity pairs in paper")
    void testFindNearDuplicates() {
        List<Question> questions = new ArrayList<>();

        Question q1 = QuestionFactory.createQuestion(QuestionType.SHORT_ANSWER, "Q1",
                "Explain the four fundamental pillars of object oriented programming.", 5.0, "A");
        Question q2 = QuestionFactory.createQuestion(QuestionType.SHORT_ANSWER, "Q2",
                "Explain the 4 fundamental pillars of Object-Oriented Programming.", 5.0, "A");
        Question q3 = QuestionFactory.createQuestion(QuestionType.PROBLEM, "Q3",
                "Write an implementation of Dijkstra shortest path algorithm.", 10.0, "B");

        questions.add(q1);
        questions.add(q2);
        questions.add(q3);

        List<DuplicateDetector.DuplicatePair> duplicates = DuplicateDetector.findNearDuplicates(questions, 0.75);

        assertEquals(1, duplicates.size(), "Should flag Q1 and Q2 as near duplicates");
        assertEquals("Q1", duplicates.get(0).questionA().getQuestionNumber());
        assertEquals("Q2", duplicates.get(0).questionB().getQuestionNumber());
        assertTrue(duplicates.get(0).similarityPercentage() >= 0.75);
    }
}
