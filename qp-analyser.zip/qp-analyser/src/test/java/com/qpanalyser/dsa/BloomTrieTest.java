// File: src/test/java/com/qpanalyser/dsa/BloomTrieTest.java
package com.qpanalyser.dsa;

import com.qpanalyser.model.BloomLevel;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit Tests for Custom Hand-Written Data Structure: BloomTrie
 * Author: DSA & Database Lead
 */
public class BloomTrieTest {

    @Test
    @DisplayName("DSA: Trie insertion and exact search operate in O(M) time")
    void testTrieInsertionAndSearch() {
        BloomTrie trie = new BloomTrie();
        assertTrue(trie.isEmpty());
        assertEquals(0, trie.getWordCount());

        trie.insert("define", BloomLevel.REMEMBER, 1.0);
        trie.insert("explain", BloomLevel.UNDERSTAND, 2.0);
        trie.insert("calculate", BloomLevel.APPLY, 3.0);
        trie.insert("design", BloomLevel.CREATE, 6.0);

        assertEquals(4, trie.getWordCount());
        assertFalse(trie.isEmpty());

        BloomTrie.VerbMatchResult match = trie.search("explain");
        assertTrue(match.isMatched());
        assertEquals("explain", match.getVerb());
        assertEquals(BloomLevel.UNDERSTAND, match.getBloomLevel());
        assertEquals(2.0, match.getWeight());

        // Case insensitivity
        BloomTrie.VerbMatchResult matchUpper = trie.search("DESIGN");
        assertTrue(matchUpper.isMatched());
        assertEquals(BloomLevel.CREATE, matchUpper.getBloomLevel());

        // Negative search
        BloomTrie.VerbMatchResult missing = trie.search("unregisteredVerb");
        assertFalse(missing.isMatched());
    }

    @Test
    @DisplayName("DSA: findBestVerbInSentence identifies the highest-level cognitive verb")
    void testFindBestVerbInSentence() {
        BloomTrie trie = new BloomTrie();
        trie.insert("explain", BloomLevel.UNDERSTAND, 2.0);
        trie.insert("implement", BloomLevel.APPLY, 3.0);
        trie.insert("design", BloomLevel.CREATE, 6.0);

        // Sentence contains both "explain" (Level 2) and "design" (Level 6)
        String sentence = "Please explain the concept and design an architecture for a compiler.";
        BloomTrie.VerbMatchResult result = trie.findBestVerbInSentence(sentence);

        assertTrue(result.isMatched());
        assertEquals("design", result.getVerb());
        assertEquals(BloomLevel.CREATE, result.getBloomLevel(), "Should pick the higher cognitive level (Create > Understand)");
    }
}
