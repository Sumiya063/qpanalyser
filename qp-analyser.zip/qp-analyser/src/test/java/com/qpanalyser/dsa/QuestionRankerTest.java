// File: src/test/java/com/qpanalyser/dsa/QuestionRankerTest.java
package com.qpanalyser.dsa;

import com.qpanalyser.model.Question;
import com.qpanalyser.model.QuestionFactory;
import com.qpanalyser.model.QuestionType;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit Tests for PriorityQueue Min-Heap Ranking & TreeMap Distribution
 * Author: DSA & Database Lead
 */
public class QuestionRankerTest {

    @Test
    @DisplayName("DSA: PriorityQueue ranks top-N hardest questions in O(K log N) time")
    void testTopNHardestQuestions() {
        List<Question> questions = new ArrayList<>();
        double[] scores = {12.0, 95.0, 45.0, 82.0, 31.0, 68.0, 91.0, 50.0};

        int idx = 1;
        for (double s : scores) {
            Question q = QuestionFactory.createQuestion(QuestionType.SHORT_ANSWER, "Q" + idx++, "Text", 5.0, "A");
            q.setDifficultyScore(s);
            questions.add(q);
        }

        // Retrieve Top 3 hardest
        List<Question> top3 = QuestionRanker.getTopNHardestQuestions(questions, 3);

        assertEquals(3, top3.size());
        assertEquals(95.0, top3.get(0).getDifficultyScore(), "Top 1 hardest must be 95.0");
        assertEquals(91.0, top3.get(1).getDifficultyScore(), "Top 2 hardest must be 91.0");
        assertEquals(82.0, top3.get(2).getDifficultyScore(), "Top 3 hardest must be 82.0");
    }

    @Test
    @DisplayName("DSA: TreeMap organizes score intervals into sorted buckets")
    void testTreeMapDistribution() {
        List<Question> questions = new ArrayList<>();

        double[] scores = {10.0, 15.0, 25.0, 40.0, 60.0, 75.0, 90.0};
        for (double s : scores) {
            Question q = QuestionFactory.createQuestion(QuestionType.SHORT_ANSWER, "Q", "Text", 5.0, "A");
            q.setDifficultyScore(s);
            questions.add(q);
        }

        Map<String, Integer> dist = QuestionRanker.computeScoreDistribution(questions);

        assertNotNull(dist);
        assertEquals(2, dist.get("1. Very Easy (0-20)"));
        assertEquals(1, dist.get("2. Easy (21-34)"));
        assertEquals(1, dist.get("3. Moderate (35-50)"));
        assertEquals(1, dist.get("4. Challenging (51-65)"));
        assertEquals(1, dist.get("5. Hard (66-80)"));
        assertEquals(1, dist.get("6. Advanced (81-100)"));
    }
}
