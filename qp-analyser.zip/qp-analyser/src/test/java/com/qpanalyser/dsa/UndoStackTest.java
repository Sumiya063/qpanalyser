// File: src/test/java/com/qpanalyser/dsa/UndoStackTest.java
package com.qpanalyser.dsa;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.EmptyStackException;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit Tests for Custom Data Structure: UndoStack<T>
 * Author: DSA & Database Lead
 */
public class UndoStackTest {

    @Test
    @DisplayName("DSA: LIFO operation - push and pop retrieve elements in reverse order")
    void testLifoBehavior() {
        UndoStack<String> stack = new UndoStack<>();
        assertTrue(stack.isEmpty());
        assertEquals(0, stack.size());

        stack.push("Action 1");
        stack.push("Action 2");
        stack.push("Action 3");

        assertEquals(3, stack.size());
        assertEquals("Action 3", stack.peek(), "Peek must inspect top without removing");
        assertEquals(3, stack.size());

        assertEquals("Action 3", stack.pop());
        assertEquals("Action 2", stack.pop());
        assertEquals("Action 1", stack.pop());
        assertTrue(stack.isEmpty());
    }

    @Test
    @DisplayName("DSA: Pop and peek on empty stack throw EmptyStackException")
    void testEmptyStackExceptions() {
        UndoStack<Integer> stack = new UndoStack<>();
        assertThrows(EmptyStackException.class, stack::pop);
        assertThrows(EmptyStackException.class, stack::peek);
    }

    @Test
    @DisplayName("DSA: Pushing null throws IllegalArgumentException")
    void testPushNull() {
        UndoStack<String> stack = new UndoStack<>();
        assertThrows(IllegalArgumentException.class, () -> stack.push(null));
    }

    @Test
    @DisplayName("DSA: Capacity restriction - Oldest entries are truncated when max capacity is reached")
    void testBoundedCapacity() {
        // Stack with max capacity 3
        UndoStack<String> boundedStack = new UndoStack<>(3);
        boundedStack.push("A");
        boundedStack.push("B");
        boundedStack.push("C");
        assertEquals(3, boundedStack.size());

        // Pushing 4th item should drop "A" from the bottom
        boundedStack.push("D");
        assertEquals(3, boundedStack.size());

        assertEquals("D", boundedStack.pop());
        assertEquals("C", boundedStack.pop());
        assertEquals("B", boundedStack.pop());
        assertTrue(boundedStack.isEmpty(), "Oldest element 'A' should have been dropped");
    }

    @Test
    @DisplayName("DSA: clear resets stack size to zero and releases top")
    void testClear() {
        UndoStack<Double> stack = new UndoStack<>();
        stack.push(10.5);
        stack.push(20.5);
        assertEquals(2, stack.size());

        stack.clear();
        assertEquals(0, stack.size());
        assertTrue(stack.isEmpty());
        assertThrows(EmptyStackException.class, stack::pop);
    }
}
