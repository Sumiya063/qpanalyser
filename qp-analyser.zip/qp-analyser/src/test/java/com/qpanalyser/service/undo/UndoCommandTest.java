// File: src/test/java/com/qpanalyser/service/undo/UndoCommandTest.java
package com.qpanalyser.service.undo;

import com.qpanalyser.model.Question;
import com.qpanalyser.model.QuestionFactory;
import com.qpanalyser.model.QuestionType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit Tests for Undo Commands & UndoManager
 * Author: DSA & Database Lead
 */
public class UndoCommandTest {

    private List<Question> questionList;
    private UndoManager undoManager;

    @BeforeEach
    void setUp() {
        questionList = new ArrayList<>();
        questionList.add(QuestionFactory.createQuestion(QuestionType.SHORT_ANSWER, "Q1", "Question 1 text", 5.0, "Section A"));
        questionList.add(QuestionFactory.createQuestion(QuestionType.SHORT_ANSWER, "Q2", "Question 2 text", 5.0, "Section A"));
        questionList.add(QuestionFactory.createQuestion(QuestionType.LONG_ANSWER, "Q3", "Question 3 text", 10.0, "Section B"));

        undoManager = new UndoManager(20);
    }

    @Test
    @DisplayName("OOP Concept: Command Pattern - DeleteQuestionCommand deletes and undo restores question")
    void testDeleteAndUndo() {
        Question q2 = questionList.get(1);
        DeleteQuestionCommand deleteCmd = new DeleteQuestionCommand(questionList, q2, 1);

        undoManager.executeCommand(deleteCmd);
        assertEquals(2, questionList.size());
        assertFalse(questionList.contains(q2));

        // Undo operation
        undoManager.undo();
        assertEquals(3, questionList.size());
        assertEquals(q2, questionList.get(1), "Question 2 must be restored at its exact original index");
    }

    @Test
    @DisplayName("OOP Concept: Command Pattern - EditQuestionCommand edits and undo reverts changes")
    void testEditAndUndo() {
        Question q1 = questionList.get(0);
        EditQuestionCommand editCmd = new EditQuestionCommand(q1, "Updated text", 8.0, "Section B", 2);

        undoManager.executeCommand(editCmd);
        assertEquals("Updated text", q1.getQuestionText());
        assertEquals(8.0, q1.getMarks());
        assertEquals("Section B", q1.getSection());
        assertEquals(2, q1.getSubPartCount());

        // Undo
        undoManager.undo();
        assertEquals("Question 1 text", q1.getQuestionText());
        assertEquals(5.0, q1.getMarks());
        assertEquals("Section A", q1.getSection());
        assertEquals(1, q1.getSubPartCount());
    }

    @Test
    @DisplayName("OOP Concept: Command Pattern - MergeQuestionsCommand combines text/marks and undo splits them back")
    void testMergeAndUndo() {
        Question q1 = questionList.get(0);
        Question q2 = questionList.get(1);

        MergeQuestionsCommand mergeCmd = new MergeQuestionsCommand(questionList, q1, q2, 1);
        undoManager.executeCommand(mergeCmd);

        assertEquals(2, questionList.size());
        assertTrue(q1.getQuestionText().contains("Question 1 text"));
        assertTrue(q1.getQuestionText().contains("Question 2 text"));
        assertEquals(10.0, q1.getMarks());
        assertFalse(questionList.contains(q2));

        // Undo merge
        undoManager.undo();
        assertEquals(3, questionList.size());
        assertEquals(5.0, q1.getMarks());
        assertEquals(q2, questionList.get(1));
    }

    @Test
    @DisplayName("OOP Concept: Command Pattern - SplitQuestionCommand divides question and undo re-unifies it")
    void testSplitAndUndo() {
        Question q3 = questionList.get(2);
        SplitQuestionCommand splitCmd = new SplitQuestionCommand(
                questionList, q3, "Part 1 text", "Part 2 text", 5.0, 5.0
        );

        undoManager.executeCommand(splitCmd);
        assertEquals(4, questionList.size());
        assertEquals(5.0, q3.getMarks());

        // Undo split
        undoManager.undo();
        assertEquals(3, questionList.size());
        assertEquals(10.0, q3.getMarks());
        assertEquals("Question 3 text", q3.getQuestionText());
    }

    @Test
    @DisplayName("UndoManager correctly manages undo and redo chains")
    void testUndoRedoChain() {
        Question q = questionList.get(0);
        EditQuestionCommand cmd = new EditQuestionCommand(q, "New text", 15.0, "Sec A", 1);

        undoManager.executeCommand(cmd);
        assertTrue(undoManager.canUndo());
        assertFalse(undoManager.canRedo());

        undoManager.undo();
        assertFalse(undoManager.canUndo());
        assertTrue(undoManager.canRedo());
        assertEquals(5.0, q.getMarks());

        undoManager.redo();
        assertTrue(undoManager.canUndo());
        assertFalse(undoManager.canRedo());
        assertEquals(15.0, q.getMarks());
    }
}
