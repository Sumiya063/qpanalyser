// File: src/test/java/com/qpanalyser/service/PaperAnalysisServiceTest.java
package com.qpanalyser.service;

import com.qpanalyser.exception.DatabaseException;
import com.qpanalyser.model.*;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit Tests for PaperAnalysisService
 * Author: Core Java & OOP Lead
 */
public class PaperAnalysisServiceTest {

    @Test
    @DisplayName("PaperAnalysisService runs end-to-end analysis on 15 sample questions")
    void testFullPaperAnalysisPipeline() throws DatabaseException {
        Paper paper = new Paper("CSE203 Final Examination", "CSE203", "2025-26", "IV", 100.0, 1);
        paper.setTargetEasy(30.0);
        paper.setTargetMedium(50.0);
        paper.setTargetHard(20.0);

        List<Question> questions = new ArrayList<>();
        // Section A (5 Easy questions, 5 marks each = 25 marks)
        questions.add(QuestionFactory.createQuestion(QuestionType.SHORT_ANSWER, "Q1", "Define encapsulation and data abstraction in Java.", 5.0, "Section A"));
        questions.add(QuestionFactory.createQuestion(QuestionType.SHORT_ANSWER, "Q2", "List the primitive data types supported in Java 21.", 5.0, "Section A"));
        questions.add(QuestionFactory.createQuestion(QuestionType.SHORT_ANSWER, "Q3", "State the difference between break and continue statements.", 5.0, "Section A"));
        questions.add(QuestionFactory.createQuestion(QuestionType.SHORT_ANSWER, "Q4", "Identify valid identifiers from the given list of names.", 5.0, "Section A"));
        questions.add(QuestionFactory.createQuestion(QuestionType.SHORT_ANSWER, "Q5", "Recall the definition of bytecode and JVM execution engine.", 5.0, "Section A"));

        // Section B (6 Medium questions = 50 marks)
        questions.add(QuestionFactory.createQuestion(QuestionType.SHORT_ANSWER, "Q6", "Explain the concept of method overriding and dynamic method dispatch.", 8.0, "Section B"));
        questions.add(QuestionFactory.createQuestion(QuestionType.SHORT_ANSWER, "Q7", "Describe the life cycle of a thread in Java concurrency.", 8.0, "Section B"));
        questions.add(QuestionFactory.createQuestion(QuestionType.PROBLEM, "Q8", "Calculate the time complexity of quicksort and trace partition algorithm.", 9.0, "Section B"));
        questions.add(QuestionFactory.createQuestion(QuestionType.PROBLEM, "Q9", "Solve the recurrence relation for merge sort algorithm. int mid = low + (high-low)/2;", 9.0, "Section B"));
        questions.add(QuestionFactory.createQuestion(QuestionType.SHORT_ANSWER, "Q10", "Differentiate between checked and unchecked exceptions in Java.", 8.0, "Section B"));
        questions.add(QuestionFactory.createQuestion(QuestionType.SHORT_ANSWER, "Q11", "Compare HashMap and TreeMap in terms of internal hashing and search time.", 8.0, "Section B"));

        // Section C (4 Hard questions = 25 marks)
        questions.add(QuestionFactory.createQuestion(QuestionType.LONG_ANSWER, "Q12", "Evaluate garbage collection algorithms: Serial, Parallel, and G1 GC. Justify choices.", 10.0, "Section C"));
        questions.add(QuestionFactory.createQuestion(QuestionType.LONG_ANSWER, "Q13", "Design an online banking system using OOP inheritance, interfaces, and design patterns.", 15.0, "Section C"));

        paper.setQuestions(questions);

        // Run Analysis Service
        PaperAnalysisService service = new PaperAnalysisService();
        AnalysisResult result = service.analyzePaper(paper);

        assertNotNull(result);
        assertTrue(result.getOverallDifficultyIndex() >= 30.0 && result.getOverallDifficultyIndex() <= 70.0,
                "Overall difficulty index should be within realistic range, was: " + result.getOverallDifficultyIndex());

        // Check Bloom count totals
        int totalBloom = result.getRememberCount() + result.getUnderstandCount() + result.getApplyCount() +
                         result.getAnalyzeCount() + result.getEvaluateCount() + result.getCreateCount();
        assertEquals(questions.size(), totalBloom, "Bloom level counters must equal total question count");

        // Check percentages sum close to 100%
        double totalPct = result.getEasyPercentage() + result.getMediumPercentage() + result.getHardPercentage();
        assertEquals(100.0, totalPct, 1.5, "Difficulty percentages must sum to ~100%");

        // Check verdict & suggestions
        assertNotNull(result.getBalanceVerdict());
        assertNotNull(result.getSuggestions());
        assertFalse(result.getSuggestions().isEmpty());
    }
}
