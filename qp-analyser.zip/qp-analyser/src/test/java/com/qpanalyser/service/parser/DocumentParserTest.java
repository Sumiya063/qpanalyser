// File: src/test/java/com/qpanalyser/service/parser/DocumentParserTest.java
package com.qpanalyser.service.parser;

import com.qpanalyser.exception.InvalidPaperException;
import com.qpanalyser.exception.ParsingException;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit Tests for Document Parsers, Factories, and File Validation
 * Author: DSA & Database Lead
 */
public class DocumentParserTest {

    @Test
    @DisplayName("OOP Concept: Strategy Pattern - DocumentParserFactory selects correct parser by extension")
    void testParserFactoryResolution() throws Exception {
        File txtFile = new File("exam.txt");
        File pdfFile = new File("midterm.pdf");
        File docxFile = new File("final.docx");

        DocumentParser txtParser = DocumentParserFactory.getParser(txtFile);
        DocumentParser pdfParser = DocumentParserFactory.getParser(pdfFile);
        DocumentParser docxParser = DocumentParserFactory.getParser(docxFile);

        assertInstanceOf(PlainTextParser.class, txtParser);
        assertInstanceOf(PdfDocumentParser.class, pdfParser);
        assertInstanceOf(DocxDocumentParser.class, docxParser);
    }

    @Test
    @DisplayName("DocumentParserFactory throws InvalidPaperException for unsupported extension")
    void testUnsupportedExtension() {
        File invalidFile = new File("archive.zip");
        assertThrows(InvalidPaperException.class, () -> DocumentParserFactory.getParser(invalidFile));
    }

    @Test
    @DisplayName("PlainTextParser successfully extracts text from valid UTF-8 file")
    void testPlainTextParserSuccess(@TempDir Path tempDir) throws Exception {
        Path tempFile = tempDir.resolve("sample_exam.txt");
        String content = "Q1. Define polymorphism in Java.\nQ2. Explain abstract classes.";
        Files.writeString(tempFile, content);

        PlainTextParser parser = new PlainTextParser();
        String extracted = parser.parse(tempFile.toFile());

        assertNotNull(extracted);
        assertEquals(content.trim(), extracted);
    }

    @Test
    @DisplayName("PlainTextParser throws InvalidPaperException when file is empty")
    void testPlainTextParserEmptyFile(@TempDir Path tempDir) throws Exception {
        Path emptyFile = tempDir.resolve("empty.txt");
        Files.createFile(emptyFile);

        PlainTextParser parser = new PlainTextParser();
        assertThrows(InvalidPaperException.class, () -> parser.parse(emptyFile.toFile()));
    }

    @Test
    @DisplayName("FileValidator enforces non-null, existence, and size limits")
    void testFileValidator(@TempDir Path tempDir) {
        assertThrows(InvalidPaperException.class, () -> FileValidator.validate(null));

        File nonExistent = new File("does_not_exist_2026.txt");
        assertThrows(InvalidPaperException.class, () -> FileValidator.validate(nonExistent));
    }

    @Test
    @DisplayName("DocumentParserFactory extracts file extension cleanly")
    void testGetFileExtension() {
        assertEquals("txt", DocumentParserFactory.getFileExtension("paper.txt"));
        assertEquals("pdf", DocumentParserFactory.getFileExtension("final_exam.PDF"));
        assertEquals("docx", DocumentParserFactory.getFileExtension("c:\\folder\\test.docx"));
        assertEquals("", DocumentParserFactory.getFileExtension("noextension"));
        assertEquals("", DocumentParserFactory.getFileExtension(null));
    }
}
