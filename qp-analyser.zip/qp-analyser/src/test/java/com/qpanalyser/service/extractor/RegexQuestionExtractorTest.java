// File: src/test/java/com/qpanalyser/service/extractor/RegexQuestionExtractorTest.java
package com.qpanalyser.service.extractor;

import com.qpanalyser.exception.ParsingException;
import com.qpanalyser.model.Question;
import com.qpanalyser.model.QuestionType;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit Tests for RegexQuestionExtractor
 * Author: Team Coordinator
 */
public class RegexQuestionExtractorTest {

    private final RegexQuestionExtractor extractor = new RegexQuestionExtractor();

    @Test
    @DisplayName("Extracts structured questions, numbers, marks, and sections from college examination text")
    void testStandardQuestionExtraction() throws ParsingException {
        String examPaper = """
                CSE203 OBJECT ORIENTED PROGRAMMING USING JAVA
                
                SECTION A: FUNDAMENTALS
                Q1. Define the terms Encapsulation and Data Hiding. [5]
                Q2. Explain the purpose of JVM and Bytecode in Java. (5 marks)
                
                SECTION B: DATA STRUCTURES & ALGORITHMS
                Q3. Write a Java method to implement binary search on a sorted array. Calculate its time complexity. [10]
                Q4. Describe polymorphism with:
                    (a) Method overloading
                    (b) Method overriding
                    (c) Dynamic method dispatch [15]
                """;

        List<Question> questions = extractor.extractQuestions(examPaper);

        assertNotNull(questions);
        assertEquals(4, questions.size(), "Must extract exactly 4 questions");

        // Verify Question 1
        Question q1 = questions.get(0);
        assertEquals("Q1", q1.getQuestionNumber());
        assertEquals(5.0, q1.getMarks());
        assertTrue(q1.getSection().contains("Section A"));
        assertTrue(q1.getQuestionText().contains("Define the terms Encapsulation"));
        assertFalse(q1.getQuestionText().contains("[5]"), "Marks tag [5] should be stripped from display text");

        // Verify Question 2
        Question q2 = questions.get(1);
        assertEquals("Q2", q2.getQuestionNumber());
        assertEquals(5.0, q2.getMarks());

        // Verify Question 3 (Problem question due to "binary search" & "time complexity")
        Question q3 = questions.get(2);
        assertEquals("Q3", q3.getQuestionNumber());
        assertEquals(10.0, q3.getMarks());
        assertTrue(q3.getSection().contains("Section B"));
        assertEquals(QuestionType.PROBLEM, q3.getQuestionType());

        // Verify Question 4 (Sub-parts count)
        Question q4 = questions.get(3);
        assertEquals("Q4", q4.getQuestionNumber());
        assertEquals(15.0, q4.getMarks());
        assertEquals(3, q4.getSubPartCount(), "Should detect 3 sub-parts: (a), (b), (c)");
        assertEquals(QuestionType.LONG_ANSWER, q4.getQuestionType());
    }

    @Test
    @DisplayName("Extracts questions with alternative numbering schemas (1., 2., Question 3)")
    void testAlternativeNumberingSchemas() throws ParsingException {
        String text = """
                1. What is an immutable object in Java? [4]
                2. Differentiate between String, StringBuilder, and StringBuffer. [6]
                Question 3: Implement a custom generic LinkedList class. [10]
                """;

        List<Question> questions = extractor.extractQuestions(text);

        assertEquals(3, questions.size());
        assertEquals("Q1", questions.get(0).getQuestionNumber());
        assertEquals(4.0, questions.get(0).getMarks());
        assertEquals("Q2", questions.get(1).getQuestionNumber());
        assertEquals(6.0, questions.get(1).getMarks());
        assertEquals("Q3", questions.get(2).getQuestionNumber());
        assertEquals(10.0, questions.get(2).getMarks());
    }

    @Test
    @DisplayName("Empty or blank text throws ParsingException")
    void testEmptyExtraction() {
        assertThrows(ParsingException.class, () -> extractor.extractQuestions(""));
        assertThrows(ParsingException.class, () -> extractor.extractQuestions("   \n\n  "));
        assertThrows(ParsingException.class, () -> extractor.extractQuestions(null));
    }
}
