// File: src/main/java/com/qpanalyser/app/MainApp.java
package com.qpanalyser.app;

import com.qpanalyser.db.DatabaseConnection;
import com.qpanalyser.db.DatabaseInitializer;
import com.qpanalyser.exception.DatabaseException;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;

/**
 * Main Application Launcher (JavaFX)
 * Author: Team Coordinator
 * 
 * College Mini Project: AI Question Paper Difficulty Analyzer
 * Course: CSE203 - Object-Oriented Programming using Java
 * 
 * Initializes database tables and launches the JavaFX GUI.
 */
public class MainApp extends Application {

    @Override
    public void init() {
        System.out.println("================================================================================");
        System.out.println("  Starting " + AppConfig.APP_NAME + " v" + AppConfig.APP_VERSION);
        System.out.println("  " + AppConfig.APP_SUBTITLE);
        System.out.println("================================================================================");

        // Auto-initialize MySQL tables and seed records
        try {
            DatabaseInitializer.initialize();
            System.out.println("[MainApp] Database tables and seed records verified successfully.");
        } catch (DatabaseException e) {
            System.err.println("[MainApp] Notice: Database auto-initialization could not complete:");
            System.err.println(e.getMessage());
            System.err.println("[MainApp] Application will launch; please verify MySQL server and db.properties.");
        }
    }

    @Override
    public void start(Stage primaryStage) {
        try {
            URL fxmlUrl = getClass().getResource("/com/qpanalyser/ui/view/login.fxml");
            if (fxmlUrl == null) {
                System.err.println("Fatal Error: Could not locate login.fxml in classpath.");
                return;
            }

            FXMLLoader loader = new FXMLLoader(fxmlUrl);
            Parent root = loader.load();

            Scene scene = new Scene(root, AppConfig.DEFAULT_WINDOW_WIDTH, AppConfig.DEFAULT_WINDOW_HEIGHT);
            primaryStage.setTitle(AppConfig.APP_NAME + " - [" + AppConfig.APP_SUBTITLE + "]");
            primaryStage.setScene(scene);
            primaryStage.setMinWidth(900);
            primaryStage.setMinHeight(600);
            primaryStage.show();

        } catch (IOException e) {
            System.err.println("Fatal Error during JavaFX scene loading: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @Override
    public void stop() {
        // OOP Concept: Clean resource teardown
        try {
            DatabaseConnection.getInstance().closeConnection();
            System.out.println("[MainApp] Closed database connection gracefully.");
        } catch (Exception ignored) {
        }
    }

    public static void main(String[] args) {
        // JavaFX launch entry point
        launch(args);
    }
}
