// File: src/main/java/com/qpanalyser/app/AppConfig.java
package com.qpanalyser.app;

/**
 * Global Application Constants & Configuration
 * Author: Team Coordinator
 */
public final class AppConfig {

    public static final String APP_NAME = "AI Question Paper Difficulty Analyzer";
    public static final String APP_SUBTITLE = "Course: CSE203 - Object-Oriented Programming using Java";
    public static final String APP_VERSION = "1.0.0";
    
    // Window dimensions
    public static final double DEFAULT_WINDOW_WIDTH = 1050;
    public static final double DEFAULT_WINDOW_HEIGHT = 700;

    private AppConfig() {
    }
}
