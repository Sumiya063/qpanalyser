// File: src/main/java/com/qpanalyser/analyzer/TrieBloomClassifier.java
package com.qpanalyser.analyzer;

import com.qpanalyser.dsa.BloomTrie;
import com.qpanalyser.model.BloomLevel;
import com.qpanalyser.model.BloomVerb;
import com.qpanalyser.model.Question;

import java.util.Collection;

/**
 * OOP Concept: Strategy Pattern Implementation (Primary Bloom Classifier)
 * Author: Core Java & OOP Lead
 * 
 * Classifies questions using the custom hand-written BloomTrie prefix tree.
 * Scans question text for action verbs and assigns the highest cognitive level.
 */
public class TrieBloomClassifier implements BloomClassifier {

    private final BloomTrie trie;

    public TrieBloomClassifier() {
        this.trie = new BloomTrie();
        seedDefaultVerbs();
    }

    public TrieBloomClassifier(BloomTrie trie) {
        this.trie = trie != null ? trie : new BloomTrie();
    }

    public void loadVerbs(Collection<BloomVerb> verbs) {
        if (verbs != null) {
            for (BloomVerb verb : verbs) {
                trie.insert(verb.getVerb(), verb.getBloomLevel(), verb.getWeight());
            }
        }
    }

    @Override
    public BloomLevel classify(Question question) {
        if (question == null || question.getQuestionText() == null) {
            return BloomLevel.REMEMBER;
        }

        BloomTrie.VerbMatchResult match = trie.findBestVerbInSentence(question.getQuestionText());
        if (match.isMatched()) {
            return match.getBloomLevel();
        }

        // Secondary fallback based on marks and question type
        return fallbackByQuestionProfile(question);
    }

    @Override
    public String getIdentifiedVerb(Question question) {
        if (question == null || question.getQuestionText() == null) {
            return "N/A";
        }
        BloomTrie.VerbMatchResult match = trie.findBestVerbInSentence(question.getQuestionText());
        return match.isMatched() ? match.getVerb() : "implicit";
    }

    private BloomLevel fallbackByQuestionProfile(Question q) {
        if (q.getMarks() >= 12.0) {
            return BloomLevel.CREATE;
        } else if (q.getMarks() >= 8.0) {
            return BloomLevel.ANALYZE;
        } else if (q.getMarks() >= 4.0) {
            return BloomLevel.UNDERSTAND;
        }
        return BloomLevel.REMEMBER;
    }

    private void seedDefaultVerbs() {
        // Level 1: Remember
        trie.insert("define", BloomLevel.REMEMBER, 1.0);
        trie.insert("list", BloomLevel.REMEMBER, 1.0);
        trie.insert("state", BloomLevel.REMEMBER, 1.0);
        trie.insert("recall", BloomLevel.REMEMBER, 1.0);
        trie.insert("name", BloomLevel.REMEMBER, 1.0);
        trie.insert("identify", BloomLevel.REMEMBER, 1.0);

        // Level 2: Understand
        trie.insert("explain", BloomLevel.UNDERSTAND, 2.0);
        trie.insert("describe", BloomLevel.UNDERSTAND, 2.0);
        trie.insert("summarize", BloomLevel.UNDERSTAND, 2.0);
        trie.insert("interpret", BloomLevel.UNDERSTAND, 2.0);
        trie.insert("classify", BloomLevel.UNDERSTAND, 2.0);
        trie.insert("discuss", BloomLevel.UNDERSTAND, 2.0);

        // Level 3: Apply
        trie.insert("apply", BloomLevel.APPLY, 3.0);
        trie.insert("calculate", BloomLevel.APPLY, 3.0);
        trie.insert("solve", BloomLevel.APPLY, 3.0);
        trie.insert("compute", BloomLevel.APPLY, 3.0);
        trie.insert("implement", BloomLevel.APPLY, 3.0);
        trie.insert("execute", BloomLevel.APPLY, 3.0);
        trie.insert("demonstrate", BloomLevel.APPLY, 3.0);

        // Level 4: Analyze
        trie.insert("analyze", BloomLevel.ANALYZE, 4.0);
        trie.insert("compare", BloomLevel.ANALYZE, 4.0);
        trie.insert("contrast", BloomLevel.ANALYZE, 4.0);
        trie.insert("differentiate", BloomLevel.ANALYZE, 4.0);
        trie.insert("distinguish", BloomLevel.ANALYZE, 4.0);
        trie.insert("examine", BloomLevel.ANALYZE, 4.0);

        // Level 5: Evaluate
        trie.insert("evaluate", BloomLevel.EVALUATE, 5.0);
        trie.insert("assess", BloomLevel.EVALUATE, 5.0);
        trie.insert("justify", BloomLevel.EVALUATE, 5.0);
        trie.insert("critique", BloomLevel.EVALUATE, 5.0);
        trie.insert("defend", BloomLevel.EVALUATE, 5.0);
        trie.insert("judge", BloomLevel.EVALUATE, 5.0);

        // Level 6: Create
        trie.insert("create", BloomLevel.CREATE, 6.0);
        trie.insert("design", BloomLevel.CREATE, 6.0);
        trie.insert("develop", BloomLevel.CREATE, 6.0);
        trie.insert("formulate", BloomLevel.CREATE, 6.0);
        trie.insert("invent", BloomLevel.CREATE, 6.0);
        trie.insert("compose", BloomLevel.CREATE, 6.0);
    }
}
