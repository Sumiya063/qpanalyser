// File: src/main/java/com/qpanalyser/analyzer/DifficultyScorer.java
package com.qpanalyser.analyzer;

import com.qpanalyser.model.DifficultyLevel;
import com.qpanalyser.model.Question;

/**
 * OOP Concept: Strategy Design Pattern (Difficulty Scorer Interface)
 * Author: Core Java & OOP Lead
 * 
 * Computes a standardized difficulty index (0 to 100) and maps questions into
 * DifficultyLevel categories (EASY, MEDIUM, HARD).
 */
public interface DifficultyScorer {

    /**
     * Calculates difficulty score on a 0.0 to 100.0 scale.
     * 
     * @param question The question under evaluation
     * @param features Linguistic and structural NLP features
     * @return Score between 0.0 and 100.0
     */
    double calculateDifficultyScore(Question question, FeatureExtractor.QuestionFeatures features);

    /**
     * Maps a numerical difficulty score into an Easy, Medium, or Hard level.
     */
    DifficultyLevel determineDifficultyLevel(double score);
}
