// File: src/main/java/com/qpanalyser/analyzer/WeightedDifficultyScorer.java
package com.qpanalyser.analyzer;

import com.qpanalyser.model.DifficultyLevel;
import com.qpanalyser.model.Question;

import java.util.Map;

/**
 * OOP Concept: Strategy Pattern Implementation (Multi-Factor Scoring Model)
 * Author: Core Java & OOP Lead
 * 
 * Implements the college project difficulty formula:
 * Difficulty = (wBloom * bloomScore) + (wLength * lengthScore) +
 *              (wSubParts * subPartScore) + (wMarks * marksScore) + (wComplexity * complexityScore)
 * 
 * Score Boundaries:
 * - Easy:   Score < 35.0
 * - Medium: 35.0 <= Score <= 65.0
 * - Hard:   Score > 65.0
 */
public class WeightedDifficultyScorer implements DifficultyScorer {

    // Default weights specified by the course document
    private double weightBloom = 0.35;
    private double weightLength = 0.20;
    private double weightSubParts = 0.15;
    private double weightMarks = 0.15;
    private double weightComplexity = 0.15;

    // Threshold boundaries
    private double easyMax = 35.0;
    private double mediumMax = 65.0;

    public WeightedDifficultyScorer() {
    }

    public WeightedDifficultyScorer(double weightBloom, double weightLength, double weightSubParts,
                                   double weightMarks, double weightComplexity,
                                   double easyMax, double mediumMax) {
        this.weightBloom = weightBloom;
        this.weightLength = weightLength;
        this.weightSubParts = weightSubParts;
        this.weightMarks = weightMarks;
        this.weightComplexity = weightComplexity;
        this.easyMax = easyMax;
        this.mediumMax = mediumMax;
    }

    /**
     * Reconfigures calculation weights dynamically from the database settings map.
     */
    public void configureFromSettings(Map<String, String> settings) {
        if (settings == null) return;
        this.weightBloom = parseDouble(settings.get("weight.bloom"), this.weightBloom);
        this.weightLength = parseDouble(settings.get("weight.length"), this.weightLength);
        this.weightSubParts = parseDouble(settings.get("weight.subparts"), this.weightSubParts);
        this.weightMarks = parseDouble(settings.get("weight.marks"), this.weightMarks);
        this.weightComplexity = parseDouble(settings.get("weight.complexity"), this.weightComplexity);
        this.easyMax = parseDouble(settings.get("threshold.easy_max"), this.easyMax);
        this.mediumMax = parseDouble(settings.get("threshold.medium_max"), this.mediumMax);
    }

    @Override
    public double calculateDifficultyScore(Question question, FeatureExtractor.QuestionFeatures features) {
        if (question == null || features == null) {
            return 20.0;
        }

        // 1. Bloom Taxonomy Score (Level 1 to 6 mapped to 0-100)
        int bloomOrder = question.getBloomLevel() != null ? question.getBloomLevel().getLevelOrder() : 1;
        double bloomScore = (bloomOrder / 6.0) * 100.0;

        // 2. Length Score (Word count normalized against 50 words ceiling)
        double lengthScore = Math.min(100.0, (features.wordCount() / 50.0) * 100.0);

        // 3. Sub-Parts Score (1 part = 25, 2 parts = 50, 3 parts = 75, 4+ parts = 100)
        double subPartScore = Math.min(100.0, (features.subPartCount() / 4.0) * 100.0);

        // 4. Marks Score (Normalized against 15 marks maximum ceiling)
        double marksScore = Math.min(100.0, (features.marks() / 15.0) * 100.0);

        // 5. Complexity Score (Technical term density + bonus for formulas/code)
        double baseComplexity = features.technicalTermDensity() * 80.0;
        if (features.hasFormulasOrCode()) {
            baseComplexity += 20.0;
        }
        double complexityScore = Math.min(100.0, Math.max(0.0, baseComplexity));

        // Aggregate Multi-Factor Weighted Sum
        double total = (weightBloom * bloomScore) +
                       (weightLength * lengthScore) +
                       (weightSubParts * subPartScore) +
                       (weightMarks * marksScore) +
                       (weightComplexity * complexityScore);

        // Round to 1 decimal place and clamp to [0.0, 100.0]
        double clamped = Math.max(0.0, Math.min(100.0, total));
        return Math.round(clamped * 10.0) / 10.0;
    }

    @Override
    public DifficultyLevel determineDifficultyLevel(double score) {
        return DifficultyLevel.fromScore(score, this.easyMax, this.mediumMax);
    }

    private double parseDouble(String str, double def) {
        if (str == null) return def;
        try {
            return Double.parseDouble(str.trim());
        } catch (NumberFormatException e) {
            return def;
        }
    }

    // Getters and Setters
    public double getWeightBloom() { return weightBloom; }
    public double getWeightLength() { return weightLength; }
    public double getWeightSubParts() { return weightSubParts; }
    public double getWeightMarks() { return weightMarks; }
    public double getWeightComplexity() { return weightComplexity; }
    public double getEasyMax() { return easyMax; }
    public double getMediumMax() { return mediumMax; }
}
