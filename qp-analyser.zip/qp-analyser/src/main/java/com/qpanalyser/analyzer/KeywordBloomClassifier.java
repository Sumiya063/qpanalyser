// File: src/main/java/com/qpanalyser/analyzer/KeywordBloomClassifier.java
package com.qpanalyser.analyzer;

import com.qpanalyser.model.BloomLevel;
import com.qpanalyser.model.Question;

import java.util.HashMap;
import java.util.Map;

/**
 * OOP Concept: Strategy Design Pattern (Alternative Classifier Implementation)
 * Author: Core Java & OOP Lead
 * 
 * Classifies questions using a Hash Table (HashMap) dictionary lookup.
 */
public class KeywordBloomClassifier implements BloomClassifier {

    private final Map<String, BloomLevel> verbMap = new HashMap<>();

    public KeywordBloomClassifier() {
        // Sample mappings
        verbMap.put("define", BloomLevel.REMEMBER);
        verbMap.put("list", BloomLevel.REMEMBER);
        verbMap.put("explain", BloomLevel.UNDERSTAND);
        verbMap.put("describe", BloomLevel.UNDERSTAND);
        verbMap.put("calculate", BloomLevel.APPLY);
        verbMap.put("solve", BloomLevel.APPLY);
        verbMap.put("compare", BloomLevel.ANALYZE);
        verbMap.put("differentiate", BloomLevel.ANALYZE);
        verbMap.put("evaluate", BloomLevel.EVALUATE);
        verbMap.put("justify", BloomLevel.EVALUATE);
        verbMap.put("design", BloomLevel.CREATE);
        verbMap.put("create", BloomLevel.CREATE);
    }

    @Override
    public BloomLevel classify(Question question) {
        if (question == null || question.getQuestionText() == null) {
            return BloomLevel.REMEMBER;
        }

        String[] words = question.getQuestionText().toLowerCase().split("[^a-z]+");
        BloomLevel highest = BloomLevel.REMEMBER;

        for (String word : words) {
            BloomLevel level = verbMap.get(word);
            if (level != null && level.getLevelOrder() > highest.getLevelOrder()) {
                highest = level;
            }
        }
        return highest;
    }

    @Override
    public String getIdentifiedVerb(Question question) {
        if (question == null || question.getQuestionText() == null) return "N/A";
        String[] words = question.getQuestionText().toLowerCase().split("[^a-z]+");
        for (String word : words) {
            if (verbMap.containsKey(word)) {
                return word;
            }
        }
        return "implicit";
    }
}
