// File: src/main/java/com/qpanalyser/analyzer/FeatureExtractor.java
package com.qpanalyser.analyzer;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * NLP Feature Extraction & Lexical Density Analyzer
 * Author: Team Coordinator
 * 
 * Computes NLP linguistic metrics per question: word count, average word length,
 * technical term density (using HashSet for O(1) lookup), stop-word filtering,
 * and formula/code presence.
 * 
 * Big-O: O(W) where W is the number of word tokens in the question text.
 */
public class FeatureExtractor {

    public record QuestionFeatures(
            int wordCount,
            double averageWordLength,
            double technicalTermDensity,
            boolean hasFormulasOrCode,
            boolean hasNumbers,
            int subPartCount,
            double marks
    ) {}

    // O(1) Stop Words lookup table
    private static final Set<String> STOP_WORDS = new HashSet<>(Arrays.asList(
            "a", "about", "above", "after", "again", "against", "all", "am", "an", "and", "any", "are",
            "as", "at", "be", "because", "been", "before", "being", "below", "between", "both", "but", "by",
            "could", "did", "do", "does", "doing", "down", "during", "each", "few", "for", "from", "further",
            "had", "has", "have", "having", "he", "her", "here", "hers", "herself", "him", "himself", "his",
            "how", "i", "if", "in", "into", "is", "it", "its", "itself", "me", "more", "most", "my", "myself",
            "no", "nor", "not", "of", "off", "on", "once", "only", "or", "other", "ought", "our", "ours",
            "ourselves", "out", "over", "own", "same", "she", "should", "so", "some", "such", "than", "that",
            "the", "their", "theirs", "them", "themselves", "then", "there", "these", "they", "this", "those",
            "through", "to", "too", "under", "until", "up", "very", "was", "we", "were", "what", "when",
            "where", "which", "while", "who", "whom", "why", "with", "would", "you", "your", "yours", "yourself"
    ));

    // O(1) Computer Science & OOP Domain Vocabulary
    private static final Set<String> TECHNICAL_TERMS = new HashSet<>(Arrays.asList(
            "class", "object", "inheritance", "polymorphism", "encapsulation", "abstraction", "interface",
            "overloading", "overriding", "constructor", "destructor", "instance", "method", "variable",
            "static", "final", "abstract", "package", "private", "public", "protected", "super", "this",
            "enum", "jvm", "bytecode", "garbage", "collection", "heap", "stack", "thread", "concurrency",
            "synchronization", "deadlock", "mutex", "stream", "lambda", "generic", "reflection", "socket",
            "exception", "throwable", "try", "catch", "finally", "array", "list", "linkedlist", "queue",
            "trie", "tree", "graph", "hashmap", "hashtable", "set", "priorityqueue", "recursion",
            "sorting", "mergesort", "quicksort", "binarysearch", "complexity", "algorithm", "database",
            "query", "transaction", "index", "jdbc", "compiler", "runtime", "memory", "pointer", "reference"
    ));

    private static final Pattern FORMULA_CODE_PATTERN = Pattern.compile(
            "[\\{\\};=+\\-*/<>|\\[\\]]|\\b(int|double|float|char|boolean|void|public|private|return|for|while|if)\\b"
    );

    private static final Pattern NUMBERS_PATTERN = Pattern.compile("\\b\\d+(?:\\.\\d+)?\\b");

    /**
     * Extracts linguistic and structural metrics from a question.
     */
    public QuestionFeatures extractFeatures(String questionText, double marks, int subParts) {
        if (questionText == null || questionText.trim().isEmpty()) {
            return new QuestionFeatures(0, 0.0, 0.0, false, false, subParts, marks);
        }

        String[] rawWords = questionText.toLowerCase().split("[^a-zA-Z0-9]+");
        int totalWords = 0;
        int totalCharLength = 0;
        int technicalCount = 0;
        int nonStopWords = 0;

        for (String word : rawWords) {
            String w = word.trim();
            if (w.isEmpty()) continue;

            totalWords++;
            totalCharLength += w.length();

            if (!STOP_WORDS.contains(w)) {
                nonStopWords++;
                if (TECHNICAL_TERMS.contains(w)) {
                    technicalCount++;
                }
            }
        }

        double avgWordLength = totalWords > 0 ? (double) totalCharLength / totalWords : 0.0;
        double techDensity = nonStopWords > 0 ? (double) technicalCount / nonStopWords : 0.0;
        boolean hasFormulas = FORMULA_CODE_PATTERN.matcher(questionText).find();
        boolean hasNumbers = NUMBERS_PATTERN.matcher(questionText).find();

        return new QuestionFeatures(
                totalWords,
                avgWordLength,
                techDensity,
                hasFormulas,
                hasNumbers,
                Math.max(1, subParts),
                marks
        );
    }
}
