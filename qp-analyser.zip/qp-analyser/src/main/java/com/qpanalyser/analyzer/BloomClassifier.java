// File: src/main/java/com/qpanalyser/analyzer/BloomClassifier.java
package com.qpanalyser.analyzer;

import com.qpanalyser.model.BloomLevel;
import com.qpanalyser.model.Question;

/**
 * OOP Concept: Strategy Design Pattern (Classifier Interface)
 * Author: Core Java & OOP Lead
 * 
 * Classifies an exam question into one of the 6 cognitive domains of Bloom's Taxonomy.
 */
public interface BloomClassifier {

    /**
     * Determines the cognitive BloomLevel for a given question.
     * 
     * @param question The question to analyze
     * @return Assigned BloomLevel
     */
    BloomLevel classify(Question question);

    /**
     * Identifies the primary action verb triggering the classification.
     * 
     * @param question The question to analyze
     * @return Triggering action verb string (e.g. "design", "explain")
     */
    String getIdentifiedVerb(Question question);
}
