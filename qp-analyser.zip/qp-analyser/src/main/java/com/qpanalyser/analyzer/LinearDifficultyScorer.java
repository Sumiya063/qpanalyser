// File: src/main/java/com/qpanalyser/analyzer/LinearDifficultyScorer.java
package com.qpanalyser.analyzer;

import com.qpanalyser.model.DifficultyLevel;
import com.qpanalyser.model.Question;

/**
 * OOP Concept: Strategy Design Pattern (Alternative Scorer Implementation)
 * Author: Core Java & OOP Lead
 * 
 * Demonstrates the Strategy pattern with an alternative linear baseline scoring model
 * primarily driven by marks and Bloom levels.
 */
public class LinearDifficultyScorer implements DifficultyScorer {

    @Override
    public double calculateDifficultyScore(Question question, FeatureExtractor.QuestionFeatures features) {
        if (question == null) return 20.0;
        int bloom = question.getBloomLevel() != null ? question.getBloomLevel().getLevelOrder() : 1;
        double marks = question.getMarks();
        double score = (bloom * 10.0) + (marks * 2.5);
        return Math.max(0.0, Math.min(100.0, score));
    }

    @Override
    public DifficultyLevel determineDifficultyLevel(double score) {
        return DifficultyLevel.fromScore(score, 35.0, 65.0);
    }
}
