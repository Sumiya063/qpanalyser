// File: src/main/java/com/qpanalyser/ui/controller/LoginController.java
package com.qpanalyser.ui.controller;

import com.qpanalyser.db.DatabaseConnection;
import com.qpanalyser.exception.AuthenticationException;
import com.qpanalyser.exception.DatabaseException;
import com.qpanalyser.model.Role;
import com.qpanalyser.model.User;
import com.qpanalyser.service.AuthService;
import com.qpanalyser.service.SessionManager;
import com.qpanalyser.ui.util.AlertHelper;
import com.qpanalyser.ui.util.SceneNavigator;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.concurrent.Task;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.net.URL;
import java.util.ResourceBundle;

/**
 * Controller: User Authentication View
 * Author: JavaFX Lead
 * 
 * Manages the UI events, animations, and transitions for the Login and Registration screen.
 * Delegates authentication logic to AuthService (MVC pattern).
 */
public class LoginController implements Initializable {

    @FXML private Label lblDbStatus;
    @FXML private Label lblDbDetails;

    // View Switching
    @FXML private Button btnTabLogin;
    @FXML private Button btnTabRegister;
    @FXML private VBox paneLogin;
    @FXML private VBox paneRegister;

    // Login Form Elements
    @FXML private TextField txtLoginUsername;
    @FXML private PasswordField txtLoginPassword;
    @FXML private Label lblLoginMessage;
    @FXML private Button btnLogin;

    // Registration Form Elements
    @FXML private TextField txtRegFullName;
    @FXML private ComboBox<Role> cmbRegRole;
    @FXML private TextField txtRegEmail;
    @FXML private TextField txtRegUsername;
    @FXML private PasswordField txtRegPassword;
    @FXML private PasswordField txtRegConfirmPassword;
    @FXML private Label lblRegMessage;
    @FXML private Button btnRegister;

    private final AuthService authService;

    public LoginController() {
        this.authService = new AuthService();
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        // Populate role dropdown
        cmbRegRole.setItems(FXCollections.observableArrayList(Role.TEACHER, Role.ADMIN));
        cmbRegRole.getSelectionModel().select(Role.TEACHER);

        // Check database connectivity in background task to keep UI responsive
        checkDatabaseStatus();
    }

    /**
     * Runs an asynchronous probe against MySQL to show real-time connection status.
     */
    private void checkDatabaseStatus() {
        Task<Boolean> checkDbTask = new Task<>() {
            @Override
            protected Boolean call() {
                return DatabaseConnection.isConnected();
            }
        };

        checkDbTask.setOnSucceeded(e -> {
            boolean connected = checkDbTask.getValue();
            if (connected) {
                lblDbStatus.setText("● Online");
                lblDbStatus.getStyleClass().setAll("db-status-badge", "db-online");
                lblDbDetails.setText("Connected to MySQL (qpanalyser)");
            } else {
                lblDbStatus.setText("● Offline");
                lblDbStatus.getStyleClass().setAll("db-status-badge", "db-offline");
                lblDbDetails.setText("Check MySQL service & db.properties");
            }
        });

        checkDbTask.setOnFailed(e -> {
            lblDbStatus.setText("● Error");
            lblDbStatus.getStyleClass().setAll("db-status-badge", "db-offline");
            lblDbDetails.setText("Connection failed");
        });

        new Thread(checkDbTask, "DB-Status-Checker").start();
    }

    @FXML
    private void handleSwitchToLogin(ActionEvent event) {
        paneLogin.setVisible(true);
        paneLogin.setManaged(true);
        paneRegister.setVisible(false);
        paneRegister.setManaged(false);

        btnTabLogin.getStyleClass().setAll("segmented-btn", "segmented-btn-active");
        btnTabRegister.getStyleClass().setAll("segmented-btn");
        clearMessages();
    }

    @FXML
    private void handleSwitchToRegister(ActionEvent event) {
        paneRegister.setVisible(true);
        paneRegister.setManaged(true);
        paneLogin.setVisible(false);
        paneLogin.setManaged(false);

        btnTabRegister.getStyleClass().setAll("segmented-btn", "segmented-btn-active");
        btnTabLogin.getStyleClass().setAll("segmented-btn");
        clearMessages();
    }

    @FXML
    private void handleLogin(ActionEvent event) {
        String username = txtLoginUsername.getText();
        String password = txtLoginPassword.getText();

        clearMessages();
        btnLogin.setDisable(true);
        btnLogin.setText("Authenticating...");

        Task<User> loginTask = new Task<>() {
            @Override
            protected User call() throws Exception {
                return authService.login(username, password);
            }
        };

        loginTask.setOnSucceeded(e -> {
            btnLogin.setDisable(false);
            btnLogin.setText("Sign In to System");
            User authenticatedUser = loginTask.getValue();

            showLoginSuccess(authenticatedUser);
        });

        loginTask.setOnFailed(e -> {
            btnLogin.setDisable(false);
            btnLogin.setText("Sign In to System");
            Throwable ex = loginTask.getException();
            String error = ex != null ? ex.getMessage() : "Unknown authentication error occurred.";
            showLoginError(error);
        });

        new Thread(loginTask, "Login-Worker").start();
    }

    @FXML
    private void handleRegister(ActionEvent event) {
        String fullName = txtRegFullName.getText();
        Role role = cmbRegRole.getValue();
        String email = txtRegEmail.getText();
        String username = txtRegUsername.getText();
        String password = txtRegPassword.getText();
        String confirmPassword = txtRegConfirmPassword.getText();

        clearMessages();
        btnRegister.setDisable(true);
        btnRegister.setText("Creating Account...");

        Task<User> regTask = new Task<>() {
            @Override
            protected User call() throws Exception {
                return authService.register(username, password, confirmPassword, fullName, email, role);
            }
        };

        regTask.setOnSucceeded(e -> {
            btnRegister.setDisable(false);
            btnRegister.setText("Register Account");
            User newUser = regTask.getValue();

            // Clear registration inputs
            txtRegFullName.clear();
            txtRegEmail.clear();
            txtRegUsername.clear();
            txtRegPassword.clear();
            txtRegConfirmPassword.clear();

            AlertHelper.showInfo(btnLogin.getScene().getWindow(),
                    "Account Created Successfully",
                    "Welcome, " + newUser.getFullName() + "!\nYour account (" + newUser.getUsername() +
                    ") with role " + newUser.getRole().getDisplayName() + " has been saved to MySQL.\nYou can now sign in.");

            // Switch to login tab and prefill username
            handleSwitchToLogin(null);
            txtLoginUsername.setText(newUser.getUsername());
            txtLoginPassword.requestFocus();
        });

        regTask.setOnFailed(e -> {
            btnRegister.setDisable(false);
            btnRegister.setText("Register Account");
            Throwable ex = regTask.getException();
            String error = ex != null ? ex.getMessage() : "Registration failed.";
            showRegError(error);
        });

        new Thread(regTask, "Register-Worker").start();
    }

    @FXML
    private void handleFillDemoTeacher(ActionEvent event) {
        txtLoginUsername.setText("teacher");
        txtLoginPassword.setText("teacher123");
        clearMessages();
    }

    @FXML
    private void handleFillDemoAdmin(ActionEvent event) {
        txtLoginUsername.setText("admin");
        txtLoginPassword.setText("admin123");
        clearMessages();
    }

    private void showLoginSuccess(User user) {
        Stage stage = (Stage) btnLogin.getScene().getWindow();
        SceneNavigator.loadDashboard(stage);
    }

    private void showLoginError(String message) {
        lblLoginMessage.setText(message);
        lblLoginMessage.getStyleClass().setAll("msg-error");
        lblLoginMessage.setVisible(true);
        lblLoginMessage.setManaged(true);
    }

    private void showRegError(String message) {
        lblRegMessage.setText(message);
        lblRegMessage.getStyleClass().setAll("msg-error");
        lblRegMessage.setVisible(true);
        lblRegMessage.setManaged(true);
    }

    private void clearMessages() {
        lblLoginMessage.setVisible(false);
        lblLoginMessage.setManaged(false);
        lblRegMessage.setVisible(false);
        lblRegMessage.setManaged(false);
    }
}
