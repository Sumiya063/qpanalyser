// File: src/main/java/com/qpanalyser/ui/controller/DashboardController.java
package com.qpanalyser.ui.controller;

import com.qpanalyser.exception.DatabaseException;
import com.qpanalyser.exception.InvalidPaperException;
import com.qpanalyser.exception.ParsingException;
import com.qpanalyser.model.Paper;
import com.qpanalyser.model.User;
import com.qpanalyser.service.PaperService;
import com.qpanalyser.service.SessionManager;
import com.qpanalyser.service.parser.DocumentParserFactory;
import com.qpanalyser.ui.util.AlertHelper;
import com.qpanalyser.ui.util.SceneNavigator;
import javafx.application.Platform;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.concurrent.Task;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;
import java.net.URL;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.ResourceBundle;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Controller: Dashboard, Paper Loader and Document Extraction Studio
 * Author: JavaFX Lead
 * 
 * Orchestrates background document parsing via JavaFX Tasks so the UI never freezes.
 * Displays extracted text streams and historical database records.
 */
public class DashboardController implements Initializable {

    @FXML private Label lblCurrentUser;

    // File Ingestion Controls
    @FXML private Button btnChooseFile;
    @FXML private Label lblSelectedFileName;
    @FXML private Label lblFileBadge;
    @FXML private Label lblFileSize;
    @FXML private Button btnParseFile;
    @FXML private ProgressBar progressBar;
    @FXML private Label lblParseStatus;

    // Paper Metadata Fields
    @FXML private TextField txtPaperTitle;
    @FXML private TextField txtSubjectCode;
    @FXML private TextField txtAcademicYear;
    @FXML private TextField txtSemester;
    @FXML private TextField txtTotalMarks;
    @FXML private TextField txtTargetEasy;
    @FXML private TextField txtTargetMedium;
    @FXML private TextField txtTargetHard;

    // Extracted Preview & Metrics
    @FXML private TextArea txtExtractedPreview;
    @FXML private Label lblWordCount;
    @FXML private Label lblCharCount;
    @FXML private Label lblEstimatedQuestions;
    @FXML private Button btnProceedExtraction;

    // Saved History Table
    @FXML private TableView<Paper> tblPapers;
    @FXML private TableColumn<Paper, Integer> colPaperId;
    @FXML private TableColumn<Paper, String> colPaperTitle;
    @FXML private TableColumn<Paper, String> colPaperSubject;
    @FXML private TableColumn<Paper, String> colPaperYear;
    @FXML private TableColumn<Paper, String> colPaperSem;
    @FXML private TableColumn<Paper, Double> colPaperMarks;
    @FXML private TableColumn<Paper, String> colPaperDate;

    private final PaperService paperService;
    private File selectedFile;

    public DashboardController() {
        this.paperService = new PaperService();
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        // Initialize User Greeting
        User currentUser = SessionManager.getInstance().getCurrentUser();
        if (currentUser != null) {
            lblCurrentUser.setText("👤 " + currentUser.getFullName() + " (" + currentUser.getRole().getDisplayName() + ")");
        } else {
            lblCurrentUser.setText("👤 Guest Faculty");
        }

        // Configure Table Columns using Lambdas (OOP / Functional)
        colPaperId.setCellValueFactory(data -> new SimpleIntegerProperty(data.getValue().getId()).asObject());
        colPaperTitle.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getTitle()));
        colPaperSubject.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getSubjectCode()));
        colPaperYear.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getAcademicYear()));
        colPaperSem.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getSemester()));
        colPaperMarks.setCellValueFactory(data -> new SimpleDoubleProperty(data.getValue().getTotalMarks()).asObject());
        
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        colPaperDate.setCellValueFactory(data -> new SimpleStringProperty(
                data.getValue().getCreatedAt() != null ? data.getValue().getCreatedAt().format(dtf) : "N/A"
        ));

        // Text preview live metric listeners
        txtExtractedPreview.textProperty().addListener((obs, oldVal, newVal) -> updateDocumentMetrics(newVal));

        // Load historical papers from MySQL
        loadHistoryFromDatabase();
    }

    @FXML
    private void handleChooseFile(ActionEvent event) {
        FileChooser chooser = new FileChooser();
        chooser.setTitle("Select Question Paper Document");
        chooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("All Supported Question Papers (*.txt, *.pdf, *.docx)", "*.txt", "*.pdf", "*.docx"),
                new FileChooser.ExtensionFilter("Plain Text Files (*.txt)", "*.txt"),
                new FileChooser.ExtensionFilter("Adobe PDF Documents (*.pdf)", "*.pdf"),
                new FileChooser.ExtensionFilter("Microsoft Word Documents (*.docx)", "*.docx")
        );

        Stage stage = (Stage) btnChooseFile.getScene().getWindow();
        File file = chooser.showOpenDialog(stage);

        if (file != null) {
            this.selectedFile = file;
            lblSelectedFileName.setText(file.getName());
            String ext = DocumentParserFactory.getFileExtension(file.getName()).toUpperCase();
            lblFileBadge.setText("FORMAT: " + ext);

            double kb = file.length() / 1024.0;
            if (kb < 1024) {
                lblFileSize.setText(String.format("%.1f KB", kb));
            } else {
                lblFileSize.setText(String.format("%.2f MB", kb / 1024.0));
            }

            btnParseFile.setDisable(false);
            lblParseStatus.setVisible(false);
            lblParseStatus.setManaged(false);
        }
    }

    @FXML
    private void handleParseFile(ActionEvent event) {
        if (selectedFile == null) {
            AlertHelper.showWarning(btnParseFile.getScene().getWindow(), "No File Selected", "Please select a file first.");
            return;
        }

        // Prepare background task to prevent UI freeze
        btnParseFile.setDisable(true);
        progressBar.setVisible(true);
        progressBar.setManaged(true);
        progressBar.setProgress(ProgressBar.INDETERMINATE_PROGRESS);
        lblParseStatus.setText("Parsing document with Apache PDFBox/POI on background thread...");
        lblParseStatus.setVisible(true);
        lblParseStatus.setManaged(true);

        Task<String> parseTask = new Task<>() {
            @Override
            protected String call() throws Exception {
                // Background execution (I/O & PDF/DOCX tokenization)
                return paperService.loadAndParseDocument(selectedFile);
            }
        };

        parseTask.setOnSucceeded(e -> {
            progressBar.setVisible(false);
            progressBar.setManaged(false);
            btnParseFile.setDisable(false);

            String parsedText = parseTask.getValue();
            txtExtractedPreview.setText(parsedText);

            lblParseStatus.setText("✓ Document parsed successfully! Ready for question extraction.");
            lblParseStatus.setStyle("-fx-text-fill: #16a34a; -fx-font-weight: bold;");
            btnProceedExtraction.setDisable(false);
        });

        parseTask.setOnFailed(e -> {
            progressBar.setVisible(false);
            progressBar.setManaged(false);
            btnParseFile.setDisable(false);

            Throwable ex = parseTask.getException();
            String error = ex != null ? ex.getMessage() : "Unknown parsing error";
            lblParseStatus.setText("✗ Failed to parse document.");
            lblParseStatus.setStyle("-fx-text-fill: #dc2626; -fx-font-weight: bold;");

            AlertHelper.showError(btnParseFile.getScene().getWindow(), "Document Parsing Error", error);
        });

        new Thread(parseTask, "Document-Parser-Thread").start();
    }

    @FXML
    private void handleLoadSamplePaper(ActionEvent event) {
        // Pre-populate with realistic CSE203 examination questions covering Bloom Taxonomy & difficulty tiers
        String samplePaper = """
                DEPARTMENT OF COMPUTER SCIENCE AND ENGINEERING
                CSE203: OBJECT ORIENTED PROGRAMMING USING JAVA
                END-SEMESTER EXAMINATION 2026
                Duration: 3 Hours                                                    Max Marks: 100
                -----------------------------------------------------------------------------------
                
                SECTION A: SHORT CONCEPTS (Remember & Understand)
                Q1. Define the four fundamental principles of Object-Oriented Programming: Encapsulation, Abstraction, Inheritance, and Polymorphism. [5]
                Q2. Explain the purpose of the 'final' keyword in Java when applied to variables, methods, and classes. [5]
                Q3. Describe the difference between method overloading and method overriding with suitable code fragments. [5]
                Q4. List the major differences between an Abstract Class and an Interface in Java 21. [5]
                
                SECTION B: APPLICATION & PROBLEM SOLVING (Apply & Analyze)
                Q5. Write a Java program to implement a generic Stack<T> data structure using an array, with push, pop, and peek methods. Include custom StackOverflowException. [10]
                Q6. Calculate the time complexity of searching in a Trie compared to a HashMap. Write a recursive method to traverse all words in a Trie. [10]
                Q7. Differentiate between checked and unchecked exceptions in Java. How does the try-with-resources statement guarantee resource deallocation? [10]
                Q8. Implement the Singleton design pattern in Java using thread-safe double-checked locking with the volatile keyword. Explain why double-checked locking is required. [10]
                
                SECTION C: DESIGN & EVALUATION (Analyze, Evaluate & Create)
                Q9. Design an Employee Payroll System using Polymorphism and the Strategy Design Pattern for bonus calculation. Provide classes for SalariedEmployee, HourlyEmployee, and CommissionEmployee. [15]
                Q10. Compare the performance characteristics of ArrayList, LinkedList, and PriorityQueue for queue processing. Evaluate their Big-O complexities for insertion and deletion. [15]
                Q11. Create a complete producer-consumer application using Java BlockingQueue and multithreading. Justify how thread synchronization prevents race conditions and deadlocks. [15]
                """;

        txtExtractedPreview.setText(samplePaper);
        txtPaperTitle.setText("CSE203 OOP Java End-Semester Exam 2026");
        txtSubjectCode.setText("CSE203");
        txtTotalMarks.setText("100");
        btnProceedExtraction.setDisable(false);
    }

    @FXML
    private void handleResetTargetRatio(ActionEvent event) {
        txtTargetEasy.setText("30");
        txtTargetMedium.setText("50");
        txtTargetHard.setText("20");
    }

    @FXML
    private void handleClearPreview(ActionEvent event) {
        txtExtractedPreview.clear();
        btnProceedExtraction.setDisable(true);
        lblParseStatus.setVisible(false);
        lblParseStatus.setManaged(false);
    }

    @FXML
    private void handleProceedToExtraction(ActionEvent event) {
        String content = txtExtractedPreview.getText();
        if (content == null || content.trim().isEmpty()) {
            AlertHelper.showWarning(btnProceedExtraction.getScene().getWindow(), "Empty Content", "Please load and parse a question paper first.");
            return;
        }

        // Validate metadata
        String title = txtPaperTitle.getText();
        String subject = txtSubjectCode.getText();
        String year = txtAcademicYear.getText();
        String semester = txtSemester.getText();

        double totalMarks;
        try {
            totalMarks = Double.parseDouble(txtTotalMarks.getText().trim());
        } catch (NumberFormatException e) {
            totalMarks = 100.0;
        }

        double targetEasy = parseDouble(txtTargetEasy.getText(), 30.0);
        double targetMedium = parseDouble(txtTargetMedium.getText(), 50.0);
        double targetHard = parseDouble(txtTargetHard.getText(), 20.0);

        User user = SessionManager.getInstance().getCurrentUser();
        int userId = user != null ? user.getId() : 1;

        try {
            Paper paper = paperService.createPaper(title, subject, year, semester, totalMarks, targetEasy, targetMedium, targetHard, userId);
            
            // Transfer state to Review Screen and transition
            ReviewController.setTransferData(paper, content);
            Stage stage = (Stage) btnProceedExtraction.getScene().getWindow();
            SceneNavigator.loadReview(stage);

        } catch (Exception e) {
            AlertHelper.showError(btnProceedExtraction.getScene().getWindow(), "Database Error", "Failed to save paper: " + e.getMessage());
        }
    }

    @FXML
    private void handleRefreshHistory(ActionEvent event) {
        loadHistoryFromDatabase();
    }

    @FXML
    private void handleLogout(ActionEvent event) {
        SessionManager.getInstance().logout();
        Stage stage = (Stage) lblCurrentUser.getScene().getWindow();
        SceneNavigator.loadLogin(stage);
    }

    @FXML
    private void handleOpenSettings(ActionEvent event) {
        Stage stage = (Stage) lblCurrentUser.getScene().getWindow();
        SceneNavigator.loadSettings(stage);
    }

    @FXML
    private void handleOpenCompare(ActionEvent event) {
        Stage stage = (Stage) lblCurrentUser.getScene().getWindow();
        SceneNavigator.loadCompare(stage);
    }

    private void updateDocumentMetrics(String text) {
        if (text == null || text.trim().isEmpty()) {
            lblWordCount.setText("Words: 0");
            lblCharCount.setText("Characters: 0");
            lblEstimatedQuestions.setText("Est. Questions: 0");
            return;
        }

        int charCount = text.length();
        int wordCount = text.trim().split("\\s+").length;

        // Heuristic count for question indicators (e.g. Q1., 1., (a), Question 1)
        Pattern pattern = Pattern.compile("(?m)^(?:Q(?:uestion)?\\s*\\d+|\\d+[\\.\\)])", Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(text);
        int estQuestions = 0;
        while (matcher.find()) {
            estQuestions++;
        }

        lblWordCount.setText("Words: " + wordCount);
        lblCharCount.setText("Characters: " + charCount);
        lblEstimatedQuestions.setText("Est. Questions: " + (estQuestions > 0 ? estQuestions : "N/A"));
    }

    private void loadHistoryFromDatabase() {
        Task<List<Paper>> loadTask = new Task<>() {
            @Override
            protected List<Paper> call() throws Exception {
                User user = SessionManager.getInstance().getCurrentUser();
                int userId = user != null ? user.getId() : 1;
                return paperService.getPapersForUser(userId);
            }
        };

        loadTask.setOnSucceeded(e -> {
            List<Paper> papers = loadTask.getValue();
            tblPapers.setItems(FXCollections.observableArrayList(papers));
        });

        loadTask.setOnFailed(e -> {
            // Silently log or show empty list if DB is offline
            tblPapers.setItems(FXCollections.observableArrayList());
        });

        new Thread(loadTask, "History-Loader-Thread").start();
    }

    private double parseDouble(String text, double defaultValue) {
        try {
            return Double.parseDouble(text.trim());
        } catch (Exception e) {
            return defaultValue;
        }
    }
}
