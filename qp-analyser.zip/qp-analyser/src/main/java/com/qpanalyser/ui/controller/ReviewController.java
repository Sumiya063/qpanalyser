// File: src/main/java/com/qpanalyser/ui/controller/ReviewController.java
package com.qpanalyser.ui.controller;

import com.qpanalyser.dao.QuestionDAO;
import com.qpanalyser.model.Paper;
import com.qpanalyser.model.Question;
import com.qpanalyser.model.QuestionFactory;
import com.qpanalyser.model.QuestionType;
import com.qpanalyser.service.QuestionReviewService;
import com.qpanalyser.service.SessionManager;
import com.qpanalyser.service.undo.UndoManager;
import com.qpanalyser.ui.util.AlertHelper;
import com.qpanalyser.ui.util.SceneNavigator;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.control.cell.ComboBoxTableCell;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import javafx.util.converter.DoubleStringConverter;
import javafx.util.converter.IntegerStringConverter;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;

/**
 * Controller: Question Paper Review, Editing, Splitting, Merging & Undo
 * Author: JavaFX Lead
 * 
 * Manages the interactive TableView with live cell editing, multiple row selection,
 * and command-based Undo/Redo operations backed by the custom UndoStack.
 */
public class ReviewController implements Initializable {

    // Global transfer container for navigating between scenes
    private static Paper transferPaper;
    private static String transferRawText;

    @FXML private Label lblPaperMeta;
    @FXML private Label lblCurrentUser;

    // Action Controls
    @FXML private Button btnUndo;
    @FXML private Button btnRedo;
    @FXML private Label lblUndoStatus;

    // Table View & Columns
    @FXML private TableView<Question> tblQuestions;
    @FXML private TableColumn<Question, String> colNum;
    @FXML private TableColumn<Question, String> colSection;
    @FXML private TableColumn<Question, String> colText;
    @FXML private TableColumn<Question, QuestionType> colType;
    @FXML private TableColumn<Question, Double> colMarks;
    @FXML private TableColumn<Question, Integer> colSubParts;
    @FXML private TableColumn<Question, String> colEstimatedTime;

    // Summary Elements
    @FXML private Label lblQuestionCount;
    @FXML private Label lblMarksAllocated;
    @FXML private Label lblMarksWarning;
    @FXML private Button btnProceedAnalysis;

    private final QuestionReviewService reviewService;
    private final UndoManager undoManager;
    private final QuestionDAO questionDAO;

    private ObservableList<Question> observableQuestions;
    private Paper currentPaper;

    public ReviewController() {
        this.reviewService = new QuestionReviewService();
        this.undoManager = new UndoManager(50);
        this.questionDAO = new QuestionDAO();
    }

    public static void setTransferData(Paper paper, String rawText) {
        transferPaper = paper;
        transferRawText = rawText;
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        this.currentPaper = transferPaper != null ? transferPaper : new Paper();

        // User info
        var currentUser = SessionManager.getInstance().getCurrentUser();
        lblCurrentUser.setText("👤 " + (currentUser != null ? currentUser.getFullName() : "Faculty Member"));
        lblPaperMeta.setText("Paper: " + currentPaper.getTitle() + " | Subject: " + currentPaper.getSubjectCode());

        // Setup ObservableList & TableView
        observableQuestions = FXCollections.observableArrayList();
        tblQuestions.setItems(observableQuestions);
        tblQuestions.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);

        setupTableColumns();

        // Populate questions from raw text extraction or existing paper
        if (transferRawText != null && !transferRawText.trim().isEmpty()) {
            try {
                List<Question> extracted = reviewService.extract(transferRawText);
                observableQuestions.addAll(extracted);
                currentPaper.setQuestions(new ArrayList<>(extracted));
            } catch (Exception e) {
                AlertHelper.showError(null, "Extraction Error", "Failed to extract questions: " + e.getMessage());
            }
        }

        updateSummaryMetrics();
        updateUndoRedoButtonStates();
    }

    /**
     * Configures TableView columns with in-place cell editing.
     */
    private void setupTableColumns() {
        // Question Number
        colNum.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getQuestionNumber()));
        colNum.setCellFactory(TextFieldTableCell.forTableColumn());
        colNum.setOnEditCommit(event -> {
            Question q = event.getRowValue();
            q.setQuestionNumber(event.getNewValue());
        });

        // Section
        colSection.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getSection()));
        colSection.setCellFactory(TextFieldTableCell.forTableColumn());
        colSection.setOnEditCommit(event -> {
            Question q = event.getRowValue();
            reviewService.editQuestion(q, q.getQuestionText(), q.getMarks(), event.getNewValue(), q.getSubPartCount(), undoManager);
            updateUndoRedoButtonStates();
        });

        // Question Text (Multiline Editing)
        colText.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getQuestionText()));
        colText.setCellFactory(TextFieldTableCell.forTableColumn());
        colText.setOnEditCommit(event -> {
            Question q = event.getRowValue();
            reviewService.editQuestion(q, event.getNewValue(), q.getMarks(), q.getSection(), q.getSubPartCount(), undoManager);
            tblQuestions.refresh();
            updateUndoRedoButtonStates();
        });

        // Question Type (Dropdown Selector)
        colType.setCellValueFactory(data -> new SimpleObjectProperty<>(data.getValue().getQuestionType()));
        colType.setCellFactory(ComboBoxTableCell.forTableColumn(QuestionType.values()));
        colType.setOnEditCommit(event -> {
            Question oldQ = event.getRowValue();
            QuestionType newType = event.getNewValue();
            if (newType != oldQ.getQuestionType()) {
                Question newQ = QuestionFactory.createQuestion(
                        newType, oldQ.getQuestionNumber(), oldQ.getQuestionText(), oldQ.getMarks(), oldQ.getSection()
                );
                newQ.setSubPartCount(oldQ.getSubPartCount());
                int idx = observableQuestions.indexOf(oldQ);
                observableQuestions.set(idx, newQ);
                tblQuestions.refresh();
                updateSummaryMetrics();
            }
        });

        // Marks (Editable Double with live recalculation)
        colMarks.setCellValueFactory(data -> new SimpleDoubleProperty(data.getValue().getMarks()).asObject());
        colMarks.setCellFactory(TextFieldTableCell.forTableColumn(new DoubleStringConverter()));
        colMarks.setOnEditCommit(event -> {
            Question q = event.getRowValue();
            double newMark = event.getNewValue() != null ? Math.max(0.5, event.getNewValue()) : 5.0;
            reviewService.editQuestion(q, q.getQuestionText(), newMark, q.getSection(), q.getSubPartCount(), undoManager);
            tblQuestions.refresh();
            updateSummaryMetrics();
            updateUndoRedoButtonStates();
        });

        // Sub-parts count
        colSubParts.setCellValueFactory(data -> new SimpleIntegerProperty(data.getValue().getSubPartCount()).asObject());
        colSubParts.setCellFactory(TextFieldTableCell.forTableColumn(new IntegerStringConverter()));
        colSubParts.setOnEditCommit(event -> {
            Question q = event.getRowValue();
            int parts = event.getNewValue() != null ? Math.max(1, event.getNewValue()) : 1;
            reviewService.editQuestion(q, q.getQuestionText(), q.getMarks(), q.getSection(), parts, undoManager);
            tblQuestions.refresh();
            updateSummaryMetrics();
            updateUndoRedoButtonStates();
        });

        // Polymorphic Estimated Time Calculation
        colEstimatedTime.setCellValueFactory(data -> new SimpleStringProperty(
                String.format("%.1f min", data.getValue().calculateEstimatedAnsweringTimeMinutes())
        ));
    }

    @FXML
    private void handleUndo(ActionEvent event) {
        String action = undoManager.undo();
        if (action != null) {
            tblQuestions.refresh();
            updateSummaryMetrics();
            updateUndoRedoButtonStates();
        }
    }

    @FXML
    private void handleRedo(ActionEvent event) {
        String action = undoManager.redo();
        if (action != null) {
            tblQuestions.refresh();
            updateSummaryMetrics();
            updateUndoRedoButtonStates();
        }
    }

    @FXML
    private void handleAddQuestion(ActionEvent event) {
        int nextNum = observableQuestions.size() + 1;
        Question newQ = QuestionFactory.createQuestion(
                QuestionType.SHORT_ANSWER, "Q" + nextNum, "New question description...", 5.0, "Section A"
        );
        reviewService.addQuestion(observableQuestions, newQ, observableQuestions.size(), undoManager);
        tblQuestions.getSelectionModel().select(newQ);
        updateSummaryMetrics();
        updateUndoRedoButtonStates();
    }

    @FXML
    private void handleDeleteSelected(ActionEvent event) {
        List<Question> selected = new ArrayList<>(tblQuestions.getSelectionModel().getSelectedItems());
        if (selected.isEmpty()) {
            AlertHelper.showWarning(tblQuestions.getScene().getWindow(), "No Selection", "Please select a question to delete.");
            return;
        }

        for (Question q : selected) {
            reviewService.deleteQuestion(observableQuestions, q, undoManager);
        }
        updateSummaryMetrics();
        updateUndoRedoButtonStates();
    }

    @FXML
    private void handleMergeSelected(ActionEvent event) {
        List<Question> selected = tblQuestions.getSelectionModel().getSelectedItems();
        if (selected.size() != 2) {
            AlertHelper.showWarning(tblQuestions.getScene().getWindow(), "Invalid Selection for Merge",
                    "Please select exactly two questions from the table to merge them.\n(Hold Ctrl or Shift to select two rows)");
            return;
        }

        Question q1 = selected.get(0);
        Question q2 = selected.get(1);

        reviewService.mergeQuestions(observableQuestions, q1, q2, undoManager);
        tblQuestions.refresh();
        updateSummaryMetrics();
        updateUndoRedoButtonStates();
    }

    @FXML
    private void handleSplitSelected(ActionEvent event) {
        Question selected = tblQuestions.getSelectionModel().getSelectedItem();
        if (selected == null) {
            AlertHelper.showWarning(tblQuestions.getScene().getWindow(), "No Question Selected", "Please select a question to split.");
            return;
        }

        // Show Split Dialog
        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.setTitle("Split Question " + selected.getQuestionNumber());
        dialog.setHeaderText("Divide question text and marks between two sub-questions");

        ButtonType btnSplitType = new ButtonType("Split Question", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(btnSplitType, ButtonType.CANCEL);

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20, 20, 10, 10));

        TextArea txtPart1 = new TextArea(selected.getQuestionText());
        txtPart1.setPrefRowCount(3);
        txtPart1.setWrapText(true);

        TextArea txtPart2 = new TextArea("Part B description...");
        txtPart2.setPrefRowCount(3);
        txtPart2.setWrapText(true);

        double halfMarks = Math.round((selected.getMarks() / 2.0) * 10.0) / 10.0;
        TextField txtPart1Marks = new TextField(String.valueOf(halfMarks));
        TextField txtPart2Marks = new TextField(String.valueOf(selected.getMarks() - halfMarks));

        grid.add(new Label("Sub-Part (a) Text:"), 0, 0);
        grid.add(txtPart1, 1, 0);
        grid.add(new Label("Sub-Part (a) Marks:"), 0, 1);
        grid.add(txtPart1Marks, 1, 1);

        grid.add(new Label("Sub-Part (b) Text:"), 0, 2);
        grid.add(txtPart2, 1, 2);
        grid.add(new Label("Sub-Part (b) Marks:"), 0, 3);
        grid.add(txtPart2Marks, 1, 3);

        dialog.getDialogPane().setContent(grid);

        Optional<ButtonType> result = dialog.showAndWait();
        if (result.isPresent() && result.get() == btnSplitType) {
            try {
                double m1 = Double.parseDouble(txtPart1Marks.getText().trim());
                double m2 = Double.parseDouble(txtPart2Marks.getText().trim());

                reviewService.splitQuestion(observableQuestions, selected, txtPart1.getText().trim(),
                        txtPart2.getText().trim(), m1, m2, undoManager);

                tblQuestions.refresh();
                updateSummaryMetrics();
                updateUndoRedoButtonStates();
            } catch (NumberFormatException e) {
                AlertHelper.showError(tblQuestions.getScene().getWindow(), "Invalid Marks", "Please enter valid numeric mark values.");
            }
        }
    }

    @FXML
    private void handleRenumberQuestions(ActionEvent event) {
        reviewService.renumberQuestions(observableQuestions);
        tblQuestions.refresh();
    }

    @FXML
    private void handleSaveQuestionsToDb(ActionEvent event) {
        if (observableQuestions.isEmpty()) {
            AlertHelper.showWarning(tblQuestions.getScene().getWindow(), "No Questions", "There are no questions to save.");
            return;
        }

        try {
            int paperId = currentPaper.getId() > 0 ? currentPaper.getId() : 1;
            questionDAO.saveAll(new ArrayList<>(observableQuestions), paperId);

            AlertHelper.showInfo(tblQuestions.getScene().getWindow(),
                    "Saved to MySQL",
                    "All " + observableQuestions.size() + " questions have been successfully saved to MySQL for Paper ID #" + paperId + "!");

        } catch (Exception e) {
            AlertHelper.showError(tblQuestions.getScene().getWindow(), "Database Save Error", "Failed to persist questions: " + e.getMessage());
        }
    }

    @FXML
    private void handleProceedToAnalysis(ActionEvent event) {
        if (observableQuestions.isEmpty()) {
            AlertHelper.showWarning(tblQuestions.getScene().getWindow(), "Empty Paper", "Please ensure at least one question exists before analyzing.");
            return;
        }

        currentPaper.setQuestions(new ArrayList<>(observableQuestions));
        btnProceedAnalysis.setDisable(true);

        javafx.concurrent.Task<com.qpanalyser.model.AnalysisResult> analysisTask = new javafx.concurrent.Task<>() {
            @Override
            protected com.qpanalyser.model.AnalysisResult call() throws Exception {
                com.qpanalyser.service.PaperAnalysisService service = new com.qpanalyser.service.PaperAnalysisService();
                return service.analyzePaper(currentPaper);
            }
        };

        analysisTask.setOnSucceeded(e -> {
            btnProceedAnalysis.setDisable(false);
            com.qpanalyser.model.AnalysisResult result = analysisTask.getValue();
            ResultsController.setTransferData(currentPaper, result);
            Stage stage = (Stage) tblQuestions.getScene().getWindow();
            SceneNavigator.loadResults(stage);
        });

        analysisTask.setOnFailed(e -> {
            btnProceedAnalysis.setDisable(false);
            Throwable ex = analysisTask.getException();
            AlertHelper.showError(tblQuestions.getScene().getWindow(), "Analysis Error",
                    "An error occurred while analyzing the paper: " + (ex != null ? ex.getMessage() : "Unknown"));
        });

        Thread thread = new Thread(analysisTask, "AnalysisTaskThread");
        thread.setDaemon(true);
        thread.start();
    }

    @FXML
    private void handleBackToDashboard(ActionEvent event) {
        Stage stage = (Stage) lblCurrentUser.getScene().getWindow();
        SceneNavigator.loadDashboard(stage);
    }

    private void updateSummaryMetrics() {
        int count = observableQuestions.size();
        double totalMarks = observableQuestions.stream().mapToDouble(Question::getMarks).sum();
        double target = currentPaper.getTotalMarks() > 0 ? currentPaper.getTotalMarks() : 100.0;

        lblQuestionCount.setText(count + " Questions");
        lblMarksAllocated.setText(String.format("%.1f / %.1f Marks", totalMarks, target));

        if (Math.abs(totalMarks - target) < 0.01) {
            lblMarksAllocated.setStyle("-fx-text-fill: #16a34a; -fx-font-weight: bold;");
            lblMarksWarning.setText("✓ Marks perfectly balanced with target!");
            lblMarksWarning.setStyle("-fx-text-fill: #16a34a;");
        } else if (totalMarks < target) {
            lblMarksAllocated.setStyle("-fx-text-fill: #ea580c; -fx-font-weight: bold;");
            lblMarksWarning.setText(String.format("⚠ Deficit of %.1f marks from target", target - totalMarks));
            lblMarksWarning.setStyle("-fx-text-fill: #ea580c;");
        } else {
            lblMarksAllocated.setStyle("-fx-text-fill: #dc2626; -fx-font-weight: bold;");
            lblMarksWarning.setText(String.format("⚠ Excess of %.1f marks over target", totalMarks - target));
            lblMarksWarning.setStyle("-fx-text-fill: #dc2626;");
        }
    }

    private void updateUndoRedoButtonStates() {
        btnUndo.setDisable(!undoManager.canUndo());
        btnRedo.setDisable(!undoManager.canRedo());
        lblUndoStatus.setText("Undo History: " + undoManager.getUndoCount() + " steps");
    }
}
