// File: src/main/java/com/qpanalyser/ui/util/SceneNavigator.java
package com.qpanalyser.ui.util;

import com.qpanalyser.app.AppConfig;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;

/**
 * UI Navigation Helper
 * Author: JavaFX Lead
 * 
 * Manages scene switching and transitions between views (Login, Dashboard, Review, Results).
 */
public final class SceneNavigator {

    private SceneNavigator() {
    }

    public static void navigate(Stage stage, String fxmlPath, String windowTitle) {
        try {
            URL url = SceneNavigator.class.getResource(fxmlPath);
            if (url == null) {
                System.err.println("Could not find FXML at: " + fxmlPath);
                return;
            }

            FXMLLoader loader = new FXMLLoader(url);
            Parent root = loader.load();

            Scene currentScene = stage.getScene();
            if (currentScene != null) {
                currentScene.setRoot(root);
            } else {
                Scene scene = new Scene(root, AppConfig.DEFAULT_WINDOW_WIDTH, AppConfig.DEFAULT_WINDOW_HEIGHT);
                stage.setScene(scene);
            }

            if (windowTitle != null) {
                stage.setTitle(windowTitle + " - " + AppConfig.APP_NAME);
            }
            stage.show();

        } catch (IOException e) {
            System.err.println("Failed to load view [" + fxmlPath + "]: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public static void loadLogin(Stage stage) {
        navigate(stage, "/com/qpanalyser/ui/view/login.fxml", "Sign In");
    }

    public static void loadDashboard(Stage stage) {
        navigate(stage, "/com/qpanalyser/ui/view/dashboard.fxml", "Dashboard & Paper Loader");
    }

    public static void loadReview(Stage stage) {
        navigate(stage, "/com/qpanalyser/ui/view/review.fxml", "Review & Refine Questions");
    }

    public static void loadResults(Stage stage) {
        navigate(stage, "/com/qpanalyser/ui/view/results.fxml", "Analysis Results");
    }

    public static void loadSettings(Stage stage) {
        navigate(stage, "/com/qpanalyser/ui/view/settings.fxml", "Settings");
    }

    public static void loadCompare(Stage stage) {
        navigate(stage, "/com/qpanalyser/ui/view/compare.fxml", "Compare Papers");
    }
}
