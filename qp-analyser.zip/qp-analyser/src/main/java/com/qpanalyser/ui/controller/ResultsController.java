// File: src/main/java/com/qpanalyser/ui/controller/ResultsController.java
package com.qpanalyser.ui.controller;

import com.qpanalyser.dsa.DuplicateDetector;
import com.qpanalyser.dsa.QuestionRanker;
import com.qpanalyser.dsa.QuestionSort;
import com.qpanalyser.model.AnalysisResult;
import com.qpanalyser.model.BloomLevel;
import com.qpanalyser.model.DifficultyLevel;
import com.qpanalyser.model.Paper;
import com.qpanalyser.model.Question;
import com.qpanalyser.ui.util.AlertHelper;
import com.qpanalyser.ui.util.SceneNavigator;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.*;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

/**
 * Controller: Results and Analytical Visualizations
 * Author: JavaFX Lead
 * 
 * Displays PieChart and BarChart for Bloom's Taxonomy & Difficulty distribution,
 * colour-coded TableView with MergeSort ranking, Top-N hardest questions via PriorityQueue,
 * and pedagogical balance suggestions.
 */
public class ResultsController implements Initializable {

    private static Paper transferPaper;
    private static AnalysisResult transferResult;

    @FXML private Label lblPaperTitle;
    @FXML private Label lblOverallDifficulty;
    @FXML private Label lblBalanceVerdict;
    @FXML private Label lblEasyPct;
    @FXML private Label lblMediumPct;
    @FXML private Label lblHardPct;

    @FXML private PieChart chartDifficulty;
    @FXML private BarChart<String, Number> chartBloom;

    @FXML private TableView<Question> tblRankedQuestions;
    @FXML private TableColumn<Question, String> colRank;
    @FXML private TableColumn<Question, String> colQNum;
    @FXML private TableColumn<Question, String> colText;
    @FXML private TableColumn<Question, Double> colMarks;
    @FXML private TableColumn<Question, String> colBloom;
    @FXML private TableColumn<Question, Double> colDifficulty;
    @FXML private TableColumn<Question, String> colLevel;

    @FXML private ListView<String> listHardestQuestions;
    @FXML private TextArea txtSuggestions;

    public static void setTransferData(Paper paper, AnalysisResult result) {
        transferPaper = paper;
        transferResult = result;
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        if (transferPaper == null || transferResult == null) {
            return;
        }

        lblPaperTitle.setText(transferPaper.getTitle() != null ? transferPaper.getTitle() : "Question Paper Analysis");
        lblOverallDifficulty.setText(String.format("%.1f / 100", transferResult.getOverallDifficultyIndex()));
        lblBalanceVerdict.setText(transferResult.getBalanceVerdict());
        lblEasyPct.setText(String.format("%.1f%%", transferResult.getEasyPercentage()));
        lblMediumPct.setText(String.format("%.1f%%", transferResult.getMediumPercentage()));
        lblHardPct.setText(String.format("%.1f%%", transferResult.getHardPercentage()));
        txtSuggestions.setText(transferResult.getSuggestions());

        setupCharts();
        setupRankedTable();
        setupHardestQuestionsList();
    }

    private void setupCharts() {
        // 1. Difficulty Pie Chart
        ObservableList<PieChart.Data> pieData = FXCollections.observableArrayList(
                new PieChart.Data("Easy (" + transferResult.getEasyPercentage() + "%)", transferResult.getEasyPercentage()),
                new PieChart.Data("Medium (" + transferResult.getMediumPercentage() + "%)", transferResult.getMediumPercentage()),
                new PieChart.Data("Hard (" + transferResult.getHardPercentage() + "%)", transferResult.getHardPercentage())
        );
        chartDifficulty.setData(pieData);

        // 2. Bloom Bar Chart
        XYChart.Series<String, Number> series = new XYChart.Series<>();
        series.setName("Bloom Distribution");
        series.getData().add(new XYChart.Data<>("Remember", transferResult.getRememberCount()));
        series.getData().add(new XYChart.Data<>("Understand", transferResult.getUnderstandCount()));
        series.getData().add(new XYChart.Data<>("Apply", transferResult.getApplyCount()));
        series.getData().add(new XYChart.Data<>("Analyze", transferResult.getAnalyzeCount()));
        series.getData().add(new XYChart.Data<>("Evaluate", transferResult.getEvaluateCount()));
        series.getData().add(new XYChart.Data<>("Create", transferResult.getCreateCount()));
        chartBloom.getData().clear();
        chartBloom.getData().add(series);
    }

    private void setupRankedTable() {
        colQNum.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getQuestionNumber()));
        colText.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getQuestionText()));
        colMarks.setCellValueFactory(c -> new SimpleDoubleProperty(c.getValue().getMarks()).asObject());
        colBloom.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getBloomLevel() != null ? c.getValue().getBloomLevel().name() : "N/A"));
        colDifficulty.setCellValueFactory(c -> new SimpleDoubleProperty(c.getValue().getDifficultyScore()).asObject());
        colLevel.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getDifficultyLevel() != null ? c.getValue().getDifficultyLevel().name() : "N/A"));

        // Use custom MergeSort to order questions descending by difficulty score
        List<Question> sorted = QuestionSort.mergeSort(transferPaper.getQuestions(), false);
        colRank.setCellValueFactory(c -> new SimpleStringProperty("#" + (sorted.indexOf(c.getValue()) + 1)));

        // Color-code difficulty rows
        colLevel.setCellFactory(col -> new TableCell<>() {
            @Override
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                    setStyle("");
                } else {
                    setText(item);
                    if ("HARD".equalsIgnoreCase(item)) {
                        setStyle("-fx-text-fill: #dc2626; -fx-font-weight: bold;");
                    } else if ("MEDIUM".equalsIgnoreCase(item)) {
                        setStyle("-fx-text-fill: #d97706; -fx-font-weight: bold;");
                    } else {
                        setStyle("-fx-text-fill: #16a34a; -fx-font-weight: bold;");
                    }
                }
            }
        });

        tblRankedQuestions.setItems(FXCollections.observableArrayList(sorted));
    }

    private void setupHardestQuestionsList() {
        // DSA: PriorityQueue Top-N Min Heap
        List<Question> hardest = QuestionRanker.getTopNHardestQuestions(transferPaper.getQuestions(), 5);
        ObservableList<String> items = FXCollections.observableArrayList();
        int rank = 1;
        for (Question q : hardest) {
            items.add(String.format("#%d [%s | Score: %.1f | %s] %s",
                    rank++, q.getQuestionNumber(), q.getDifficultyScore(),
                    q.getBloomLevel(), q.getQuestionText()));
        }
        listHardestQuestions.setItems(items);
    }

    @FXML
    private void handleExportReport(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Export Analysis Report");
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("CSV File (*.csv)", "*.csv"),
                new FileChooser.ExtensionFilter("Text Report (*.txt)", "*.txt")
        );
        fileChooser.setInitialFileName("Analysis_Report_" + System.currentTimeMillis() + ".csv");
        File file = fileChooser.showSaveDialog(lblPaperTitle.getScene().getWindow());

        if (file != null) {
            try (FileWriter writer = new FileWriter(file)) {
                if (file.getName().endsWith(".csv")) {
                    writer.write("Question No,Question Text,Type,Marks,Bloom Level,Difficulty Score,Difficulty Level\n");
                    for (Question q : transferPaper.getQuestions()) {
                        writer.write(String.format("\"%s\",\"%s\",\"%s\",%.1f,\"%s\",%.1f,\"%s\"\n",
                                q.getQuestionNumber(),
                                q.getQuestionText().replace("\"", "\"\""),
                                q.getQuestionType(),
                                q.getMarks(),
                                q.getBloomLevel(),
                                q.getDifficultyScore(),
                                q.getDifficultyLevel()
                        ));
                    }
                } else {
                    writer.write("====================================================\n");
                    writer.write("    AI QUESTION PAPER DIFFICULTY ANALYSIS REPORT    \n");
                    writer.write("====================================================\n\n");
                    writer.write("Paper Title: " + transferPaper.getTitle() + "\n");
                    writer.write("Overall Difficulty Index: " + transferResult.getOverallDifficultyIndex() + " / 100\n");
                    writer.write("Verdict: " + transferResult.getBalanceVerdict() + "\n");
                    writer.write(String.format("Easy: %.1f%% | Medium: %.1f%% | Hard: %.1f%%\n\n",
                            transferResult.getEasyPercentage(), transferResult.getMediumPercentage(), transferResult.getHardPercentage()));
                    writer.write("Pedagogical Suggestions:\n" + transferResult.getSuggestions() + "\n\n");
                    writer.write("----------------------------------------------------\n");
                    for (Question q : transferPaper.getQuestions()) {
                        writer.write(String.format("[%s] (%s, %.1f Marks, Bloom: %s, Score: %.1f [%s])\n%s\n\n",
                                q.getQuestionNumber(), q.getQuestionType(), q.getMarks(), q.getBloomLevel(),
                                q.getDifficultyScore(), q.getDifficultyLevel(), q.getQuestionText()));
                    }
                }
                AlertHelper.showInfo(lblPaperTitle.getScene().getWindow(), "Export Successful", "Report exported to: " + file.getAbsolutePath());
            } catch (IOException e) {
                AlertHelper.showError(lblPaperTitle.getScene().getWindow(), "Export Failed", e.getMessage());
            }
        }
    }

    @FXML
    private void handleBackToDashboard(ActionEvent event) {
        Stage stage = (Stage) lblPaperTitle.getScene().getWindow();
        SceneNavigator.loadDashboard(stage);
    }
}
