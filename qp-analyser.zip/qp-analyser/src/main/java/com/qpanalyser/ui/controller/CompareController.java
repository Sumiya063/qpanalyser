// File: src/main/java/com/qpanalyser/ui/controller/CompareController.java
package com.qpanalyser.ui.controller;

import com.qpanalyser.dao.AnalysisResultDAO;
import com.qpanalyser.dao.PaperDAO;
import com.qpanalyser.exception.DatabaseException;
import com.qpanalyser.model.AnalysisResult;
import com.qpanalyser.model.Paper;
import com.qpanalyser.ui.util.AlertHelper;
import com.qpanalyser.ui.util.SceneNavigator;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import javafx.util.StringConverter;

import java.net.URL;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;

/**
 * Controller: Compare Two Question Papers
 * Author: JavaFX Lead
 * 
 * Side-by-side comparative analysis of two papers: Difficulty scores,
 * Bloom distributions, and balance verdicts.
 */
public class CompareController implements Initializable {

    @FXML private ComboBox<Paper> cmbPaperA;
    @FXML private ComboBox<Paper> cmbPaperB;

    @FXML private Label lblTitleA;
    @FXML private Label lblScoreA;
    @FXML private Label lblVerdictA;
    @FXML private Label lblDistributionA;

    @FXML private Label lblTitleB;
    @FXML private Label lblScoreB;
    @FXML private Label lblVerdictB;
    @FXML private Label lblDistributionB;

    @FXML private BarChart<String, Number> chartComparison;

    private final PaperDAO paperDAO = new PaperDAO();
    private final AnalysisResultDAO analysisResultDAO = new AnalysisResultDAO();
    private ObservableList<Paper> observablePapers = FXCollections.observableArrayList();

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        StringConverter<Paper> converter = new StringConverter<>() {
            @Override
            public String toString(Paper p) {
                return p == null ? "" : p.getTitle() + " (" + p.getSubjectCode() + ")";
            }

            @Override
            public Paper fromString(String string) {
                return null;
            }
        };

        cmbPaperA.setConverter(converter);
        cmbPaperB.setConverter(converter);

        loadPapers();

        cmbPaperA.setOnAction(e -> updateComparison());
        cmbPaperB.setOnAction(e -> updateComparison());
    }

    private void loadPapers() {
        try {
            List<Paper> papers = paperDAO.findAll();
            observablePapers.setAll(papers);
            cmbPaperA.setItems(observablePapers);
            cmbPaperB.setItems(observablePapers);

            if (papers.size() >= 2) {
                cmbPaperA.getSelectionModel().select(0);
                cmbPaperB.getSelectionModel().select(1);
                updateComparison();
            } else if (!papers.isEmpty()) {
                cmbPaperA.getSelectionModel().select(0);
            }
        } catch (DatabaseException e) {
            // Non-fatal if offline
        }
    }

    private void updateComparison() {
        Paper pA = cmbPaperA.getValue();
        Paper pB = cmbPaperB.getValue();

        chartComparison.getData().clear();

        if (pA != null) {
            lblTitleA.setText(pA.getTitle());
            try {
                Optional<AnalysisResult> optA = analysisResultDAO.findByPaperId(pA.getId());
                if (optA.isPresent()) {
                    AnalysisResult resA = optA.get();
                    lblScoreA.setText(String.format("%.1f / 100", resA.getOverallDifficultyIndex()));
                    lblVerdictA.setText(resA.getBalanceVerdict());
                    lblDistributionA.setText(String.format("Easy: %.1f%% | Med: %.1f%% | Hard: %.1f%%",
                            resA.getEasyPercentage(), resA.getMediumPercentage(), resA.getHardPercentage()));

                    XYChart.Series<String, Number> seriesA = new XYChart.Series<>();
                    seriesA.setName(pA.getTitle());
                    seriesA.getData().add(new XYChart.Data<>("Remember", resA.getRememberCount()));
                    seriesA.getData().add(new XYChart.Data<>("Understand", resA.getUnderstandCount()));
                    seriesA.getData().add(new XYChart.Data<>("Apply", resA.getApplyCount()));
                    seriesA.getData().add(new XYChart.Data<>("Analyze", resA.getAnalyzeCount()));
                    seriesA.getData().add(new XYChart.Data<>("Evaluate", resA.getEvaluateCount()));
                    seriesA.getData().add(new XYChart.Data<>("Create", resA.getCreateCount()));
                    chartComparison.getData().add(seriesA);
                } else {
                    lblScoreA.setText("Not yet analyzed");
                    lblVerdictA.setText("-");
                    lblDistributionA.setText("-");
                }
            } catch (DatabaseException e) {
                lblScoreA.setText("Error loading result");
            }
        }

        if (pB != null) {
            lblTitleB.setText(pB.getTitle());
            try {
                Optional<AnalysisResult> optB = analysisResultDAO.findByPaperId(pB.getId());
                if (optB.isPresent()) {
                    AnalysisResult resB = optB.get();
                    lblScoreB.setText(String.format("%.1f / 100", resB.getOverallDifficultyIndex()));
                    lblVerdictB.setText(resB.getBalanceVerdict());
                    lblDistributionB.setText(String.format("Easy: %.1f%% | Med: %.1f%% | Hard: %.1f%%",
                            resB.getEasyPercentage(), resB.getMediumPercentage(), resB.getHardPercentage()));

                    XYChart.Series<String, Number> seriesB = new XYChart.Series<>();
                    seriesB.setName(pB.getTitle());
                    seriesB.getData().add(new XYChart.Data<>("Remember", resB.getRememberCount()));
                    seriesB.getData().add(new XYChart.Data<>("Understand", resB.getUnderstandCount()));
                    seriesB.getData().add(new XYChart.Data<>("Apply", resB.getApplyCount()));
                    seriesB.getData().add(new XYChart.Data<>("Analyze", resB.getAnalyzeCount()));
                    seriesB.getData().add(new XYChart.Data<>("Evaluate", resB.getEvaluateCount()));
                    seriesB.getData().add(new XYChart.Data<>("Create", resB.getCreateCount()));
                    chartComparison.getData().add(seriesB);
                } else {
                    lblScoreB.setText("Not yet analyzed");
                    lblVerdictB.setText("-");
                    lblDistributionB.setText("-");
                }
            } catch (DatabaseException e) {
                lblScoreB.setText("Error loading result");
            }
        }
    }

    @FXML
    private void handleBackToDashboard(ActionEvent event) {
        Stage stage = (Stage) cmbPaperA.getScene().getWindow();
        SceneNavigator.loadDashboard(stage);
    }
}
