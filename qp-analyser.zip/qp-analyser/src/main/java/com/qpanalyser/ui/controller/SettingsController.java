// File: src/main/java/com/qpanalyser/ui/controller/SettingsController.java
package com.qpanalyser.ui.controller;

import com.qpanalyser.dao.BloomVerbDAO;
import com.qpanalyser.dao.SettingsDAO;
import com.qpanalyser.exception.DatabaseException;
import com.qpanalyser.model.BloomLevel;
import com.qpanalyser.model.BloomVerb;
import com.qpanalyser.model.Setting;
import com.qpanalyser.ui.util.AlertHelper;
import com.qpanalyser.ui.util.SceneNavigator;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.net.URL;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;

/**
 * Controller: Settings and Taxonomy Customization
 * Author: JavaFX Lead
 * 
 * Allows configuring difficulty formula weights, target balance ratios,
 * and adding/modifying Bloom action verbs.
 */
public class SettingsController implements Initializable {

    @FXML private TextField txtWeightBloom;
    @FXML private TextField txtWeightLength;
    @FXML private TextField txtWeightSubParts;
    @FXML private TextField txtWeightMarks;
    @FXML private TextField txtWeightComplexity;

    @FXML private TextField txtTargetEasy;
    @FXML private TextField txtTargetMedium;
    @FXML private TextField txtTargetHard;

    @FXML private TableView<BloomVerb> tblVerbs;
    @FXML private TableColumn<BloomVerb, String> colVerb;
    @FXML private TableColumn<BloomVerb, BloomLevel> colBloomLevel;
    @FXML private TableColumn<BloomVerb, Double> colWeight;

    @FXML private TextField txtNewVerb;
    @FXML private ComboBox<BloomLevel> cmbNewBloomLevel;

    private final SettingsDAO settingsDAO = new SettingsDAO();
    private final BloomVerbDAO bloomVerbDAO = new BloomVerbDAO();
    private ObservableList<BloomVerb> observableVerbs = FXCollections.observableArrayList();

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        cmbNewBloomLevel.setItems(FXCollections.observableArrayList(BloomLevel.values()));
        cmbNewBloomLevel.getSelectionModel().select(BloomLevel.REMEMBER);

        setupVerbTable();
        loadSettingsFromDB();
        loadVerbsFromDB();
    }

    private void setupVerbTable() {
        colVerb.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getVerb()));
        colBloomLevel.setCellValueFactory(c -> new SimpleObjectProperty<>(c.getValue().getBloomLevel()));
        colWeight.setCellValueFactory(c -> new SimpleDoubleProperty(c.getValue().getWeight()).asObject());
        tblVerbs.setItems(observableVerbs);
    }

    private void loadSettingsFromDB() {
        try {
            txtWeightBloom.setText(settingsDAO.getValue("weight.bloom", "0.35"));
            txtWeightLength.setText(settingsDAO.getValue("weight.length", "0.20"));
            txtWeightSubParts.setText(settingsDAO.getValue("weight.subparts", "0.15"));
            txtWeightMarks.setText(settingsDAO.getValue("weight.marks", "0.15"));
            txtWeightComplexity.setText(settingsDAO.getValue("weight.complexity", "0.15"));

            txtTargetEasy.setText(settingsDAO.getValue("target.easy", "30.0"));
            txtTargetMedium.setText(settingsDAO.getValue("target.medium", "50.0"));
            txtTargetHard.setText(settingsDAO.getValue("target.hard", "20.0"));
        } catch (Exception e) {
            // Default fallbacks
            txtWeightBloom.setText("0.35");
            txtWeightLength.setText("0.20");
            txtWeightSubParts.setText("0.15");
            txtWeightMarks.setText("0.15");
            txtWeightComplexity.setText("0.15");
            txtTargetEasy.setText("30.0");
            txtTargetMedium.setText("50.0");
            txtTargetHard.setText("20.0");
        }
    }

    private void loadVerbsFromDB() {
        try {
            List<BloomVerb> verbs = bloomVerbDAO.findAll();
            observableVerbs.setAll(verbs);
        } catch (DatabaseException e) {
            AlertHelper.showWarning(txtNewVerb.getScene().getWindow(), "Database Notice",
                    "Could not load custom verbs from MySQL; default in-memory taxonomy is active.");
        }
    }

    @FXML
    private void handleSaveSettings(ActionEvent event) {
        try {
            double wB = Double.parseDouble(txtWeightBloom.getText());
            double wL = Double.parseDouble(txtWeightLength.getText());
            double wS = Double.parseDouble(txtWeightSubParts.getText());
            double wM = Double.parseDouble(txtWeightMarks.getText());
            double wC = Double.parseDouble(txtWeightComplexity.getText());

            double sum = wB + wL + wS + wM + wC;
            if (Math.abs(sum - 1.0) > 0.01) {
                AlertHelper.showWarning(txtWeightBloom.getScene().getWindow(), "Weight Sum Error",
                        "Weights must sum to 1.00 (Current Sum: " + String.format("%.2f", sum) + ")");
                return;
            }

            double tE = Double.parseDouble(txtTargetEasy.getText());
            double tM = Double.parseDouble(txtTargetMedium.getText());
            double tH = Double.parseDouble(txtTargetHard.getText());

            if (Math.abs(tE + tM + tH - 100.0) > 0.01) {
                AlertHelper.showWarning(txtWeightBloom.getScene().getWindow(), "Target Sum Error",
                        "Target distributions must sum to 100% (Current Sum: " + String.format("%.1f", tE + tM + tH) + "%)");
                return;
            }

            settingsDAO.save(new Setting("weight.bloom", String.valueOf(wB), "Weight for Bloom cognitive level"));
            settingsDAO.save(new Setting("weight.length", String.valueOf(wL), "Weight for text length"));
            settingsDAO.save(new Setting("weight.subparts", String.valueOf(wS), "Weight for sub-parts"));
            settingsDAO.save(new Setting("weight.marks", String.valueOf(wM), "Weight for allocated marks"));
            settingsDAO.save(new Setting("weight.complexity", String.valueOf(wC), "Weight for technical complexity"));

            settingsDAO.save(new Setting("target.easy", String.valueOf(tE), "Target Easy percentage"));
            settingsDAO.save(new Setting("target.medium", String.valueOf(tM), "Target Medium percentage"));
            settingsDAO.save(new Setting("target.hard", String.valueOf(tH), "Target Hard percentage"));

            AlertHelper.showInfo(txtWeightBloom.getScene().getWindow(), "Settings Saved",
                    "Configuration parameters updated successfully.");
        } catch (NumberFormatException e) {
            AlertHelper.showError(txtWeightBloom.getScene().getWindow(), "Invalid Format", "Please enter valid numeric values.");
        } catch (DatabaseException e) {
            AlertHelper.showError(txtWeightBloom.getScene().getWindow(), "Database Error", e.getMessage());
        }
    }

    @FXML
    private void handleAddVerb(ActionEvent event) {
        String verb = txtNewVerb.getText() != null ? txtNewVerb.getText().trim().toLowerCase() : "";
        if (verb.isEmpty()) {
            AlertHelper.showWarning(txtNewVerb.getScene().getWindow(), "Empty Verb", "Please enter a verb.");
            return;
        }

        BloomLevel level = cmbNewBloomLevel.getValue();
        BloomVerb newVerb = new BloomVerb(verb, level, level.getDefaultWeight());

        try {
            BloomVerb saved = bloomVerbDAO.save(newVerb);
            observableVerbs.add(saved);
            txtNewVerb.clear();
            AlertHelper.showInfo(txtNewVerb.getScene().getWindow(), "Verb Added",
                    "Successfully added '" + verb + "' to " + level + " category.");
        } catch (DatabaseException e) {
            AlertHelper.showError(txtNewVerb.getScene().getWindow(), "Database Error", e.getMessage());
        }
    }

    @FXML
    private void handleDeleteVerb(ActionEvent event) {
        BloomVerb selected = tblVerbs.getSelectionModel().getSelectedItem();
        if (selected == null) {
            AlertHelper.showWarning(tblVerbs.getScene().getWindow(), "No Selection", "Please select a verb to delete.");
            return;
        }

        try {
            bloomVerbDAO.deleteById(selected.getId());
            observableVerbs.remove(selected);
        } catch (DatabaseException e) {
            AlertHelper.showError(tblVerbs.getScene().getWindow(), "Delete Failed", e.getMessage());
        }
    }

    @FXML
    private void handleBackToDashboard(ActionEvent event) {
        Stage stage = (Stage) txtWeightBloom.getScene().getWindow();
        SceneNavigator.loadDashboard(stage);
    }
}
