// File: src/main/java/com/qpanalyser/util/PasswordUtil.java
package com.qpanalyser.util;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.HexFormat;

/**
 * Utility Class: Cryptographic Hashing for Passwords
 * Author: Team Coordinator
 * 
 * Implements salted SHA-256 password hashing.
 * Uses java.security.SecureRandom for salt generation and java.security.MessageDigest
 * with constant-time equality checking to resist rainbow-table and timing attacks.
 */
public final class PasswordUtil {

    private static final int SALT_BYTE_LENGTH = 16;
    private static final SecureRandom SECURE_RANDOM = new SecureRandom();

    // Private constructor prevents instantiation of utility class
    private PasswordUtil() {
        throw new UnsupportedOperationException("Utility class cannot be instantiated");
    }

    /**
     * Generates a cryptographically secure random salt in hexadecimal format.
     * 
     * @return 32-character hexadecimal string
     */
    public static String generateSalt() {
        byte[] saltBytes = new byte[SALT_BYTE_LENGTH];
        SECURE_RANDOM.nextBytes(saltBytes);
        return HexFormat.of().formatHex(saltBytes);
    }

    /**
     * Computes the SHA-256 hash of the concatenated salt and plaintext password.
     * 
     * @param plainPassword The plain text password entered by user
     * @param salt The unique salt string
     * @return 64-character hexadecimal SHA-256 hash
     */
    public static String hashPassword(String plainPassword, String salt) {
        if (plainPassword == null || salt == null) {
            throw new IllegalArgumentException("Password and salt cannot be null");
        }
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            // Combine salt and password bytes
            String saltedInput = salt + plainPassword;
            byte[] hashBytes = digest.digest(saltedInput.getBytes(StandardCharsets.UTF_8));
            return HexFormat.of().formatHex(hashBytes);
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("SHA-256 algorithm not available in current JVM", e);
        }
    }

    /**
     * Verifies whether a plain password matches the stored salted hash using constant-time comparison.
     * 
     * @param plainPassword Raw password entered during login
     * @param salt The stored salt for that user
     * @param storedHash The stored password hash in the database
     * @return true if matches, false otherwise
     */
    public static boolean verifyPassword(String plainPassword, String salt, String storedHash) {
        if (plainPassword == null || salt == null || storedHash == null) {
            return false;
        }
        String computedHash = hashPassword(plainPassword, salt);
        return MessageDigest.isEqual(
                computedHash.getBytes(StandardCharsets.UTF_8),
                storedHash.getBytes(StandardCharsets.UTF_8)
        );
    }
}
