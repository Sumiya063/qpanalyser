// File: src/main/java/com/qpanalyser/model/DifficultyLevel.java
package com.qpanalyser.model;

/**
 * OOP Concept: Enum Type with Custom Logic
 * Author: Core Java & OOP Lead
 * 
 * Represents Question difficulty classifications:
 * - EASY: difficulty score < 35.0
 * - MEDIUM: difficulty score between 35.0 and 65.0
 * - HARD: difficulty score > 65.0
 */
public enum DifficultyLevel {
    EASY("Easy", "#10B981", 0.0, 35.0),       // Green
    MEDIUM("Medium", "#F59E0B", 35.0, 65.0),   // Orange / Amber
    HARD("Hard", "#EF4444", 65.0, 100.0);      // Red

    private final String label;
    private final String badgeColorHex;
    private final double minScore;
    private final double maxScore;

    DifficultyLevel(String label, String badgeColorHex, double minScore, double maxScore) {
        this.label = label;
        this.badgeColorHex = badgeColorHex;
        this.minScore = minScore;
        this.maxScore = maxScore;
    }

    public String getLabel() {
        return label;
    }

    public String getBadgeColorHex() {
        return badgeColorHex;
    }

    public double getMinScore() {
        return minScore;
    }

    public double getMaxScore() {
        return maxScore;
    }

    /**
     * Determines the DifficultyLevel based on a calculated difficulty score (0 to 100).
     */
    public static DifficultyLevel fromScore(double score, double easyMax, double mediumMax) {
        if (score < easyMax) {
            return EASY;
        } else if (score <= mediumMax) {
            return MEDIUM;
        } else {
            return HARD;
        }
    }

    public static DifficultyLevel fromString(String text) {
        if (text == null) {
            return EASY;
        }
        for (DifficultyLevel d : DifficultyLevel.values()) {
            if (d.name().equalsIgnoreCase(text.trim()) || d.label.equalsIgnoreCase(text.trim())) {
                return d;
            }
        }
        return EASY;
    }
}
