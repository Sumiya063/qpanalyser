// File: src/main/java/com/qpanalyser/model/McqQuestion.java
package com.qpanalyser.model;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * OOP Concept: Inheritance & Method Overriding (Polymorphism)
 * Author: Core Java & OOP Lead
 * 
 * Represents a Multiple Choice Question (MCQ).
 * Extends the abstract Question class by adding choice options and specific timing heuristics.
 */
public class McqQuestion extends Question {

    // Subclass-specific encapsulated state
    private List<String> options = new ArrayList<>();
    private String correctOption;

    public McqQuestion() {
        super();
        setMarks(1.0);
    }

    public McqQuestion(String questionNumber, String questionText, double marks, String section) {
        super(questionNumber, questionText, marks, section);
    }

    public McqQuestion(int id, int paperId, String questionNumber, String questionText, double marks,
                       int subPartCount, BloomLevel bloomLevel, DifficultyLevel difficultyLevel,
                       double difficultyScore, String section, LocalDateTime createdAt) {
        super(id, paperId, questionNumber, questionText, marks, subPartCount, bloomLevel, difficultyLevel, difficultyScore, section, createdAt);
    }

    public List<String> getOptions() {
        return Collections.unmodifiableList(options);
    }

    public void setOptions(List<String> options) {
        this.options = options != null ? new ArrayList<>(options) : new ArrayList<>();
    }

    public void addOption(String option) {
        if (option != null && !option.trim().isEmpty()) {
            this.options.add(option.trim());
        }
    }

    public String getCorrectOption() {
        return correctOption;
    }

    public void setCorrectOption(String correctOption) {
        this.correctOption = correctOption;
    }

    // OOP Concept: Method Overriding - Subclass polymorphic implementation
    @Override
    public QuestionType getQuestionType() {
        return QuestionType.MCQ;
    }

    // OOP Concept: Method Overriding - MCQs typically require 1.5 minutes per question
    @Override
    public double calculateEstimatedAnsweringTimeMinutes() {
        return Math.max(1.0, getMarks() * 1.5);
    }

    @Override
    public String getDisplaySnippet() {
        int optCount = options.size();
        return "[MCQ " + getQuestionNumber() + "] " +
                (getQuestionText().length() > 40 ? getQuestionText().substring(0, 37) + "..." : getQuestionText()) +
                (optCount > 0 ? " (" + optCount + " choices)" : "");
    }
}
