// File: src/main/java/com/qpanalyser/model/LongAnswerQuestion.java
package com.qpanalyser.model;

import java.time.LocalDateTime;

/**
 * OOP Concept: Inheritance & Method Overriding (Polymorphism)
 * Author: Core Java & OOP Lead
 * 
 * Represents an Essay or Long Answer Question (typically 8 to 15 marks).
 * Requires structured exposition, deep analysis, or multi-faceted diagrams.
 */
public class LongAnswerQuestion extends Question {

    private boolean requiresDiagram;
    private String guidelines;

    public LongAnswerQuestion() {
        super();
        setMarks(10.0);
    }

    public LongAnswerQuestion(String questionNumber, String questionText, double marks, String section) {
        super(questionNumber, questionText, marks, section);
    }

    public LongAnswerQuestion(int id, int paperId, String questionNumber, String questionText, double marks,
                              int subPartCount, BloomLevel bloomLevel, DifficultyLevel difficultyLevel,
                              double difficultyScore, String section, LocalDateTime createdAt) {
        super(id, paperId, questionNumber, questionText, marks, subPartCount, bloomLevel, difficultyLevel, difficultyScore, section, createdAt);
    }

    public boolean isRequiresDiagram() {
        return requiresDiagram;
    }

    public void setRequiresDiagram(boolean requiresDiagram) {
        this.requiresDiagram = requiresDiagram;
    }

    public String getGuidelines() {
        return guidelines;
    }

    public void setGuidelines(String guidelines) {
        this.guidelines = guidelines;
    }

    // OOP Concept: Method Overriding
    @Override
    public QuestionType getQuestionType() {
        return QuestionType.LONG_ANSWER;
    }

    // OOP Concept: Method Overriding - Long answers typically need 2.2 minutes per mark plus extra time for sub-parts
    @Override
    public double calculateEstimatedAnsweringTimeMinutes() {
        double baseTime = getMarks() * 2.2;
        if (getSubPartCount() > 1) {
            baseTime += (getSubPartCount() - 1) * 2.0;
        }
        return Math.max(10.0, baseTime);
    }

    @Override
    public String getDisplaySnippet() {
        return "[Long " + getQuestionNumber() + "] (" + getMarks() + "M) " +
                (getQuestionText().length() > 50 ? getQuestionText().substring(0, 47) + "..." : getQuestionText());
    }
}
