// File: src/main/java/com/qpanalyser/model/QuestionFactory.java
package com.qpanalyser.model;

import java.time.LocalDateTime;

/**
 * OOP Concept: Factory Design Pattern
 * Author: Core Java & OOP Lead
 * 
 * Centralizes the instantiation of polymorphic Question subclasses based on QuestionType.
 * Eliminates tight coupling between client callers and concrete Question subclasses.
 */
public final class QuestionFactory {

    private QuestionFactory() {
        throw new UnsupportedOperationException("Factory class cannot be instantiated");
    }

    /**
     * Creates a new uninitialized Question subclass instance based on QuestionType.
     * 
     * @param type The QuestionType enum
     * @return Concrete Question subclass instance
     */
    public static Question createQuestion(QuestionType type) {
        if (type == null) {
            return new ShortAnswerQuestion();
        }
        return switch (type) {
            case MCQ -> new McqQuestion();
            case SHORT_ANSWER -> new ShortAnswerQuestion();
            case LONG_ANSWER -> new LongAnswerQuestion();
            case PROBLEM -> new ProblemQuestion();
        };
    }

    /**
     * Creates a Question subclass instance with basic metadata.
     */
    public static Question createQuestion(QuestionType type, String questionNumber, String questionText,
                                          double marks, String section) {
        Question q = createQuestion(type);
        q.setQuestionNumber(questionNumber);
        q.setQuestionText(questionText);
        q.setMarks(marks);
        q.setSection(section);
        return q;
    }

    /**
     * Creates a Question subclass instance from full database parameters.
     */
    public static Question createQuestion(int id, int paperId, String questionNumber, String questionText,
                                          QuestionType type, double marks, int subPartCount,
                                          BloomLevel bloomLevel, DifficultyLevel difficultyLevel,
                                          double difficultyScore, String section, LocalDateTime createdAt) {
        Question q = switch (type != null ? type : QuestionType.SHORT_ANSWER) {
            case MCQ -> new McqQuestion(id, paperId, questionNumber, questionText, marks, subPartCount,
                    bloomLevel, difficultyLevel, difficultyScore, section, createdAt);
            case SHORT_ANSWER -> new ShortAnswerQuestion(id, paperId, questionNumber, questionText, marks, subPartCount,
                    bloomLevel, difficultyLevel, difficultyScore, section, createdAt);
            case LONG_ANSWER -> new LongAnswerQuestion(id, paperId, questionNumber, questionText, marks, subPartCount,
                    bloomLevel, difficultyLevel, difficultyScore, section, createdAt);
            case PROBLEM -> new ProblemQuestion(id, paperId, questionNumber, questionText, marks, subPartCount,
                    bloomLevel, difficultyLevel, difficultyScore, section, createdAt);
        };
        return q;
    }
}
