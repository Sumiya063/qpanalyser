// File: src/main/java/com/qpanalyser/model/BloomLevel.java
package com.qpanalyser.model;

/**
 * OOP Concept: Enum Type with Fields and Methods
 * Author: Core Java & OOP Lead
 * 
 * Represents the 6 cognitive domains of Bloom's Revised Taxonomy:
 * 1. Remember (Knowledge Recall) - weight 1.0
 * 2. Understand (Comprehension) - weight 2.0
 * 3. Apply (Application) - weight 3.0
 * 4. Analyze (Analysis) - weight 4.0
 * 5. Evaluate (Evaluation) - weight 5.0
 * 6. Create (Creation / Synthesis) - weight 6.0
 */
public enum BloomLevel {
    REMEMBER(1, 1.0, "Recall facts and basic concepts", "#3B82F6"),     // Blue
    UNDERSTAND(2, 2.0, "Explain ideas or concepts", "#06B6D4"),         // Cyan
    APPLY(3, 3.0, "Use information in new situations", "#10B981"),      // Green
    ANALYZE(4, 4.0, "Draw connections among ideas", "#F59E0B"),         // Amber
    EVALUATE(5, 5.0, "Justify a stand or decision", "#EF4444"),         // Red
    CREATE(6, 6.0, "Produce new or original work", "#8B5CF6");          // Purple

    private final int levelOrder;
    private final double defaultWeight;
    private final String description;
    private final String colorHex;

    BloomLevel(int levelOrder, double defaultWeight, String description, String colorHex) {
        this.levelOrder = levelOrder;
        this.defaultWeight = defaultWeight;
        this.description = description;
        this.colorHex = colorHex;
    }

    public int getLevelOrder() {
        return levelOrder;
    }

    public double getDefaultWeight() {
        return defaultWeight;
    }

    public String getDescription() {
        return description;
    }

    public String getColorHex() {
        return colorHex;
    }

    public static BloomLevel fromString(String text) {
        if (text == null) {
            return REMEMBER;
        }
        for (BloomLevel b : BloomLevel.values()) {
            if (b.name().equalsIgnoreCase(text.trim())) {
                return b;
            }
        }
        return REMEMBER;
    }
}
