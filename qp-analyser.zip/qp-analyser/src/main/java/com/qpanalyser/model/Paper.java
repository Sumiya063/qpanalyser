// File: src/main/java/com/qpanalyser/model/Paper.java
package com.qpanalyser.model;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

/**
 * OOP Concept: Composition & Aggregation
 * Author: Core Java & OOP Lead
 * 
 * Represents an entire question paper containing metadata and an aggregated list of Questions.
 * Demonstrates the use of Java Streams and Lambdas for statistical aggregation.
 */
public class Paper {

    private int id;
    private String title;
    private String subjectCode;
    private String academicYear;
    private String semester;
    private double totalMarks;
    private double targetEasy = 30.0;
    private double targetMedium = 50.0;
    private double targetHard = 20.0;
    private int createdBy;
    private LocalDateTime createdAt;

    // OOP Concept: Composition - A Paper contains a collection of Question objects
    private List<Question> questions = new ArrayList<>();

    public Paper() {
        this.title = "Untitled Question Paper";
        this.subjectCode = "CSE203";
        this.academicYear = "2025-2026";
        this.semester = "Semester IV";
        this.totalMarks = 100.0;
        this.createdAt = LocalDateTime.now();
    }

    public Paper(String title, String subjectCode, String academicYear, String semester, double totalMarks, int createdBy) {
        this.title = title != null ? title.trim() : "Untitled Question Paper";
        this.subjectCode = subjectCode != null ? subjectCode.trim() : "CSE203";
        this.academicYear = academicYear != null ? academicYear.trim() : "2025-2026";
        this.semester = semester != null ? semester.trim() : "Semester IV";
        this.totalMarks = totalMarks > 0 ? totalMarks : 100.0;
        this.createdBy = createdBy;
        this.createdAt = LocalDateTime.now();
    }

    public Paper(int id, String title, String subjectCode, String academicYear, String semester,
                 double totalMarks, double targetEasy, double targetMedium, double targetHard,
                 int createdBy, LocalDateTime createdAt) {
        this.id = id;
        this.title = title;
        this.subjectCode = subjectCode;
        this.academicYear = academicYear;
        this.semester = semester;
        this.totalMarks = totalMarks;
        this.targetEasy = targetEasy;
        this.targetMedium = targetMedium;
        this.targetHard = targetHard;
        this.createdBy = createdBy;
        this.createdAt = createdAt != null ? createdAt : LocalDateTime.now();
    }

    // =========================================================================
    // Collection Management & Stream Aggregations
    // =========================================================================

    public void addQuestion(Question question) {
        if (question != null) {
            this.questions.add(question);
        }
    }

    public void removeQuestion(Question question) {
        this.questions.remove(question);
    }

    public boolean removeQuestionById(int questionId) {
        return this.questions.removeIf(q -> q.getId() == questionId);
    }

    public void clearQuestions() {
        this.questions.clear();
    }

    public List<Question> getQuestions() {
        return Collections.unmodifiableList(questions);
    }

    public void setQuestions(List<Question> questions) {
        this.questions = questions != null ? new ArrayList<>(questions) : new ArrayList<>();
    }

    public int getQuestionCount() {
        return this.questions.size();
    }

    /**
     * OOP Concept: Lambdas and Streams
     * Computes the sum of marks allocated across all questions in this paper.
     */
    public double calculateActualTotalMarks() {
        return this.questions.stream()
                .mapToDouble(Question::getMarks)
                .sum();
    }

    /**
     * OOP Concept: Polymorphism & Streams
     * Calculates the estimated total exam time needed by students by invoking
     * each question's polymorphic calculateEstimatedAnsweringTimeMinutes() method.
     */
    public double calculateEstimatedExamDurationMinutes() {
        return this.questions.stream()
                .mapToDouble(Question::calculateEstimatedAnsweringTimeMinutes)
                .sum();
    }

    // =========================================================================
    // Getters and Setters
    // =========================================================================

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getSubjectCode() {
        return subjectCode;
    }

    public void setSubjectCode(String subjectCode) {
        this.subjectCode = subjectCode;
    }

    public String getAcademicYear() {
        return academicYear;
    }

    public void setAcademicYear(String academicYear) {
        this.academicYear = academicYear;
    }

    public String getSemester() {
        return semester;
    }

    public void setSemester(String semester) {
        this.semester = semester;
    }

    public double getTotalMarks() {
        return totalMarks;
    }

    public void setTotalMarks(double totalMarks) {
        this.totalMarks = totalMarks;
    }

    public double getTargetEasy() {
        return targetEasy;
    }

    public void setTargetEasy(double targetEasy) {
        this.targetEasy = targetEasy;
    }

    public double getTargetMedium() {
        return targetMedium;
    }

    public void setTargetMedium(double targetMedium) {
        this.targetMedium = targetMedium;
    }

    public double getTargetHard() {
        return targetHard;
    }

    public void setTargetHard(double targetHard) {
        this.targetHard = targetHard;
    }

    public int getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(int createdBy) {
        this.createdBy = createdBy;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Paper paper)) return false;
        return id == paper.id && Objects.equals(title, paper.title) && Objects.equals(subjectCode, paper.subjectCode);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, title, subjectCode);
    }

    @Override
    public String toString() {
        return "Paper{" +
                "id=" + id +
                ", title='" + title + '\'' +
                ", subjectCode='" + subjectCode + '\'' +
                ", totalMarks=" + totalMarks +
                ", questionCount=" + questions.size() +
                '}';
    }
}
