// File: src/main/java/com/qpanalyser/model/ProblemQuestion.java
package com.qpanalyser.model;

import java.time.LocalDateTime;

/**
 * OOP Concept: Inheritance & Method Overriding (Polymorphism)
 * Author: Core Java & OOP Lead
 * 
 * Represents a Mathematical, Algorithmic, or Coding Problem Question.
 * Typically involves computations, dry runs, proofs, or pseudo-code implementations.
 */
public class ProblemQuestion extends Question {

    private boolean hasNumericalFormula;
    private boolean containsCodeSnippet;
    private String expectedOutput;

    public ProblemQuestion() {
        super();
        setMarks(8.0);
    }

    public ProblemQuestion(String questionNumber, String questionText, double marks, String section) {
        super(questionNumber, questionText, marks, section);
    }

    public ProblemQuestion(int id, int paperId, String questionNumber, String questionText, double marks,
                           int subPartCount, BloomLevel bloomLevel, DifficultyLevel difficultyLevel,
                           double difficultyScore, String section, LocalDateTime createdAt) {
        super(id, paperId, questionNumber, questionText, marks, subPartCount, bloomLevel, difficultyLevel, difficultyScore, section, createdAt);
    }

    public boolean isHasNumericalFormula() {
        return hasNumericalFormula;
    }

    public void setHasNumericalFormula(boolean hasNumericalFormula) {
        this.hasNumericalFormula = hasNumericalFormula;
    }

    public boolean isContainsCodeSnippet() {
        return containsCodeSnippet;
    }

    public void setContainsCodeSnippet(boolean containsCodeSnippet) {
        this.containsCodeSnippet = containsCodeSnippet;
    }

    public String getExpectedOutput() {
        return expectedOutput;
    }

    public void setExpectedOutput(String expectedOutput) {
        this.expectedOutput = expectedOutput;
    }

    // OOP Concept: Method Overriding
    @Override
    public QuestionType getQuestionType() {
        return QuestionType.PROBLEM;
    }

    // OOP Concept: Method Overriding - Problem questions require contemplation, calculation and tracing (~2.5 mins per mark)
    @Override
    public double calculateEstimatedAnsweringTimeMinutes() {
        double time = getMarks() * 2.5;
        if (hasNumericalFormula || containsCodeSnippet) {
            time += 3.0; // Extra buffer for mathematical calculation or code tracing
        }
        return Math.max(6.0, time);
    }

    @Override
    public String getDisplaySnippet() {
        return "[Problem " + getQuestionNumber() + "] (" + getMarks() + "M) " +
                (getQuestionText().length() > 50 ? getQuestionText().substring(0, 47) + "..." : getQuestionText());
    }
}
