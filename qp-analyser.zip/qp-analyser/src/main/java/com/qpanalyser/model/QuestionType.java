// File: src/main/java/com/qpanalyser/model/QuestionType.java
package com.qpanalyser.model;

/**
 * OOP Concept: Enum Type
 * Author: Core Java & OOP Lead
 * 
 * Classifies question formats supported by the analyzer.
 */
public enum QuestionType {
    MCQ("Multiple Choice Question", "Objective question with defined choices"),
    SHORT_ANSWER("Short Answer Question", "Concise descriptive question (1-5 marks)"),
    LONG_ANSWER("Long Answer / Essay Question", "Comprehensive conceptual question (6-15 marks)"),
    PROBLEM("Problem / Numerical Question", "Algorithmic, mathematical, or coding problem");

    private final String displayName;
    private final String description;

    QuestionType(String displayName, String description) {
        this.displayName = displayName;
        this.description = description;
    }

    public String getDisplayName() {
        return displayName;
    }

    public String getDescription() {
        return description;
    }

    public static QuestionType fromString(String value) {
        if (value == null) {
            return SHORT_ANSWER;
        }
        for (QuestionType type : QuestionType.values()) {
            if (type.name().equalsIgnoreCase(value.trim()) || 
                type.displayName.equalsIgnoreCase(value.trim())) {
                return type;
            }
        }
        return SHORT_ANSWER;
    }
}
