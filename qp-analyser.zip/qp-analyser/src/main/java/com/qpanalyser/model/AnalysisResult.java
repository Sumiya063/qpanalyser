// File: src/main/java/com/qpanalyser/model/AnalysisResult.java
package com.qpanalyser.model;

import java.time.LocalDateTime;

/**
 * OOP Concept: Encapsulation
 * Author: Core Java & OOP Lead
 * 
 * Aggregates analytical metrics for a question paper, including Bloom's cognitive distribution,
 * difficulty category percentages, balance verdict, and rule-based suggestions.
 */
public class AnalysisResult {

    private int id;
    private int paperId;
    private double overallDifficultyIndex;
    private double easyPercentage;
    private double mediumPercentage;
    private double hardPercentage;

    // Bloom Distribution Counters
    private int rememberCount;
    private int understandCount;
    private int applyCount;
    private int analyzeCount;
    private int evaluateCount;
    private int createCount;

    // Qualitative Metrics
    private String balanceVerdict;
    private String suggestions;
    private LocalDateTime generatedAt;

    public AnalysisResult() {
        this.generatedAt = LocalDateTime.now();
    }

    public AnalysisResult(int paperId, double overallDifficultyIndex, double easyPercentage,
                          double mediumPercentage, double hardPercentage, String balanceVerdict,
                          String suggestions) {
        this.paperId = paperId;
        this.overallDifficultyIndex = overallDifficultyIndex;
        this.easyPercentage = easyPercentage;
        this.mediumPercentage = mediumPercentage;
        this.hardPercentage = hardPercentage;
        this.balanceVerdict = balanceVerdict;
        this.suggestions = suggestions;
        this.generatedAt = LocalDateTime.now();
    }

    // Getters and Setters (Encapsulation)
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getPaperId() { return paperId; }
    public void setPaperId(int paperId) { this.paperId = paperId; }

    public double getOverallDifficultyIndex() { return overallDifficultyIndex; }
    public void setOverallDifficultyIndex(double overallDifficultyIndex) { this.overallDifficultyIndex = overallDifficultyIndex; }

    public double getEasyPercentage() { return easyPercentage; }
    public void setEasyPercentage(double easyPercentage) { this.easyPercentage = easyPercentage; }

    public double getMediumPercentage() { return mediumPercentage; }
    public void setMediumPercentage(double mediumPercentage) { this.mediumPercentage = mediumPercentage; }

    public double getHardPercentage() { return hardPercentage; }
    public void setHardPercentage(double hardPercentage) { this.hardPercentage = hardPercentage; }

    public int getRememberCount() { return rememberCount; }
    public void setRememberCount(int rememberCount) { this.rememberCount = rememberCount; }

    public int getUnderstandCount() { return understandCount; }
    public void setUnderstandCount(int understandCount) { this.understandCount = understandCount; }

    public int getApplyCount() { return applyCount; }
    public void setApplyCount(int applyCount) { this.applyCount = applyCount; }

    public int getAnalyzeCount() { return analyzeCount; }
    public void setAnalyzeCount(int analyzeCount) { this.analyzeCount = analyzeCount; }

    public int getEvaluateCount() { return evaluateCount; }
    public void setEvaluateCount(int evaluateCount) { this.evaluateCount = evaluateCount; }

    public int getCreateCount() { return createCount; }
    public void setCreateCount(int createCount) { this.createCount = createCount; }

    public String getBalanceVerdict() { return balanceVerdict; }
    public void setBalanceVerdict(String balanceVerdict) { this.balanceVerdict = balanceVerdict; }

    public String getSuggestions() { return suggestions; }
    public void setSuggestions(String suggestions) { this.suggestions = suggestions; }

    public LocalDateTime getGeneratedAt() { return generatedAt; }
    public void setGeneratedAt(LocalDateTime generatedAt) { this.generatedAt = generatedAt; }
}
