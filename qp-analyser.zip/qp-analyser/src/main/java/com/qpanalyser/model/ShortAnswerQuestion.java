// File: src/main/java/com/qpanalyser/model/ShortAnswerQuestion.java
package com.qpanalyser.model;

import java.time.LocalDateTime;

/**
 * OOP Concept: Inheritance & Method Overriding (Polymorphism)
 * Author: Core Java & OOP Lead
 * 
 * Represents a Short Answer Question (typically 2 to 5 marks).
 * Characterized by concise explanations, definitions, or direct short proofs.
 */
public class ShortAnswerQuestion extends Question {

    private int expectedWordLimit = 100;

    public ShortAnswerQuestion() {
        super();
        setMarks(3.0);
    }

    public ShortAnswerQuestion(String questionNumber, String questionText, double marks, String section) {
        super(questionNumber, questionText, marks, section);
    }

    public ShortAnswerQuestion(int id, int paperId, String questionNumber, String questionText, double marks,
                               int subPartCount, BloomLevel bloomLevel, DifficultyLevel difficultyLevel,
                               double difficultyScore, String section, LocalDateTime createdAt) {
        super(id, paperId, questionNumber, questionText, marks, subPartCount, bloomLevel, difficultyLevel, difficultyScore, section, createdAt);
    }

    public int getExpectedWordLimit() {
        return expectedWordLimit;
    }

    public void setExpectedWordLimit(int expectedWordLimit) {
        this.expectedWordLimit = expectedWordLimit;
    }

    // OOP Concept: Method Overriding
    @Override
    public QuestionType getQuestionType() {
        return QuestionType.SHORT_ANSWER;
    }

    // OOP Concept: Method Overriding - Short answers usually take 1.8 to 2.0 minutes per mark
    @Override
    public double calculateEstimatedAnsweringTimeMinutes() {
        return Math.max(3.0, getMarks() * 2.0);
    }

    @Override
    public String getDisplaySnippet() {
        return "[Short " + getQuestionNumber() + "] " +
                (getQuestionText().length() > 50 ? getQuestionText().substring(0, 47) + "..." : getQuestionText());
    }
}
