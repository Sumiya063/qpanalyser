// File: src/main/java/com/qpanalyser/model/Role.java
package com.qpanalyser.model;

/**
 * OOP Concept: Enum Type
 * Author: Core Java & OOP Lead
 * 
 * Defines the user authorization roles in the application.
 */
public enum Role {
    TEACHER("Teacher"),
    ADMIN("Administrator");

    private final String displayName;

    Role(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }

    public static Role fromString(String value) {
        if (value == null) {
            return TEACHER;
        }
        for (Role role : Role.values()) {
            if (role.name().equalsIgnoreCase(value.trim()) || role.displayName.equalsIgnoreCase(value.trim())) {
                return role;
            }
        }
        return TEACHER;
    }
}
