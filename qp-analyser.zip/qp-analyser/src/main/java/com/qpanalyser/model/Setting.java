// File: src/main/java/com/qpanalyser/model/Setting.java
package com.qpanalyser.model;

import java.util.Objects;

/**
 * OOP Concept: Encapsulation
 * Author: Core Java & OOP Lead
 * 
 * Represents a key-value system configuration entry (e.g. calculation weights, target ratios).
 */
public class Setting {
    private int id;
    private String key;
    private String value;
    private String description;

    public Setting() {
    }

    public Setting(String key, String value, String description) {
        this.key = key;
        this.value = value;
        this.description = description;
    }

    public Setting(int id, String key, String value, String description) {
        this.id = id;
        this.key = key;
        this.value = value;
        this.description = description;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public double getDoubleValue(double defaultValue) {
        try {
            return Double.parseDouble(this.value);
        } catch (NumberFormatException | NullPointerException e) {
            return defaultValue;
        }
    }

    public int getIntValue(int defaultValue) {
        try {
            return Integer.parseInt(this.value);
        } catch (NumberFormatException | NullPointerException e) {
            return defaultValue;
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Setting setting)) return false;
        return Objects.equals(key, setting.key);
    }

    @Override
    public int hashCode() {
        return Objects.hash(key);
    }

    @Override
    public String toString() {
        return "Setting{" +
                "id=" + id +
                ", key='" + key + '\'' +
                ", value='" + value + '\'' +
                ", description='" + description + '\'' +
                '}';
    }
}
