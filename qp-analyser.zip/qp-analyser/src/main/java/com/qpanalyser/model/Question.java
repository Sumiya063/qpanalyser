// File: src/main/java/com/qpanalyser/model/Question.java
package com.qpanalyser.model;

import java.time.LocalDateTime;
import java.util.Objects;

/**
 * OOP Concept: Abstraction & Inheritance Base Class
 * Author: Core Java & OOP Lead
 * 
 * Abstract base class representing a generic question in a question paper.
 * Encapsulates common attributes (text, marks, Bloom taxonomy level, difficulty score, section)
 * and declares abstract polymorphic methods that each subclass must implement.
 */
public abstract class Question {

    // OOP Concept: Encapsulation - Private fields protected from direct external modification
    private int id;
    private int paperId;
    private String questionNumber;
    private String questionText;
    private double marks;
    private int subPartCount;
    private BloomLevel bloomLevel;
    private DifficultyLevel difficultyLevel;
    private double difficultyScore;
    private String section;
    private LocalDateTime createdAt;

    // Default Constructor
    public Question() {
        this.questionNumber = "Q1";
        this.questionText = "";
        this.marks = 5.0;
        this.subPartCount = 1;
        this.bloomLevel = BloomLevel.REMEMBER;
        this.difficultyLevel = DifficultyLevel.EASY;
        this.difficultyScore = 20.0;
        this.section = "Section A";
        this.createdAt = LocalDateTime.now();
    }

    // Parameterized Constructor
    public Question(String questionNumber, String questionText, double marks, String section) {
        this.questionNumber = questionNumber != null ? questionNumber.trim() : "Q1";
        this.questionText = questionText != null ? questionText.trim() : "";
        this.marks = marks > 0 ? marks : 5.0;
        this.subPartCount = 1;
        this.bloomLevel = BloomLevel.REMEMBER;
        this.difficultyLevel = DifficultyLevel.EASY;
        this.difficultyScore = 0.0;
        this.section = section != null ? section.trim() : "Section A";
        this.createdAt = LocalDateTime.now();
    }

    // Full Parameterized Constructor
    public Question(int id, int paperId, String questionNumber, String questionText, double marks,
                    int subPartCount, BloomLevel bloomLevel, DifficultyLevel difficultyLevel,
                    double difficultyScore, String section, LocalDateTime createdAt) {
        this.id = id;
        this.paperId = paperId;
        this.questionNumber = questionNumber;
        this.questionText = questionText;
        this.marks = marks;
        this.subPartCount = Math.max(1, subPartCount);
        this.bloomLevel = bloomLevel != null ? bloomLevel : BloomLevel.REMEMBER;
        this.difficultyLevel = difficultyLevel != null ? difficultyLevel : DifficultyLevel.EASY;
        this.difficultyScore = difficultyScore;
        this.section = section != null ? section : "Section A";
        this.createdAt = createdAt != null ? createdAt : LocalDateTime.now();
    }

    // =========================================================================
    // OOP Concept: Polymorphism & Abstract Methods
    // Subclasses must provide their own specific implementations.
    // =========================================================================

    /**
     * Polymorphic method to identify the specific question format.
     * 
     * @return QuestionType enum value
     */
    public abstract QuestionType getQuestionType();

    /**
     * Polymorphic method to estimate how many minutes a student typically needs
     * to answer this question during an examination, factoring in its type and marks.
     * 
     * @return Estimated answering time in minutes
     */
    public abstract double calculateEstimatedAnsweringTimeMinutes();

    /**
     * Formats a short summary snippet suitable for tables and summary cards.
     * 
     * @return Formatted string snippet
     */
    public abstract String getDisplaySnippet();

    // =========================================================================
    // Getters and Setters (Encapsulation)
    // =========================================================================

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getPaperId() {
        return paperId;
    }

    public void setPaperId(int paperId) {
        this.paperId = paperId;
    }

    public String getQuestionNumber() {
        return questionNumber;
    }

    public void setQuestionNumber(String questionNumber) {
        this.questionNumber = questionNumber;
    }

    public String getQuestionText() {
        return questionText;
    }

    public void setQuestionText(String questionText) {
        this.questionText = questionText;
    }

    public double getMarks() {
        return marks;
    }

    public void setMarks(double marks) {
        this.marks = marks;
    }

    public int getSubPartCount() {
        return subPartCount;
    }

    public void setSubPartCount(int subPartCount) {
        this.subPartCount = Math.max(1, subPartCount);
    }

    public BloomLevel getBloomLevel() {
        return bloomLevel;
    }

    public void setBloomLevel(BloomLevel bloomLevel) {
        this.bloomLevel = bloomLevel != null ? bloomLevel : BloomLevel.REMEMBER;
    }

    public DifficultyLevel getDifficultyLevel() {
        return difficultyLevel;
    }

    public void setDifficultyLevel(DifficultyLevel difficultyLevel) {
        this.difficultyLevel = difficultyLevel != null ? difficultyLevel : DifficultyLevel.EASY;
    }

    public double getDifficultyScore() {
        return difficultyScore;
    }

    public void setDifficultyScore(double difficultyScore) {
        this.difficultyScore = Math.max(0.0, Math.min(100.0, difficultyScore));
    }

    public String getSection() {
        return section;
    }

    public void setSection(String section) {
        this.section = section;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public int getWordCount() {
        if (questionText == null || questionText.trim().isEmpty()) {
            return 0;
        }
        return questionText.trim().split("\\s+").length;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Question question)) return false;
        return id == question.id &&
                Double.compare(question.marks, marks) == 0 &&
                Objects.equals(questionNumber, question.questionNumber) &&
                Objects.equals(questionText, question.questionText);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, questionNumber, questionText, marks);
    }

    @Override
    public String toString() {
        return "[" + getQuestionType() + " " + questionNumber + "] (" + marks + " marks) " +
                (questionText.length() > 50 ? questionText.substring(0, 47) + "..." : questionText);
    }
}
