// File: src/main/java/com/qpanalyser/model/BloomVerb.java
package com.qpanalyser.model;

import java.util.Objects;

/**
 * OOP Concept: Encapsulation
 * Author: Core Java & OOP Lead
 * 
 * Represents an action verb in the Bloom's taxonomy dictionary.
 */
public class BloomVerb {
    private int id;
    private String verb;
    private BloomLevel bloomLevel;
    private double weight;

    public BloomVerb() {
    }

    public BloomVerb(String verb, BloomLevel bloomLevel, double weight) {
        this.verb = verb != null ? verb.toLowerCase().trim() : "";
        this.bloomLevel = bloomLevel != null ? bloomLevel : BloomLevel.REMEMBER;
        this.weight = weight;
    }

    public BloomVerb(int id, String verb, BloomLevel bloomLevel, double weight) {
        this.id = id;
        this.verb = verb != null ? verb.toLowerCase().trim() : "";
        this.bloomLevel = bloomLevel != null ? bloomLevel : BloomLevel.REMEMBER;
        this.weight = weight;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getVerb() {
        return verb;
    }

    public void setVerb(String verb) {
        this.verb = verb != null ? verb.toLowerCase().trim() : "";
    }

    public BloomLevel getBloomLevel() {
        return bloomLevel;
    }

    public void setBloomLevel(BloomLevel bloomLevel) {
        this.bloomLevel = bloomLevel;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof BloomVerb bloomVerb)) return false;
        return Objects.equals(verb, bloomVerb.verb);
    }

    @Override
    public int hashCode() {
        return Objects.hash(verb);
    }

    @Override
    public String toString() {
        return "BloomVerb{" +
                "id=" + id +
                ", verb='" + verb + '\'' +
                ", bloomLevel=" + bloomLevel +
                ", weight=" + weight +
                '}';
    }
}
