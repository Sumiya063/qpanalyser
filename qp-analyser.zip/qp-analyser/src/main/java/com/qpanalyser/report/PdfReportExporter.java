// File: src/main/java/com/qpanalyser/report/PdfReportExporter.java
package com.qpanalyser.report;

import com.qpanalyser.model.AnalysisResult;
import com.qpanalyser.model.Paper;
import com.qpanalyser.model.Question;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDType1Font;

import java.io.File;
import java.io.IOException;

/**
 * OOP Strategy Implementation: PDF Report Exporter using Apache PDFBox
 * Author: Team Coordinator
 * 
 * Generates an executive PDF report containing paper diagnostics, Bloom breakdown,
 * and question analysis.
 */
public class PdfReportExporter implements ReportExporter {

    @Override
    public void export(Paper paper, AnalysisResult result, File destination) throws IOException {
        try (PDDocument document = new PDDocument()) {
            PDPage page = new PDPage(PDRectangle.A4);
            document.addPage(page);

            try (PDPageContentStream stream = new PDPageContentStream(document, page)) {
                stream.beginText();
                stream.setFont(PDType1Font.HELVETICA_BOLD, 18);
                stream.setLeading(22.0f);
                stream.newLineAtOffset(50, 780);

                // Title
                stream.showText("AI Question Paper Difficulty Analysis Report");
                stream.newLine();
                stream.setFont(PDType1Font.HELVETICA, 10);
                stream.showText("Course: CSE203 Object Oriented Programming using Java");
                stream.newLine();
                stream.newLine();

                // Metadata
                stream.setFont(PDType1Font.HELVETICA_BOLD, 12);
                stream.showText("1. Paper Overview");
                stream.newLine();
                stream.setFont(PDType1Font.HELVETICA, 10);
                stream.showText("Title: " + sanitize(paper.getTitle()) + "  |  Subject: " + sanitize(paper.getSubjectCode()) + "  |  Total Marks: " + paper.getTotalMarks());
                stream.newLine();
                stream.showText(String.format("Overall Difficulty Index: %.1f / 100  |  Verdict: %s",
                        result.getOverallDifficultyIndex(), sanitize(result.getBalanceVerdict())));
                stream.newLine();
                stream.showText(String.format("Difficulty Distribution: Easy: %.1f%%  |  Medium: %.1f%%  |  Hard: %.1f%%",
                        result.getEasyPercentage(), result.getMediumPercentage(), result.getHardPercentage()));
                stream.newLine();
                stream.newLine();

                // Bloom's taxonomy
                stream.setFont(PDType1Font.HELVETICA_BOLD, 12);
                stream.showText("2. Bloom's Taxonomy Cognitive Profile");
                stream.newLine();
                stream.setFont(PDType1Font.HELVETICA, 10);
                stream.showText(String.format("Remember: %d  |  Understand: %d  |  Apply: %d  |  Analyze: %d  |  Evaluate: %d  |  Create: %d",
                        result.getRememberCount(), result.getUnderstandCount(), result.getApplyCount(),
                        result.getAnalyzeCount(), result.getEvaluateCount(), result.getCreateCount()));
                stream.newLine();
                stream.newLine();

                // Questions preview
                stream.setFont(PDType1Font.HELVETICA_BOLD, 12);
                stream.showText("3. Questions Summary");
                stream.newLine();
                stream.setFont(PDType1Font.HELVETICA, 9);
                if (paper.getQuestions() != null) {
                    int count = 0;
                    for (Question q : paper.getQuestions()) {
                        if (++count > 15) {
                            stream.showText("... and " + (paper.getQuestions().size() - 15) + " more questions.");
                            stream.newLine();
                            break;
                        }
                        String line = String.format("[%s] %s (%.1f marks, %s, Score: %.1f) - %s",
                                sanitize(q.getQuestionNumber()), q.getQuestionType(), q.getMarks(),
                                q.getBloomLevel(), q.getDifficultyScore(),
                                truncate(sanitize(q.getQuestionText()), 65));
                        stream.showText(line);
                        stream.newLine();
                    }
                }

                stream.endText();
            }

            document.save(destination);
        }
    }

    private String sanitize(String text) {
        if (text == null) return "";
        return text.replaceAll("[\\r\\n]+", " ").replaceAll("[^\\x20-\\x7E]", "?");
    }

    private String truncate(String text, int max) {
        if (text == null) return "";
        return text.length() <= max ? text : text.substring(0, max - 3) + "...";
    }

    @Override
    public String getFormatName() {
        return "Portable Document Format (*.pdf)";
    }

    @Override
    public String getFileExtension() {
        return "pdf";
    }
}
