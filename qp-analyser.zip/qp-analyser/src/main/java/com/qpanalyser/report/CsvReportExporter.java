// File: src/main/java/com/qpanalyser/report/CsvReportExporter.java
package com.qpanalyser.report;

import com.qpanalyser.model.AnalysisResult;
import com.qpanalyser.model.Paper;
import com.qpanalyser.model.Question;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

/**
 * OOP Strategy Implementation: CSV Report Exporter
 * Author: Team Coordinator
 * 
 * Exports question paper analysis, individual questions, marks, Bloom taxonomy level,
 * and difficulty scores as a comma-separated values (CSV) spreadsheet file.
 */
public class CsvReportExporter implements ReportExporter {

    @Override
    public void export(Paper paper, AnalysisResult result, File destination) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(destination, StandardCharsets.UTF_8))) {
            // Header summary
            writer.write("# Paper Title:," + escape(paper.getTitle()) + "\n");
            writer.write("# Subject:," + escape(paper.getSubjectCode()) + "\n");
            writer.write("# Total Marks:," + paper.getTotalMarks() + "\n");
            writer.write("# Overall Difficulty Index:," + result.getOverallDifficultyIndex() + "\n");
            writer.write("# Verdict:," + escape(result.getBalanceVerdict()) + "\n");
            writer.write(String.format("# Easy %s:,%.1f%%,# Medium %s:,%.1f%%,# Hard %s:,%.1f%%\n",
                    "%", result.getEasyPercentage(), "%", result.getMediumPercentage(), "%", result.getHardPercentage()));
            writer.write("\n");

            // Questions Table Header
            writer.write("Question No,Question Text,Type,Marks,Bloom Level,Difficulty Score,Difficulty Level\n");

            if (paper.getQuestions() != null) {
                for (Question q : paper.getQuestions()) {
                    writer.write(String.format("%s,%s,%s,%.1f,%s,%.1f,%s\n",
                            escape(q.getQuestionNumber()),
                            escape(q.getQuestionText()),
                            q.getQuestionType(),
                            q.getMarks(),
                            q.getBloomLevel(),
                            q.getDifficultyScore(),
                            q.getDifficultyLevel()
                    ));
                }
            }
        }
    }

    private String escape(String field) {
        if (field == null) {
            return "\"\"";
        }
        return "\"" + field.replace("\"", "\"\"").replace("\n", " ") + "\"";
    }

    @Override
    public String getFormatName() {
        return "Comma Separated Values (*.csv)";
    }

    @Override
    public String getFileExtension() {
        return "csv";
    }
}
