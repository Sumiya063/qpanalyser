// File: src/main/java/com/qpanalyser/report/ReportExporter.java
package com.qpanalyser.report;

import com.qpanalyser.model.AnalysisResult;
import com.qpanalyser.model.Paper;

import java.io.File;
import java.io.IOException;

/**
 * OOP Concept: Strategy Pattern Interface for Multi-Format Report Exporting
 * Author: Team Coordinator
 * 
 * Defines standard contract for exporting paper analysis metrics to various file formats.
 */
public interface ReportExporter {

    /**
     * Exports the paper and its analysis result to a specified destination file.
     * 
     * @param paper Analysis target question paper
     * @param result Aggregated analytical metrics
     * @param destination Target output file
     * @throws IOException If file creation or write fails
     */
    void export(Paper paper, AnalysisResult result, File destination) throws IOException;

    /**
     * Returns the human-readable format description.
     */
    String getFormatName();

    /**
     * Returns the supported file extension (e.g., "csv", "txt", "pdf").
     */
    String getFileExtension();
}
