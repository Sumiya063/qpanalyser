// File: src/main/java/com/qpanalyser/dsa/UndoStack.java
package com.qpanalyser.dsa;

import java.util.EmptyStackException;

/**
 * Custom Data Structure: Generic Linked-Node Stack for Undo Operations
 * Author: DSA & Database Lead
 * 
 * Hand-written LIFO (Last-In-First-Out) stack implementation without java.util.Stack.
 * Supports an optional maximum capacity limit to restrict in-memory history depth.
 * 
 * Big-O Complexity Analysis:
 * - push(T item): O(1) Time | O(1) Space
 * - pop():        O(1) Time | O(1) Space
 * - peek():       O(1) Time | O(1) Space
 * - isEmpty():    O(1) Time | O(1) Space
 * - size():       O(1) Time | O(1) Space
 * - clear():      O(N) Time | O(1) Auxiliary Space
 * 
 * @param <T> The element type held by this stack
 */
public class UndoStack<T> {

    // Internal linked node
    private static class Node<E> {
        final E data;
        Node<E> next;

        Node(E data, Node<E> next) {
            this.data = data;
            this.next = next;
        }
    }

    private Node<T> top;
    private int size;
    private final int maxCapacity;

    /**
     * Creates an unbounded UndoStack (capacity up to Integer.MAX_VALUE).
     */
    public UndoStack() {
        this(Integer.MAX_VALUE);
    }

    /**
     * Creates a bounded UndoStack with a maximum number of historical steps.
     * 
     * @param maxCapacity Maximum allowed elements before oldest are dropped
     */
    public UndoStack(int maxCapacity) {
        if (maxCapacity <= 0) {
            throw new IllegalArgumentException("Capacity must be greater than zero");
        }
        this.maxCapacity = maxCapacity;
        this.top = null;
        this.size = 0;
    }

    /**
     * Pushes a new element onto the top of the stack.
     * Time Complexity: O(1)
     * 
     * @param item Element to push
     */
    public void push(T item) {
        if (item == null) {
            throw new IllegalArgumentException("Cannot push null onto UndoStack");
        }

        // Enforce maximum capacity by truncating bottom if necessary
        if (size >= maxCapacity) {
            dropOldest();
        }

        top = new Node<>(item, top);
        size++;
    }

    /**
     * Removes and returns the element at the top of the stack.
     * Time Complexity: O(1)
     * 
     * @return Element previously at the top
     * @throws EmptyStackException if stack is empty
     */
    public T pop() {
        if (isEmpty()) {
            throw new EmptyStackException();
        }
        T data = top.data;
        top = top.next;
        size--;
        return data;
    }

    /**
     * Retrieves, but does not remove, the element at the top of the stack.
     * Time Complexity: O(1)
     * 
     * @return Element at top of stack
     * @throws EmptyStackException if stack is empty
     */
    public T peek() {
        if (isEmpty()) {
            throw new EmptyStackException();
        }
        return top.data;
    }

    /**
     * Checks if the stack contains zero elements.
     * Time Complexity: O(1)
     */
    public boolean isEmpty() {
        return top == null;
    }

    /**
     * Returns the current number of elements on the stack.
     * Time Complexity: O(1)
     */
    public int size() {
        return size;
    }

    /**
     * Empties the stack and releases all node references for garbage collection.
     * Time Complexity: O(N)
     */
    public void clear() {
        top = null;
        size = 0;
    }

    /**
     * Removes the bottom-most (oldest) node when capacity is exceeded.
     * Time Complexity: O(N) (only triggered when buffer reaches capacity limit)
     */
    private void dropOldest() {
        if (top == null || top.next == null) {
            top = null;
            size = 0;
            return;
        }
        Node<T> current = top;
        while (current.next != null && current.next.next != null) {
            current = current.next;
        }
        current.next = null;
        size--;
    }
}
