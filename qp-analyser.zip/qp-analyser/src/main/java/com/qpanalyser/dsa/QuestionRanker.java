// File: src/main/java/com/qpanalyser/dsa/QuestionRanker.java
package com.qpanalyser.dsa;

import com.qpanalyser.model.Question;

import java.util.*;

/**
 * PriorityQueue & TreeMap Algorithms for Question Ranking & Distributions
 * Author: DSA & Database Lead
 * 
 * Uses Min-Heap (PriorityQueue) to retrieve the Top-N hardest questions in O(K log N) time,
 * and TreeMap to compute ordered score range frequency distributions.
 * 
 * Big-O Complexity Analysis:
 * - Top-N Heap Ranking:     O(K log N) Time | O(N) Space, where K = total questions, N = top count.
 * - TreeMap Distribution:  O(K log B) Time | O(B) Space, where B = number of distribution buckets.
 */
public final class QuestionRanker {

    private QuestionRanker() {
        throw new UnsupportedOperationException("Utility class cannot be instantiated");
    }

    /**
     * Retrieves the top-N most difficult questions using a Min-Heap PriorityQueue.
     * 
     * Heap Invariant:
     * Maintains a Min-Heap of size N. Any question with higher difficulty score
     * evicts the current minimum element in O(log N) time.
     * 
     * @param questions Full list of questions
     * @param n Maximum number of top questions to return (e.g. 5)
     * @return List of top-N hardest questions in descending order (hardest first)
     */
    public static List<Question> getTopNHardestQuestions(List<Question> questions, int n) {
        if (questions == null || questions.isEmpty() || n <= 0) {
            return new ArrayList<>();
        }

        int targetCount = Math.min(n, questions.size());

        // Min-Heap ordered by difficulty score ascending
        PriorityQueue<Question> minHeap = new PriorityQueue<>(targetCount,
                Comparator.comparingDouble(Question::getDifficultyScore)
        );

        for (Question q : questions) {
            if (minHeap.size() < targetCount) {
                minHeap.offer(q);
            } else if (q.getDifficultyScore() > minHeap.peek().getDifficultyScore()) {
                minHeap.poll(); // Evict the least hard among current top candidates
                minHeap.offer(q);
            }
        }

        // Extract from Min-Heap and reverse to descending order
        List<Question> result = new ArrayList<>();
        while (!minHeap.isEmpty()) {
            result.add(minHeap.poll());
        }
        Collections.reverse(result);
        return result;
    }

    /**
     * Buckets questions into sorted difficulty score intervals using a TreeMap.
     * TreeMap guarantees O(log B) key insertion and naturally sorted ascending keys.
     * 
     * @param questions List of questions
     * @return Sorted TreeMap mapping score intervals to question frequencies
     */
    public static Map<String, Integer> computeScoreDistribution(List<Question> questions) {
        Map<String, Integer> distribution = new TreeMap<>();
        distribution.put("1. Very Easy (0-20)", 0);
        distribution.put("2. Easy (21-34)", 0);
        distribution.put("3. Moderate (35-50)", 0);
        distribution.put("4. Challenging (51-65)", 0);
        distribution.put("5. Hard (66-80)", 0);
        distribution.put("6. Advanced (81-100)", 0);

        if (questions == null) {
            return distribution;
        }

        for (Question q : questions) {
            double score = q.getDifficultyScore();
            if (score <= 20.0) {
                distribution.compute("1. Very Easy (0-20)", (k, v) -> v + 1);
            } else if (score <= 34.0) {
                distribution.compute("2. Easy (21-34)", (k, v) -> v + 1);
            } else if (score <= 50.0) {
                distribution.compute("3. Moderate (35-50)", (k, v) -> v + 1);
            } else if (score <= 65.0) {
                distribution.compute("4. Challenging (51-65)", (k, v) -> v + 1);
            } else if (score <= 80.0) {
                distribution.compute("5. Hard (66-80)", (k, v) -> v + 1);
            } else {
                distribution.compute("6. Advanced (81-100)", (k, v) -> v + 1);
            }
        }

        return distribution;
    }
}
