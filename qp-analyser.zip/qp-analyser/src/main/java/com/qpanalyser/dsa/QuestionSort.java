// File: src/main/java/com/qpanalyser/dsa/QuestionSort.java
package com.qpanalyser.dsa;

import com.qpanalyser.model.Question;

import java.util.ArrayList;
import java.util.List;

/**
 * Hand-written Divide & Conquer Sorting & Binary Search Algorithms
 * Author: DSA & Database Lead
 * 
 * Provides custom Merge Sort to sort questions by difficulty score, and Binary Search
 * to locate score cutoff thresholds (Easy <35, Medium 35-65, Hard >65).
 * 
 * Big-O Complexity Analysis:
 * - Merge Sort Time:   O(N log N) Best, Average, and Worst case.
 * - Merge Sort Space:  O(N) Auxiliary Space (divide-and-conquer array buffer).
 * - Binary Search:     O(log N) Time | O(1) Space.
 */
public final class QuestionSort {

    private QuestionSort() {
        throw new UnsupportedOperationException("Utility algorithm class cannot be instantiated");
    }

    /**
     * Hand-written Divide-and-Conquer Merge Sort algorithm.
     * Guaranteed O(N log N) time complexity across all inputs.
     * 
     * @param questions List of questions to sort
     * @param ascending true for ascending order (0 -> 100), false for descending (100 -> 0)
     * @return New sorted ArrayList of questions
     */
    public static List<Question> mergeSort(List<Question> questions, boolean ascending) {
        if (questions == null) {
            return new ArrayList<>();
        }
        if (questions.size() <= 1) {
            return new ArrayList<>(questions);
        }

        int mid = questions.size() / 2;
        List<Question> left = mergeSort(questions.subList(0, mid), ascending);
        List<Question> right = mergeSort(questions.subList(mid, questions.size()), ascending);

        return merge(left, right, ascending);
    }

    /**
     * Combines two sorted sub-lists into a single sorted list.
     * Time Complexity: O(N) where N = left.size() + right.size()
     */
    private static List<Question> merge(List<Question> left, List<Question> right, boolean ascending) {
        List<Question> merged = new ArrayList<>(left.size() + right.size());
        int i = 0, j = 0;

        while (i < left.size() && j < right.size()) {
            double scoreLeft = left.get(i).getDifficultyScore();
            double scoreRight = right.get(j).getDifficultyScore();

            boolean condition = ascending ? (scoreLeft <= scoreRight) : (scoreLeft >= scoreRight);

            if (condition) {
                merged.add(left.get(i++));
            } else {
                merged.add(right.get(j++));
            }
        }

        while (i < left.size()) {
            merged.add(left.get(i++));
        }

        while (j < right.size()) {
            merged.add(right.get(j++));
        }

        return merged;
    }

    /**
     * Hand-written Binary Search on a list of questions sorted in ascending order.
     * Finds the first index where question difficulty score is >= targetThreshold.
     * 
     * Time Complexity: O(log N)
     * Space Complexity: O(1)
     * 
     * @param sortedAscending List of questions sorted ascending by difficultyScore
     * @param targetThreshold Cutoff threshold (e.g. 65.0 for Hard)
     * @return Index of the first matching question, or sortedAscending.size() if none
     */
    public static int binarySearchThreshold(List<Question> sortedAscending, double targetThreshold) {
        if (sortedAscending == null || sortedAscending.isEmpty()) {
            return -1;
        }

        int low = 0;
        int high = sortedAscending.size() - 1;
        int resultIndex = sortedAscending.size(); // default if all elements < target

        while (low <= high) {
            int mid = low + (high - low) / 2;
            double midScore = sortedAscending.get(mid).getDifficultyScore();

            if (midScore >= targetThreshold) {
                resultIndex = mid;
                high = mid - 1; // Search left half for earlier occurrence
            } else {
                low = mid + 1;  // Search right half
            }
        }

        return resultIndex;
    }
}
