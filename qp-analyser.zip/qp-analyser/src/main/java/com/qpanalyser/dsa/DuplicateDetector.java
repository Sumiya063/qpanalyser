// File: src/main/java/com/qpanalyser/dsa/DuplicateDetector.java
package com.qpanalyser.dsa;

import com.qpanalyser.model.Question;

import java.util.*;

/**
 * Dynamic Programming: Levenshtein Distance & Jaccard Similarity for Question Deduplication
 * Author: DSA & Database Lead
 * 
 * Uses 2D Dynamic Programming table to compute Minimum Edit Distance between questions
 * to detect near-identical or accidentally duplicated questions in an exam.
 * 
 * Big-O Complexity Analysis:
 * - Levenshtein Distance: O(M * N) Time | O(M * N) Space, where M and N are string lengths.
 * - Jaccard Similarity:   O(W1 + W2) Time | O(W1 + W2) Space, where W1, W2 are word tokens.
 * - Pairwise Scan:        O(K^2 * M * N) Time, where K is number of questions in paper.
 */
public final class DuplicateDetector {

    public record DuplicatePair(Question questionA, Question questionB, double similarityPercentage) {
        @Override
        public String toString() {
            return String.format("%s and %s are %.1f%% similar",
                    questionA.getQuestionNumber(), questionB.getQuestionNumber(), similarityPercentage * 100.0);
        }
    }

    private DuplicateDetector() {
        throw new UnsupportedOperationException("Utility class cannot be instantiated");
    }

    /**
     * Computes the Levenshtein (edit) distance using Dynamic Programming.
     * 
     * DP Recurrence:
     * D[i, 0] = i
     * D[0, j] = j
     * D[i, j] = min( D[i-1, j] + 1,        // deletion
     *                D[i, j-1] + 1,        // insertion
     *                D[i-1, j-1] + cost )  // substitution
     * 
     * Time Complexity:  O(M * N)
     * Space Complexity: O(M * N)
     */
    public static int computeLevenshteinDistance(String s1, String s2) {
        if (s1 == null) s1 = "";
        if (s2 == null) s2 = "";

        int m = s1.length();
        int n = s2.length();

        // DP Table
        int[][] dp = new int[m + 1][n + 1];

        // Base cases
        for (int i = 0; i <= m; i++) {
            dp[i][0] = i;
        }
        for (int j = 0; j <= n; j++) {
            dp[0][j] = j;
        }

        // Fill DP table row by row
        for (int i = 1; i <= m; i++) {
            char char1 = s1.charAt(i - 1);
            for (int j = 1; j <= n; j++) {
                char char2 = s2.charAt(j - 1);
                int cost = (Character.toLowerCase(char1) == Character.toLowerCase(char2)) ? 0 : 1;

                dp[i][j] = Math.min(
                        dp[i - 1][j] + 1,              // Deletion
                        Math.min(
                                dp[i][j - 1] + 1,      // Insertion
                                dp[i - 1][j - 1] + cost // Substitution
                        )
                );
            }
        }

        return dp[m][n];
    }

    /**
     * Calculates normalized similarity score between 0.0 (completely distinct) and 1.0 (identical).
     */
    public static double computeSimilarity(String s1, String s2) {
        if (s1 == null || s2 == null) {
            return 0.0;
        }
        String clean1 = s1.trim().toLowerCase();
        String clean2 = s2.trim().toLowerCase();

        if (clean1.equals(clean2)) {
            return 1.0;
        }

        int maxLength = Math.max(clean1.length(), clean2.length());
        if (maxLength == 0) {
            return 1.0;
        }

        int distance = computeLevenshteinDistance(clean1, clean2);
        return 1.0 - ((double) distance / maxLength);
    }

    /**
     * Computes Jaccard Similarity between token sets: |A ∩ B| / |A ∪ B|.
     * Time Complexity: O(W1 + W2) using HashSet
     */
    public static double computeJaccardSimilarity(String s1, String s2) {
        if (s1 == null || s2 == null) return 0.0;

        Set<String> setA = new HashSet<>(Arrays.asList(s1.toLowerCase().split("\\s+")));
        Set<String> setB = new HashSet<>(Arrays.asList(s2.toLowerCase().split("\\s+")));

        if (setA.isEmpty() && setB.isEmpty()) return 1.0;

        Set<String> intersection = new HashSet<>(setA);
        intersection.retainAll(setB);

        Set<String> union = new HashSet<>(setA);
        union.addAll(setB);

        return (double) intersection.size() / union.size();
    }

    /**
     * Scans all question pairs in a paper to detect near-duplicate questions.
     * 
     * @param questions List of questions
     * @param threshold Similarity cutoff (e.g. 0.70 for 70% similar)
     * @return List of flagged duplicate pairs
     */
    public static List<DuplicatePair> findNearDuplicates(List<Question> questions, double threshold) {
        List<DuplicatePair> duplicates = new ArrayList<>();
        if (questions == null || questions.size() < 2) {
            return duplicates;
        }

        for (int i = 0; i < questions.size(); i++) {
            Question qA = questions.get(i);
            for (int j = i + 1; j < questions.size(); j++) {
                Question qB = questions.get(j);

                // Quick pre-filter: Jaccard similarity on word tokens
                double jaccard = computeJaccardSimilarity(qA.getQuestionText(), qB.getQuestionText());
                if (jaccard >= 0.50) {
                    // Fine-grained evaluation via Levenshtein DP
                    double levenshteinSim = computeSimilarity(qA.getQuestionText(), qB.getQuestionText());
                    double finalScore = Math.max(jaccard, levenshteinSim);

                    if (finalScore >= threshold) {
                        duplicates.add(new DuplicatePair(qA, qB, finalScore));
                    }
                }
            }
        }

        return duplicates;
    }
}
