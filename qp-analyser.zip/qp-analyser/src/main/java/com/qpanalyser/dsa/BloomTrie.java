// File: src/main/java/com/qpanalyser/dsa/BloomTrie.java
package com.qpanalyser.dsa;

import com.qpanalyser.model.BloomLevel;

import java.util.HashMap;
import java.util.Map;

/**
 * Custom Data Structure: Prefix Tree (Trie) for Bloom's Taxonomy Action Verbs
 * Author: DSA & Database Lead
 * 
 * Hand-written Trie optimized for fast O(M) dictionary lookup and substring prefix matching
 * of pedagogical action verbs (e.g., "explain", "design", "evaluate").
 * 
 * Big-O Complexity Analysis:
 * - insert(verb, level, weight): O(M) Time | O(M) Space, where M is length of the verb.
 * - search(verb):                O(M) Time | O(1) Auxiliary Space.
 * - findBestVerb(sentence):      O(W * M) Time, where W is word count and M is average word length.
 * - total space:                 O(Sigma * |V| * M) where Sigma is alphabet size and |V| is dictionary size.
 */
public class BloomTrie {

    public static class TrieNode {
        private final Map<Character, TrieNode> children = new HashMap<>();
        private boolean isEndOfWord;
        private BloomLevel bloomLevel;
        private double weight;
        private String fullVerb;

        public boolean isEndOfWord() {
            return isEndOfWord;
        }

        public BloomLevel getBloomLevel() {
            return bloomLevel;
        }

        public double getWeight() {
            return weight;
        }

        public String getFullVerb() {
            return fullVerb;
        }
    }

    public static class VerbMatchResult {
        private final boolean matched;
        private final String verb;
        private final BloomLevel bloomLevel;
        private final double weight;

        public VerbMatchResult(boolean matched, String verb, BloomLevel bloomLevel, double weight) {
            this.matched = matched;
            this.verb = verb;
            this.bloomLevel = bloomLevel;
            this.weight = weight;
        }

        public static VerbMatchResult notFound() {
            return new VerbMatchResult(false, null, BloomLevel.REMEMBER, 1.0);
        }

        public boolean isMatched() {
            return matched;
        }

        public String getVerb() {
            return verb;
        }

        public BloomLevel getBloomLevel() {
            return bloomLevel;
        }

        public double getWeight() {
            return weight;
        }
    }

    private final TrieNode root;
    private int wordCount;

    public BloomTrie() {
        this.root = new TrieNode();
        this.wordCount = 0;
    }

    /**
     * Inserts an action verb with its associated Bloom cognitive domain and weight.
     * Time Complexity: O(M) where M = verb.length()
     */
    public void insert(String verb, BloomLevel level, double weight) {
        if (verb == null || verb.trim().isEmpty()) {
            return;
        }
        String normalized = verb.toLowerCase().trim();
        TrieNode current = root;

        for (int i = 0; i < normalized.length(); i++) {
            char ch = normalized.charAt(i);
            current = current.children.computeIfAbsent(ch, c -> new TrieNode());
        }

        if (!current.isEndOfWord) {
            wordCount++;
        }
        current.isEndOfWord = true;
        current.bloomLevel = level != null ? level : BloomLevel.REMEMBER;
        current.weight = weight;
        current.fullVerb = normalized;
    }

    /**
     * Searches for an exact verb match in the Trie.
     * Time Complexity: O(M)
     */
    public VerbMatchResult search(String verb) {
        if (verb == null || verb.trim().isEmpty()) {
            return VerbMatchResult.notFound();
        }
        String normalized = verb.toLowerCase().trim();
        TrieNode current = root;

        for (int i = 0; i < normalized.length(); i++) {
            char ch = normalized.charAt(i);
            current = current.children.get(ch);
            if (current == null) {
                return VerbMatchResult.notFound();
            }
        }

        if (current.isEndOfWord) {
            return new VerbMatchResult(true, current.fullVerb, current.bloomLevel, current.weight);
        }
        return VerbMatchResult.notFound();
    }

    /**
     * Scans through words of a question sentence to find the highest-order Bloom action verb.
     * Time Complexity: O(W * M) where W is number of words and M is average word length.
     * 
     * @param sentence Full question text
     * @return Best matching VerbMatchResult (highest cognitive level found)
     */
    public VerbMatchResult findBestVerbInSentence(String sentence) {
        if (sentence == null || sentence.trim().isEmpty()) {
            return VerbMatchResult.notFound();
        }

        String[] tokens = sentence.toLowerCase().split("[^a-z]+");
        VerbMatchResult bestMatch = null;

        for (String token : tokens) {
            if (token.length() < 3) continue; // Skip short noise words

            VerbMatchResult match = search(token);
            if (match.isMatched()) {
                if (bestMatch == null || match.getBloomLevel().getLevelOrder() > bestMatch.getBloomLevel().getLevelOrder()) {
                    bestMatch = match;
                }
            }
        }

        return bestMatch != null ? bestMatch : VerbMatchResult.notFound();
    }

    public int getWordCount() {
        return wordCount;
    }

    public boolean isEmpty() {
        return wordCount == 0;
    }
}
