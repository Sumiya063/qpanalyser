// File: src/main/java/com/qpanalyser/service/undo/UndoManager.java
package com.qpanalyser.service.undo;

import com.qpanalyser.dsa.UndoStack;

/**
 * Service: Undo/Redo Manager powered by custom UndoStack
 * Author: DSA & Database Lead
 * 
 * Manages the history of edits made to question papers during review.
 * Utilizes the custom hand-written UndoStack<T> data structure.
 */
public class UndoManager {

    private final UndoStack<EditCommand> undoStack;
    private final UndoStack<EditCommand> redoStack;

    public UndoManager() {
        this(50); // Keep up to 50 historical steps in memory
    }

    public UndoManager(int maxCapacity) {
        this.undoStack = new UndoStack<>(maxCapacity);
        this.redoStack = new UndoStack<>(maxCapacity);
    }

    /**
     * Executes a command and records it onto the undo stack.
     */
    public void executeCommand(EditCommand command) {
        if (command == null) return;
        command.execute();
        undoStack.push(command);
        redoStack.clear(); // Clearing redo stack on new action
    }

    /**
     * Reverses the last executed command.
     * 
     * @return Description of the undone action, or null if cannot undo
     */
    public String undo() {
        if (undoStack.isEmpty()) {
            return null;
        }
        EditCommand command = undoStack.pop();
        command.undo();
        redoStack.push(command);
        return command.getDescription();
    }

    /**
     * Re-applies the last undone command.
     * 
     * @return Description of the redone action, or null if cannot redo
     */
    public String redo() {
        if (redoStack.isEmpty()) {
            return null;
        }
        EditCommand command = redoStack.pop();
        command.redo();
        undoStack.push(command);
        return command.getDescription();
    }

    public boolean canUndo() {
        return !undoStack.isEmpty();
    }

    public boolean canRedo() {
        return !redoStack.isEmpty();
    }

    public int getUndoCount() {
        return undoStack.size();
    }

    public int getRedoCount() {
        return redoStack.size();
    }

    public void clear() {
        undoStack.clear();
        redoStack.clear();
    }
}
