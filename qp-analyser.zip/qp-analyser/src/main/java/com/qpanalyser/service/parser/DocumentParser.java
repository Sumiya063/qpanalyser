// File: src/main/java/com/qpanalyser/service/parser/DocumentParser.java
package com.qpanalyser.service.parser;

import com.qpanalyser.exception.InvalidPaperException;
import com.qpanalyser.exception.ParsingException;

import java.io.File;

/**
 * OOP Concept: Strategy Design Pattern (Interface Contract)
 * Author: DSA & Database Lead
 * 
 * Defines the contract for parsing question paper documents from different file formats
 * (Plain text, PDF, Word DOCX) into clean normalized string content.
 */
public interface DocumentParser {

    /**
     * Extracts and returns the full text content from the specified document file.
     * 
     * @param file The question paper file on disk
     * @return Normalized text content
     * @throws ParsingException if low-level stream reading or decoding fails
     * @throws InvalidPaperException if file content is empty or structurally invalid
     */
    String parse(File file) throws ParsingException, InvalidPaperException;

    /**
     * Checks if this parser implementation supports the given file extension.
     * 
     * @param fileExtension File extension without dot (e.g. "txt", "pdf", "docx")
     * @return true if supported, false otherwise
     */
    boolean supports(String fileExtension);
}
