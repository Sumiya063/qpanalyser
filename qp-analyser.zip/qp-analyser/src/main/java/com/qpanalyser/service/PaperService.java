// File: src/main/java/com/qpanalyser/service/PaperService.java
package com.qpanalyser.service;

import com.qpanalyser.dao.PaperDAO;
import com.qpanalyser.dao.QuestionDAO;
import com.qpanalyser.exception.DatabaseException;
import com.qpanalyser.exception.InvalidPaperException;
import com.qpanalyser.exception.ParsingException;
import com.qpanalyser.model.Paper;
import com.qpanalyser.model.Question;
import com.qpanalyser.service.parser.DocumentParser;
import com.qpanalyser.service.parser.DocumentParserFactory;
import com.qpanalyser.service.parser.FileValidator;

import java.io.File;
import java.util.List;
import java.util.Optional;

/**
 * Business Service: Paper Management and Document Extraction Pipeline
 * Author: Core Java & OOP Lead
 * 
 * Orchestrates file validation, document format parsing, and persistence.
 */
public class PaperService {

    private final PaperDAO paperDAO;
    private final QuestionDAO questionDAO;

    public PaperService() {
        this.paperDAO = new PaperDAO();
        this.questionDAO = new QuestionDAO();
    }

    public PaperService(PaperDAO paperDAO, QuestionDAO questionDAO) {
        this.paperDAO = paperDAO;
        this.questionDAO = questionDAO;
    }

    /**
     * Validates and parses a physical question paper file into clean text.
     * 
     * @param file Uploaded file (.txt, .pdf, .docx)
     * @return Extracted raw text content
     * @throws InvalidPaperException if file fails validation or format checks
     * @throws ParsingException if extraction encounters parsing errors
     */
    public String loadAndParseDocument(File file) throws InvalidPaperException, ParsingException {
        FileValidator.validate(file);
        DocumentParser parser = DocumentParserFactory.getParser(file);
        return parser.parse(file);
    }

    /**
     * Persists paper metadata to the database.
     */
    public Paper createPaper(String title, String subjectCode, String academicYear, String semester,
                             double totalMarks, double targetEasy, double targetMedium, double targetHard,
                             int createdByUserId) throws DatabaseException, InvalidPaperException {

        if (title == null || title.trim().isEmpty()) {
            throw new InvalidPaperException("Paper title cannot be empty.");
        }
        if (subjectCode == null || subjectCode.trim().isEmpty()) {
            throw new InvalidPaperException("Subject code cannot be empty.");
        }

        Paper paper = new Paper(title.trim(), subjectCode.trim(), academicYear, semester, totalMarks, createdByUserId);
        paper.setTargetEasy(targetEasy);
        paper.setTargetMedium(targetMedium);
        paper.setTargetHard(targetHard);

        return paperDAO.save(paper);
    }

    public List<Paper> getPapersForUser(int userId) throws DatabaseException {
        return paperDAO.findByCreatedBy(userId);
    }

    public Optional<Paper> getPaperWithQuestions(int paperId) throws DatabaseException {
        Optional<Paper> paperOpt = paperDAO.findById(paperId);
        if (paperOpt.isPresent()) {
            Paper paper = paperOpt.get();
            List<Question> questions = questionDAO.findByPaperId(paperId);
            paper.setQuestions(questions);
            return Optional.of(paper);
        }
        return Optional.empty();
    }

    public boolean deletePaper(int paperId) throws DatabaseException {
        return paperDAO.deleteById(paperId);
    }
}
