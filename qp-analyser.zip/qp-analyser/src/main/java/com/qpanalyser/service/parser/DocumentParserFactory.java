// File: src/main/java/com/qpanalyser/service/parser/DocumentParserFactory.java
package com.qpanalyser.service.parser;

import com.qpanalyser.exception.InvalidPaperException;

import java.io.File;
import java.util.List;

/**
 * OOP Concept: Factory & Strategy Selection Pattern
 * Author: DSA & Database Lead
 * 
 * Determines and returns the appropriate DocumentParser implementation based on file extension.
 */
public final class DocumentParserFactory {

    private static final List<DocumentParser> PARSERS = List.of(
            new PlainTextParser(),
            new PdfDocumentParser(),
            new DocxDocumentParser()
    );

    private DocumentParserFactory() {
        throw new UnsupportedOperationException("Factory class cannot be instantiated");
    }

    /**
     * Resolves the matching DocumentParser for the provided file.
     * 
     * @param file The file to parse
     * @return Corresponding DocumentParser implementation
     * @throws InvalidPaperException if the file type is unsupported
     */
    public static DocumentParser getParser(File file) throws InvalidPaperException {
        if (file == null) {
            throw new InvalidPaperException("No file was specified for parsing.");
        }

        String extension = getFileExtension(file.getName());
        return PARSERS.stream()
                .filter(p -> p.supports(extension))
                .findFirst()
                .orElseThrow(() -> new InvalidPaperException(
                        "Unsupported file format: '." + extension + "'.\n" +
                        "Supported formats are: Plain Text (.txt), Adobe PDF (.pdf), and Microsoft Word (.docx)."
                ));
    }

    /**
     * Extracts lowercase file extension without the preceding period.
     */
    public static String getFileExtension(String fileName) {
        if (fileName == null || !fileName.contains(".")) {
            return "";
        }
        return fileName.substring(fileName.lastIndexOf('.') + 1).toLowerCase().trim();
    }
}
