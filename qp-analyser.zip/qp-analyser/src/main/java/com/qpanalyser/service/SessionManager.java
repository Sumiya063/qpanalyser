// File: src/main/java/com/qpanalyser/service/SessionManager.java
package com.qpanalyser.service;

import com.qpanalyser.model.Role;
import com.qpanalyser.model.User;

/**
 * Session Management Singleton
 * Author: Core Java & OOP Lead
 * 
 * Manages the current authenticated user session in memory throughout application runtime.
 */
public class SessionManager {

    private static volatile SessionManager instance;
    private User currentUser;

    private SessionManager() {
    }

    public static SessionManager getInstance() {
        if (instance == null) {
            synchronized (SessionManager.class) {
                if (instance == null) {
                    instance = new SessionManager();
                }
            }
        }
        return instance;
    }

    public synchronized void setCurrentUser(User user) {
        this.currentUser = user;
    }

    public synchronized User getCurrentUser() {
        return this.currentUser;
    }

    public synchronized boolean isLoggedIn() {
        return this.currentUser != null;
    }

    public synchronized boolean hasRole(Role role) {
        return this.currentUser != null && this.currentUser.getRole() == role;
    }

    public synchronized boolean isAdmin() {
        return hasRole(Role.ADMIN);
    }

    public synchronized void logout() {
        this.currentUser = null;
    }
}
