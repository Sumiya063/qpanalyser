// File: src/main/java/com/qpanalyser/service/parser/PdfDocumentParser.java
package com.qpanalyser.service.parser;

import com.qpanalyser.exception.InvalidPaperException;
import com.qpanalyser.exception.ParsingException;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;

import java.io.File;
import java.io.IOException;

/**
 * OOP Concept: Strategy Pattern Implementation & Third-Party Library Integration
 * Author: DSA & Database Lead
 * 
 * Extracts raw textual content from Adobe PDF (.pdf) question papers using Apache PDFBox.
 * Time Complexity: O(P * K) where P is page count and K is text density per page.
 */
public class PdfDocumentParser implements DocumentParser {

    @Override
    public String parse(File file) throws ParsingException, InvalidPaperException {
        if (file == null || !file.exists()) {
            throw new InvalidPaperException("Selected PDF file does not exist.");
        }

        // OOP Concept: Try-with-resources ensures PDDocument is properly closed after parsing
        try (PDDocument document = PDDocument.load(file)) {
            if (document.isEncrypted()) {
                throw new ParsingException("The uploaded PDF is encrypted or password-protected. Please upload an unprotected file.");
            }

            if (document.getNumberOfPages() == 0) {
                throw new InvalidPaperException("The uploaded PDF document contains 0 pages.");
            }

            PDFTextStripper stripper = new PDFTextStripper();
            stripper.setSortByPosition(true); // Preserve visual order of exam questions
            String text = stripper.getText(document);

            if (text == null || text.trim().isEmpty()) {
                throw new InvalidPaperException("No extractable text was found in the PDF. Scanned image-only PDFs are not supported.");
            }

            return text.replace("\r\n", "\n").replace("\r", "\n").trim();

        } catch (IOException e) {
            throw new ParsingException("Failed to parse PDF document with Apache PDFBox: " + e.getMessage(), e);
        }
    }

    @Override
    public boolean supports(String fileExtension) {
        return fileExtension != null && fileExtension.equalsIgnoreCase("pdf");
    }
}
