// File: src/main/java/com/qpanalyser/service/parser/FileValidator.java
package com.qpanalyser.service.parser;

import com.qpanalyser.exception.InvalidPaperException;

import java.io.File;
import java.util.Set;

/**
 * Validation Utility: Question Paper File Verification
 * Author: Team Coordinator
 * 
 * Enforces file size boundaries, extension whitelist, and filesystem accessibility.
 */
public final class FileValidator {

    // Maximum allowed file size in bytes (15 MB)
    public static final long MAX_FILE_SIZE_BYTES = 15 * 1024 * 1024;
    private static final Set<String> ALLOWED_EXTENSIONS = Set.of("txt", "pdf", "docx");

    private FileValidator() {
        throw new UnsupportedOperationException("Utility class cannot be instantiated");
    }

    /**
     * Validates that the uploaded paper file meets all physical file requirements.
     * 
     * @param file The uploaded file
     * @throws InvalidPaperException if any validation check fails
     */
    public static void validate(File file) throws InvalidPaperException {
        if (file == null) {
            throw new InvalidPaperException("No file was selected. Please choose a question paper file.");
        }

        if (!file.exists()) {
            throw new InvalidPaperException("The selected file does not exist at path: " + file.getAbsolutePath());
        }

        if (!file.isFile()) {
            throw new InvalidPaperException("The selected path is a directory, not a question paper file.");
        }

        if (!file.canRead()) {
            throw new InvalidPaperException("The application lacks read permission for file: " + file.getName());
        }

        if (file.length() == 0) {
            throw new InvalidPaperException("The selected file '" + file.getName() + "' is empty (0 bytes).");
        }

        if (file.length() > MAX_FILE_SIZE_BYTES) {
            long sizeInMb = file.length() / (1024 * 1024);
            throw new InvalidPaperException("File size (" + sizeInMb + " MB) exceeds the maximum limit of 15 MB.");
        }

        String extension = DocumentParserFactory.getFileExtension(file.getName());
        if (!ALLOWED_EXTENSIONS.contains(extension)) {
            throw new InvalidPaperException(
                    "File extension '." + extension + "' is not permitted. Allowed extensions are: " +
                    String.join(", ", ALLOWED_EXTENSIONS)
            );
        }
    }
}
