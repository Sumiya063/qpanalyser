// File: src/main/java/com/qpanalyser/service/undo/SplitQuestionCommand.java
package com.qpanalyser.service.undo;

import com.qpanalyser.model.Question;
import com.qpanalyser.model.QuestionFactory;

import java.util.List;

/**
 * Command: Split Question into Two Sub-Questions
 * Author: DSA & Database Lead
 */
public class SplitQuestionCommand implements EditCommand {

    private final List<Question> questionList;
    private final Question originalQuestion;
    private final Question newlyCreatedQuestion;
    private final int insertIndex;

    private final String originalText;
    private final double originalMarks;

    public SplitQuestionCommand(List<Question> questionList, Question originalQuestion,
                                String part1Text, String part2Text, double part1Marks, double part2Marks) {
        this.questionList = questionList;
        this.originalQuestion = originalQuestion;
        this.originalText = originalQuestion.getQuestionText();
        this.originalMarks = originalQuestion.getMarks();

        int originalIdx = questionList.indexOf(originalQuestion);
        this.insertIndex = originalIdx + 1;

        // Create the second question split from the original
        this.newlyCreatedQuestion = QuestionFactory.createQuestion(
                originalQuestion.getQuestionType(),
                originalQuestion.getQuestionNumber() + "(b)",
                part2Text,
                part2Marks,
                originalQuestion.getSection()
        );
    }

    @Override
    public void execute() {
        // Adjust original question to part 1
        originalQuestion.setQuestionNumber(originalQuestion.getQuestionNumber() + "(a)");
        originalQuestion.setMarks(originalMarks - newlyCreatedQuestion.getMarks());
        // Insert new second question
        if (insertIndex >= 0 && insertIndex <= questionList.size()) {
            questionList.add(insertIndex, newlyCreatedQuestion);
        } else {
            questionList.add(newlyCreatedQuestion);
        }
    }

    @Override
    public void undo() {
        // Remove newly created question
        questionList.remove(newlyCreatedQuestion);
        // Restore original question
        String qNum = originalQuestion.getQuestionNumber();
        if (qNum.endsWith("(a)")) {
            originalQuestion.setQuestionNumber(qNum.substring(0, qNum.length() - 3));
        }
        originalQuestion.setQuestionText(originalText);
        originalQuestion.setMarks(originalMarks);
    }

    @Override
    public String getDescription() {
        return "Split " + originalQuestion.getQuestionNumber();
    }
}
