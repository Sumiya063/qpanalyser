// File: src/main/java/com/qpanalyser/service/extractor/RegexQuestionExtractor.java
package com.qpanalyser.service.extractor;

import com.qpanalyser.exception.ParsingException;
import com.qpanalyser.model.Question;
import com.qpanalyser.model.QuestionFactory;
import com.qpanalyser.model.QuestionType;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * OOP Concept: Strategy Pattern Implementation
 * Author: Team Coordinator
 * 
 * Extracts questions using regular expressions and domain heuristics.
 * Recognizes numbering schemas (1., Q1, (a), (i)), marks ([5], 5 marks),
 * and dynamic section headers.
 * 
 * Big-O Complexity Analysis:
 * - Time Complexity:  O(L) where L is the total character length of the raw paper text.
 * - Space Complexity: O(Q) auxiliary space where Q is the number of extracted questions.
 */
public class RegexQuestionExtractor implements QuestionExtractor {

    // Regex for Section Headings (e.g. "SECTION A: BASIC CONCEPTS", "PART 1", "UNIT II")
    private static final Pattern SECTION_PATTERN = Pattern.compile(
            "(?im)^(?:SECTION|PART|UNIT|GROUP)\\s+([A-Z0-9]+)[\\:\\-\\s]*(.*)$"
    );

    // Regex for Question Numbering (e.g. "Q1.", "Q1)", "1.", "1)", "Question 1:", "(1)")
    private static final Pattern QUESTION_START_PATTERN = Pattern.compile(
            "(?im)^(?:(?:Question|Q)\\s*(\\d+[a-z]?)|(\\d+[a-z]?)\\s*[\\.\\:\\-\\)]|\\((\\d+[a-z]?)\\))\\s*(.*)$"
    );

    // Regex for Marks extraction: [5], [5 Marks], (10 marks), (5m), - 5 marks
    private static final Pattern MARKS_PATTERN = Pattern.compile(
            "(?i)\\[\\s*(\\d+(?:\\.\\d+)?)\\s*(?:marks?|pts?|m)?\\s*\\]|" +
            "\\(\\s*(\\d+(?:\\.\\d+)?)\\s*(?:marks?|pts?|m)\\s*\\)|" +
            "[-–—]\\s*(\\d+(?:\\.\\d+)?)\\s*(?:marks?|pts?)"
    );

    // Regex for Sub-parts (e.g. (a), (b), (i), (ii) either at start of line or preceded by whitespace)
    private static final Pattern SUB_PART_PATTERN = Pattern.compile(
            "(?i)(?:^|\\s)(?:\\([a-z0-9]+\\)|\\[[a-z0-9]+\\]|\\([ivxlcdm]+\\)|[a-z]\\))(?=\\s)"
    );

    // Heuristics for Problem / Code Questions
    private static final Pattern CODE_MATH_PATTERN = Pattern.compile(
            "(?i)\\b(write a program|algorithm|calculate|compute|solve|pseudo[- ]?code|time complexity|equation|formula|implement|code)\\b"
    );

    // Heuristics for MCQ choices: uppercase choices (A), (B), (C), (D)
    private static final Pattern MCQ_PATTERN = Pattern.compile(
            "(?:^|\\s)(?:[A-D]\\)|\\([A-D]\\)|[A-D]\\.)(?=\\s)"
    );

    @Override
    public List<Question> extractQuestions(String rawPaperText) throws ParsingException {
        if (rawPaperText == null || rawPaperText.trim().isEmpty()) {
            throw new ParsingException("Question paper text is empty. Cannot extract questions.");
        }

        List<Question> questions = new ArrayList<>();
        String[] lines = rawPaperText.replace("\r\n", "\n").replace("\r", "\n").split("\n");

        String currentSection = "General";
        String currentQuestionNumber = null;
        StringBuilder currentQuestionText = new StringBuilder();

        for (String line : lines) {
            String trimmed = line.trim();
            if (trimmed.isEmpty()) {
                if (currentQuestionNumber != null) {
                    currentQuestionText.append("\n");
                }
                continue;
            }

            // 1. Check if line is a Section Heading
            Matcher sectionMatcher = SECTION_PATTERN.matcher(trimmed);
            if (sectionMatcher.matches()) {
                // If we were parsing a question, finalize it before switching sections
                if (currentQuestionNumber != null) {
                    questions.add(buildQuestion(currentQuestionNumber, currentQuestionText.toString(), currentSection));
                    currentQuestionNumber = null;
                    currentQuestionText.setLength(0);
                }
                String secId = sectionMatcher.group(1);
                String secTitle = sectionMatcher.group(2);
                currentSection = "Section " + secId + (secTitle.isEmpty() ? "" : ": " + secTitle.trim());
                continue;
            }

            // 2. Check if line starts a new Question
            Matcher qMatcher = QUESTION_START_PATTERN.matcher(trimmed);
            if (qMatcher.matches()) {
                // Finalize previous question if one exists
                if (currentQuestionNumber != null) {
                    questions.add(buildQuestion(currentQuestionNumber, currentQuestionText.toString(), currentSection));
                    currentQuestionText.setLength(0);
                }

                // Identify question number string
                String num = qMatcher.group(1) != null ? qMatcher.group(1) :
                             qMatcher.group(2) != null ? qMatcher.group(2) :
                             qMatcher.group(3);
                currentQuestionNumber = num != null ? "Q" + num : "Q" + (questions.size() + 1);

                // Start accumulator with remainder of line
                String remainder = qMatcher.group(4);
                if (remainder != null && !remainder.trim().isEmpty()) {
                    currentQuestionText.append(remainder.trim());
                }
            } else {
                // Continuation line of current question or header noise
                if (currentQuestionNumber != null) {
                    if (currentQuestionText.length() > 0) {
                        currentQuestionText.append("\n");
                    }
                    currentQuestionText.append(trimmed);
                }
            }
        }

        // Finalize last question in document
        if (currentQuestionNumber != null && currentQuestionText.length() > 0) {
            questions.add(buildQuestion(currentQuestionNumber, currentQuestionText.toString(), currentSection));
        }

        // Fallback: If no structured "Q1." format was detected, split by double line breaks
        if (questions.isEmpty()) {
            questions = fallbackExtraction(rawPaperText);
        }

        return questions;
    }

    /**
     * Constructs a Question subclass instance with parsed marks, sub-parts, and type heuristic.
     */
    private Question buildQuestion(String qNumber, String rawText, String section) {
        double marks = extractMarks(rawText);
        int subParts = countSubParts(rawText);
        String cleanedText = cleanMarksTags(rawText);
        QuestionType type = inferQuestionType(cleanedText, marks, subParts);

        Question q = QuestionFactory.createQuestion(type, qNumber, cleanedText, marks, section);
        q.setSubPartCount(subParts);
        return q;
    }

    /**
     * Extracts marks from strings like "[5]", "[10 Marks]", "(5m)". Defaults to 5.0 marks if not found.
     */
    private double extractMarks(String text) {
        Matcher matcher = MARKS_PATTERN.matcher(text);
        if (matcher.find()) {
            for (int i = 1; i <= matcher.groupCount(); i++) {
                String val = matcher.group(i);
                if (val != null) {
                    try {
                        return Double.parseDouble(val.trim());
                    } catch (NumberFormatException ignored) {
                    }
                }
            }
        }
        return 5.0; // Default mark allocation
    }

    /**
     * Removes marks tokens from the final question text for clean display.
     */
    private String cleanMarksTags(String text) {
        return MARKS_PATTERN.matcher(text).replaceAll("").trim();
    }

    /**
     * Counts the occurrence of sub-parts (e.g. (a), (b), (i), (ii)).
     */
    private int countSubParts(String text) {
        int count = 0;
        Matcher matcher = SUB_PART_PATTERN.matcher(text);
        while (matcher.find()) {
            count++;
        }
        return Math.max(1, count);
    }

    /**
     * Heuristically determines question type based on content patterns and mark weight.
     */
    private QuestionType inferQuestionType(String text, double marks, int subParts) {
        // 1. Check for MCQ choices (must have uppercase options and typical low marks)
        if (marks <= 3.0) {
            Matcher mcqMatcher = MCQ_PATTERN.matcher(text);
            int choiceCount = 0;
            while (mcqMatcher.find()) {
                choiceCount++;
            }
            if (choiceCount >= 3) {
                return QuestionType.MCQ;
            }
        }

        // 2. Check for Problem / Code / Math Questions
        if (CODE_MATH_PATTERN.matcher(text).find()) {
            return QuestionType.PROBLEM;
        }

        // 3. Check for Long Answer / Essay (high marks, multiple subparts, or extensive text)
        if (marks >= 8.0 || subParts >= 3 || text.length() > 300) {
            return QuestionType.LONG_ANSWER;
        }

        // 4. Default to Short Answer
        return QuestionType.SHORT_ANSWER;
    }

    /**
     * Fallback extractor when standard numbering patterns are absent.
     */
    private List<Question> fallbackExtraction(String text) {
        List<Question> result = new ArrayList<>();
        String[] paragraphs = text.split("\n\\s*\n");
        int index = 1;
        for (String para : paragraphs) {
            String trimmed = para.trim();
            if (trimmed.length() > 15) { // Skip trivial headers
                double marks = extractMarks(trimmed);
                String cleaned = cleanMarksTags(trimmed);
                Question q = QuestionFactory.createQuestion(
                        QuestionType.SHORT_ANSWER,
                        "Q" + index++,
                        cleaned,
                        marks,
                        "Section A"
                );
                result.add(q);
            }
        }
        return result;
    }
}
