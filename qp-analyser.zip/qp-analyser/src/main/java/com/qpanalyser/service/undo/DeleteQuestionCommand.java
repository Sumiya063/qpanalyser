// File: src/main/java/com/qpanalyser/service/undo/DeleteQuestionCommand.java
package com.qpanalyser.service.undo;

import com.qpanalyser.model.Question;

import java.util.List;

/**
 * Command: Delete Question
 * Author: DSA & Database Lead
 */
public class DeleteQuestionCommand implements EditCommand {

    private final List<Question> questionList;
    private final Question deletedQuestion;
    private final int originalIndex;

    public DeleteQuestionCommand(List<Question> questionList, Question questionToDelete, int index) {
        this.questionList = questionList;
        this.deletedQuestion = questionToDelete;
        this.originalIndex = index;
    }

    @Override
    public void execute() {
        questionList.remove(deletedQuestion);
    }

    @Override
    public void undo() {
        if (originalIndex >= 0 && originalIndex <= questionList.size()) {
            questionList.add(originalIndex, deletedQuestion);
        } else {
            questionList.add(deletedQuestion);
        }
    }

    @Override
    public String getDescription() {
        return "Delete " + deletedQuestion.getQuestionNumber();
    }
}
