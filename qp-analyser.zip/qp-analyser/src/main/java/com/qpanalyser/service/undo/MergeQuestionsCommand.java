// File: src/main/java/com/qpanalyser/service/undo/MergeQuestionsCommand.java
package com.qpanalyser.service.undo;

import com.qpanalyser.model.Question;

import java.util.List;

/**
 * Command: Merge Two Questions
 * Author: DSA & Database Lead
 */
public class MergeQuestionsCommand implements EditCommand {

    private final List<Question> questionList;
    private final Question first;
    private final Question second;
    private final int secondIndex;

    // Previous state of first question
    private final String originalFirstText;
    private final double originalFirstMarks;
    private final int originalFirstSubParts;

    public MergeQuestionsCommand(List<Question> questionList, Question first, Question second, int secondIndex) {
        this.questionList = questionList;
        this.first = first;
        this.second = second;
        this.secondIndex = secondIndex;

        this.originalFirstText = first.getQuestionText();
        this.originalFirstMarks = first.getMarks();
        this.originalFirstSubParts = first.getSubPartCount();
    }

    @Override
    public void execute() {
        // Merge text, marks, and sub-parts into first question
        first.setQuestionText(originalFirstText + "\n" + second.getQuestionText());
        first.setMarks(originalFirstMarks + second.getMarks());
        first.setSubPartCount(originalFirstSubParts + second.getSubPartCount());

        // Remove second question from list
        questionList.remove(second);
    }

    @Override
    public void undo() {
        // Restore first question state
        first.setQuestionText(originalFirstText);
        first.setMarks(originalFirstMarks);
        first.setSubPartCount(originalFirstSubParts);

        // Re-insert second question at its original position
        if (secondIndex >= 0 && secondIndex <= questionList.size()) {
            questionList.add(secondIndex, second);
        } else {
            questionList.add(second);
        }
    }

    @Override
    public String getDescription() {
        return "Merge " + first.getQuestionNumber() + " with " + second.getQuestionNumber();
    }
}
