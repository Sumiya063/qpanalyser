// File: src/main/java/com/qpanalyser/service/QuestionReviewService.java
package com.qpanalyser.service;

import com.qpanalyser.exception.ParsingException;
import com.qpanalyser.model.Question;
import com.qpanalyser.service.extractor.QuestionExtractor;
import com.qpanalyser.service.extractor.RegexQuestionExtractor;
import com.qpanalyser.service.undo.*;

import java.util.List;

/**
 * Service: Question Review, Splitting, Merging and Undo Integration
 * Author: Core Java & OOP Lead
 * 
 * Coordinates question editing operations and manufactures Command objects for the UndoManager.
 */
public class QuestionReviewService {

    private final QuestionExtractor defaultExtractor;

    public QuestionReviewService() {
        this.defaultExtractor = new RegexQuestionExtractor();
    }

    public QuestionReviewService(QuestionExtractor extractor) {
        this.defaultExtractor = extractor != null ? extractor : new RegexQuestionExtractor();
    }

    /**
     * Extracts questions from raw document text using the configured extractor strategy.
     */
    public List<Question> extract(String rawText) throws ParsingException {
        return defaultExtractor.extractQuestions(rawText);
    }

    /**
     * Creates and executes a DeleteQuestionCommand via the UndoManager.
     */
    public void deleteQuestion(List<Question> list, Question question, UndoManager undoManager) {
        if (question == null || list == null) return;
        int idx = list.indexOf(question);
        DeleteQuestionCommand cmd = new DeleteQuestionCommand(list, question, idx);
        undoManager.executeCommand(cmd);
    }

    /**
     * Creates and executes an AddQuestionCommand via the UndoManager.
     */
    public void addQuestion(List<Question> list, Question question, int index, UndoManager undoManager) {
        if (question == null || list == null) return;
        AddQuestionCommand cmd = new AddQuestionCommand(list, question, index);
        undoManager.executeCommand(cmd);
    }

    /**
     * Creates and executes an EditQuestionCommand via the UndoManager.
     */
    public void editQuestion(Question question, String newText, double newMarks, String newSection,
                             int newSubParts, UndoManager undoManager) {
        if (question == null) return;
        EditQuestionCommand cmd = new EditQuestionCommand(question, newText, newMarks, newSection, newSubParts);
        undoManager.executeCommand(cmd);
    }

    /**
     * Merges two questions together and pushes the command to the UndoManager.
     */
    public void mergeQuestions(List<Question> list, Question first, Question second, UndoManager undoManager) {
        if (list == null || first == null || second == null || first == second) return;
        int secondIdx = list.indexOf(second);
        MergeQuestionsCommand cmd = new MergeQuestionsCommand(list, first, second, secondIdx);
        undoManager.executeCommand(cmd);
    }

    /**
     * Splits a question into two distinct sub-questions and records it in the UndoManager.
     */
    public void splitQuestion(List<Question> list, Question original, String part1Text, String part2Text,
                              double part1Marks, double part2Marks, UndoManager undoManager) {
        if (list == null || original == null) return;
        SplitQuestionCommand cmd = new SplitQuestionCommand(list, original, part1Text, part2Text, part1Marks, part2Marks);
        undoManager.executeCommand(cmd);
    }

    /**
     * Re-indexes question numbers consecutively (Q1, Q2, Q3...).
     */
    public void renumberQuestions(List<Question> list) {
        if (list == null) return;
        int index = 1;
        for (Question q : list) {
            q.setQuestionNumber("Q" + index++);
        }
    }
}
