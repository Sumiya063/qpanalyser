// File: src/main/java/com/qpanalyser/service/AuthService.java
package com.qpanalyser.service;

import com.qpanalyser.dao.UserDAO;
import com.qpanalyser.exception.AuthenticationException;
import com.qpanalyser.exception.DatabaseException;
import com.qpanalyser.model.Role;
import com.qpanalyser.model.User;
import com.qpanalyser.util.PasswordUtil;
import com.qpanalyser.util.ValidationUtil;

import java.util.Optional;

/**
 * Business Service: User Authentication and Registration
 * Author: Core Java & OOP Lead
 * 
 * Enforces security rules, password hashing, and session management.
 */
public class AuthService {

    private final UserDAO userDAO;

    public AuthService() {
        this.userDAO = new UserDAO();
    }

    public AuthService(UserDAO userDAO) {
        this.userDAO = userDAO;
    }

    /**
     * Authenticates a user against stored salted SHA-256 credentials.
     * 
     * @param username Provided username
     * @param password Plaintext password
     * @return Authenticated User object
     * @throws AuthenticationException if verification fails
     * @throws DatabaseException if persistence error occurs
     */
    public User login(String username, String password) throws AuthenticationException, DatabaseException {
        if (!ValidationUtil.isNotEmpty(username) || !ValidationUtil.isNotEmpty(password)) {
            throw new AuthenticationException("Please enter both username and password.");
        }

        Optional<User> userOpt = userDAO.findByUsername(username.trim());
        if (userOpt.isEmpty()) {
            throw new AuthenticationException("Invalid username or password.");
        }

        User user = userOpt.get();
        boolean matches = PasswordUtil.verifyPassword(password, user.getSalt(), user.getPasswordHash());
        if (!matches) {
            throw new AuthenticationException("Invalid username or password.");
        }

        // Establish session
        SessionManager.getInstance().setCurrentUser(user);
        return user;
    }

    /**
     * Registers a new user account with role TEACHER or ADMIN.
     */
    public User register(String username, String password, String confirmPassword,
                         String fullName, String email, Role role)
            throws AuthenticationException, DatabaseException {

        // Validate Full Name
        if (!ValidationUtil.isNotEmpty(fullName)) {
            throw new AuthenticationException("Full Name cannot be empty.");
        }

        // Validate Username
        if (!ValidationUtil.isValidUsername(username)) {
            throw new AuthenticationException("Username must be 3-30 characters alphanumeric or underscore.");
        }

        // Validate Email
        if (!ValidationUtil.isValidEmail(email)) {
            throw new AuthenticationException("Please provide a valid email address.");
        }

        // Validate Password Length
        if (!ValidationUtil.isValidPassword(password)) {
            throw new AuthenticationException("Password must be at least 6 characters long.");
        }

        // Validate Password Confirmation
        if (!password.equals(confirmPassword)) {
            throw new AuthenticationException("Passwords do not match.");
        }

        // Check Unique Username
        if (userDAO.existsByUsername(username.trim())) {
            throw new AuthenticationException("Username '" + username.trim() + "' is already in use.");
        }

        // Check Unique Email
        if (userDAO.existsByEmail(email.trim())) {
            throw new AuthenticationException("Email '" + email.trim() + "' is already registered.");
        }

        // Hash password with salt
        String salt = PasswordUtil.generateSalt();
        String hash = PasswordUtil.hashPassword(password, salt);

        User newUser = new User(
                username.trim(),
                hash,
                salt,
                fullName.trim(),
                email.trim().toLowerCase(),
                role != null ? role : Role.TEACHER
        );

        return userDAO.save(newUser);
    }
}
