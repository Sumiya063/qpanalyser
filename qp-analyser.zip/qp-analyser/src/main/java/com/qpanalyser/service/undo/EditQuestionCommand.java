// File: src/main/java/com/qpanalyser/service/undo/EditQuestionCommand.java
package com.qpanalyser.service.undo;

import com.qpanalyser.model.BloomLevel;
import com.qpanalyser.model.Question;

/**
 * Command: Modify Question Attributes
 * Author: DSA & Database Lead
 */
public class EditQuestionCommand implements EditCommand {

    private final Question question;

    // Previous snapshot
    private final String oldText;
    private final double oldMarks;
    private final String oldSection;
    private final int oldSubParts;

    // New snapshot
    private final String newText;
    private final double newMarks;
    private final String newSection;
    private final int newSubParts;

    public EditQuestionCommand(Question question, String newText, double newMarks, String newSection, int newSubParts) {
        this.question = question;

        this.oldText = question.getQuestionText();
        this.oldMarks = question.getMarks();
        this.oldSection = question.getSection();
        this.oldSubParts = question.getSubPartCount();

        this.newText = newText;
        this.newMarks = newMarks;
        this.newSection = newSection;
        this.newSubParts = newSubParts;
    }

    @Override
    public void execute() {
        question.setQuestionText(newText);
        question.setMarks(newMarks);
        question.setSection(newSection);
        question.setSubPartCount(newSubParts);
    }

    @Override
    public void undo() {
        question.setQuestionText(oldText);
        question.setMarks(oldMarks);
        question.setSection(oldSection);
        question.setSubPartCount(oldSubParts);
    }

    @Override
    public String getDescription() {
        return "Edit " + question.getQuestionNumber();
    }
}
