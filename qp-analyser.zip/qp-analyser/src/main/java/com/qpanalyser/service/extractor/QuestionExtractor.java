// File: src/main/java/com/qpanalyser/service/extractor/QuestionExtractor.java
package com.qpanalyser.service.extractor;

import com.qpanalyser.exception.ParsingException;
import com.qpanalyser.model.Question;

import java.util.List;

/**
 * OOP Concept: Strategy Design Pattern (Interface Contract)
 * Author: Core Java & OOP Lead
 * 
 * Defines the contract for parsing question items out of unstructured question paper text.
 */
public interface QuestionExtractor {

    /**
     * Extracts an ordered list of polymorphic Question objects from raw paper text.
     * 
     * @param rawPaperText The full text extracted from the document
     * @return List of parsed Question instances
     * @throws ParsingException if extraction rules fail critically
     */
    List<Question> extractQuestions(String rawPaperText) throws ParsingException;
}
