// File: src/main/java/com/qpanalyser/service/PaperAnalysisService.java
package com.qpanalyser.service;

import com.qpanalyser.analyzer.*;
import com.qpanalyser.dao.AnalysisResultDAO;
import com.qpanalyser.dao.BloomVerbDAO;
import com.qpanalyser.dao.SettingsDAO;
import com.qpanalyser.dsa.DuplicateDetector;
import com.qpanalyser.dsa.QuestionRanker;
import com.qpanalyser.exception.DatabaseException;
import com.qpanalyser.model.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Core Business Service: AI Question Paper Analysis Engine
 * Author: Core Java & OOP Lead
 * 
 * Orchestrates Bloom's taxonomy classification, multi-factor difficulty scoring,
 * balance verdict evaluation against target ratios, and actionable rule-based pedagogical suggestions.
 */
public class PaperAnalysisService {

    private final BloomClassifier bloomClassifier;
    private final DifficultyScorer difficultyScorer;
    private final FeatureExtractor featureExtractor;
    private final AnalysisResultDAO analysisResultDAO;
    private final SettingsDAO settingsDAO;
    private final BloomVerbDAO bloomVerbDAO;

    public PaperAnalysisService() {
        this.bloomClassifier = new TrieBloomClassifier();
        this.difficultyScorer = new WeightedDifficultyScorer();
        this.featureExtractor = new FeatureExtractor();
        this.analysisResultDAO = new AnalysisResultDAO();
        this.settingsDAO = new SettingsDAO();
        this.bloomVerbDAO = new BloomVerbDAO();
        loadDatabaseConfigurations();
    }

    public PaperAnalysisService(BloomClassifier bloomClassifier, DifficultyScorer difficultyScorer,
                                FeatureExtractor featureExtractor, AnalysisResultDAO dao,
                                SettingsDAO settingsDAO, BloomVerbDAO verbDAO) {
        this.bloomClassifier = bloomClassifier;
        this.difficultyScorer = difficultyScorer;
        this.featureExtractor = featureExtractor;
        this.analysisResultDAO = dao;
        this.settingsDAO = settingsDAO;
        this.bloomVerbDAO = verbDAO;
        loadDatabaseConfigurations();
    }

    private void loadDatabaseConfigurations() {
        try {
            // Load custom settings from MySQL if available
            Map<String, String> settings = settingsDAO.getAllAsMap();
            if (difficultyScorer instanceof WeightedDifficultyScorer weightedScorer) {
                weightedScorer.configureFromSettings(settings);
            }
            // Load Bloom verbs dictionary into Trie if available
            if (bloomClassifier instanceof TrieBloomClassifier trieClassifier) {
                List<BloomVerb> verbs = bloomVerbDAO.findAll();
                if (!verbs.isEmpty()) {
                    trieClassifier.loadVerbs(verbs);
                }
            }
        } catch (Exception e) {
            // Non-fatal: falls back to built-in defaults
        }
    }

    /**
     * Executes the comprehensive analytical evaluation pipeline over a question paper.
     * 
     * @param paper The Question Paper entity
     * @return Generated AnalysisResult
     */
    public AnalysisResult analyzePaper(Paper paper) throws DatabaseException {
        if (paper == null || paper.getQuestions() == null || paper.getQuestions().isEmpty()) {
            throw new IllegalArgumentException("Cannot analyze an empty question paper.");
        }

        List<Question> questions = paper.getQuestions();
        double totalMarksSum = 0.0;
        double weightedDifficultySum = 0.0;

        int countEasy = 0, countMed = 0, countHard = 0;
        double marksEasy = 0.0, marksMed = 0.0, marksHard = 0.0;

        int remCount = 0, undCount = 0, appCount = 0, anaCount = 0, evaCount = 0, creCount = 0;

        // 1. Per-Question NLP & Algorithmic Analysis
        for (Question q : questions) {
            // Step 1: Bloom Classification
            BloomLevel bloom = bloomClassifier.classify(q);
            q.setBloomLevel(bloom);

            // Step 2: Feature Extraction
            FeatureExtractor.QuestionFeatures features = featureExtractor.extractFeatures(
                    q.getQuestionText(), q.getMarks(), q.getSubPartCount()
            );

            // Step 3: Difficulty Scoring (0 - 100)
            double score = difficultyScorer.calculateDifficultyScore(q, features);
            q.setDifficultyScore(score);

            // Step 4: Categorical Difficulty Assignment
            DifficultyLevel diffLevel = difficultyScorer.determineDifficultyLevel(score);
            q.setDifficultyLevel(diffLevel);

            // Accumulate statistics
            totalMarksSum += q.getMarks();
            weightedDifficultySum += (score * q.getMarks());

            switch (diffLevel) {
                case EASY -> { countEasy++; marksEasy += q.getMarks(); }
                case MEDIUM -> { countMed++; marksMed += q.getMarks(); }
                case HARD -> { countHard++; marksHard += q.getMarks(); }
            }

            switch (bloom) {
                case REMEMBER -> remCount++;
                case UNDERSTAND -> undCount++;
                case APPLY -> appCount++;
                case ANALYZE -> anaCount++;
                case EVALUATE -> evaCount++;
                case CREATE -> creCount++;
            }
        }

        // 2. Paper-Level Aggregation
        double overallDifficulty = totalMarksSum > 0 ? (weightedDifficultySum / totalMarksSum) : 50.0;
        overallDifficulty = Math.round(overallDifficulty * 10.0) / 10.0;

        double easyPct = totalMarksSum > 0 ? (marksEasy / totalMarksSum) * 100.0 : 0.0;
        double medPct  = totalMarksSum > 0 ? (marksMed  / totalMarksSum) * 100.0 : 0.0;
        double hardPct = totalMarksSum > 0 ? (marksHard / totalMarksSum) * 100.0 : 0.0;

        easyPct = Math.round(easyPct * 10.0) / 10.0;
        medPct  = Math.round(medPct * 10.0) / 10.0;
        hardPct = Math.round(hardPct * 10.0) / 10.0;

        // 3. Balance Verdict Evaluation
        String verdict = evaluateBalanceVerdict(paper, easyPct, medPct, hardPct);

        // 4. Rule-Based Pedagogical Suggestions
        String suggestions = generateSuggestions(paper, questions, easyPct, medPct, hardPct,
                remCount, undCount, appCount, anaCount, evaCount, creCount);

        // 5. Construct Result Entity
        AnalysisResult result = new AnalysisResult(
                paper.getId(), overallDifficulty, easyPct, medPct, hardPct, verdict, suggestions
        );
        result.setRememberCount(remCount);
        result.setUnderstandCount(undCount);
        result.setApplyCount(appCount);
        result.setAnalyzeCount(anaCount);
        result.setEvaluateCount(evaCount);
        result.setCreateCount(creCount);

        // 6. Persist to MySQL if paper exists in database
        if (paper.getId() > 0) {
            analysisResultDAO.save(result);
        }

        return result;
    }

    private String evaluateBalanceVerdict(Paper paper, double easyPct, double medPct, double hardPct) {
        double targetEasy = paper.getTargetEasy() > 0 ? paper.getTargetEasy() : 30.0;
        double targetMed  = paper.getTargetMedium() > 0 ? paper.getTargetMedium() : 50.0;
        double targetHard = paper.getTargetHard() > 0 ? paper.getTargetHard() : 20.0;

        double easyDelta = easyPct - targetEasy;
        double hardDelta = hardPct - targetHard;

        if (Math.abs(easyDelta) <= 8.0 && Math.abs(hardDelta) <= 8.0) {
            return "Balanced Examination Paper";
        } else if (easyDelta > 10.0) {
            return "Unbalanced: Skewed Easy (Excessive Recall Questions)";
        } else if (hardDelta > 10.0) {
            return "Unbalanced: Overly Difficult (Exceeds Student Cognitive Norms)";
        } else if (medPct < targetMed - 12.0) {
            return "Unbalanced: Polarized Distribution (Deficit of Medium Questions)";
        }
        return "Moderately Balanced";
    }

    private String generateSuggestions(Paper paper, List<Question> questions,
                                       double easyPct, double medPct, double hardPct,
                                       int rem, int und, int app, int ana, int eva, int cre) {
        List<String> list = new ArrayList<>();
        int totalQuestions = questions.size();

        // Rule 1: Bloom Recall Bias
        int lowerOrder = rem + und;
        int higherOrder = app + ana + eva + cre;
        double lowerOrderPct = totalQuestions > 0 ? ((double) lowerOrder / totalQuestions) * 100.0 : 0.0;

        if (lowerOrderPct > 60.0) {
            list.add("• Bloom's Taxonomy: Lower-order cognitive questions (Remember/Understand) constitute " +
                    String.format("%.0f%%", lowerOrderPct) + " of the paper. Suggest substituting 2 recall questions with Apply or Analyze tasks.");
        } else if (higherOrder < 2) {
            list.add("• Bloom's Taxonomy: Insufficient higher-order thinking (Evaluate/Create). Consider adding a synthesis problem or architectural design prompt.");
        }

        // Rule 2: Difficulty Target Skew
        if (easyPct > paper.getTargetEasy() + 8.0) {
            list.add("• Difficulty Balance: Easy marks (" + easyPct + "%) exceed target (" + paper.getTargetEasy() + "%). Elevate question complexity by introducing numerical proofs or coding dry-runs.");
        }
        if (hardPct > paper.getTargetHard() + 8.0) {
            list.add("• Difficulty Balance: Hard marks (" + hardPct + "%) exceed recommended threshold. Provide additional sub-part scaffolding to assist student progression.");
        }

        // Rule 3: Near-Duplicate Detection Check
        List<DuplicateDetector.DuplicatePair> duplicates = DuplicateDetector.findNearDuplicates(questions, 0.75);
        if (!duplicates.isEmpty()) {
            for (DuplicateDetector.DuplicatePair pair : duplicates) {
                list.add("• Duplicate Warning: Questions " + pair.questionA().getQuestionNumber() + " and " +
                        pair.questionB().getQuestionNumber() + " share high lexical overlap (" +
                        String.format("%.0f%%", pair.similarityPercentage() * 100.0) + " similarity). Verify uniqueness.");
            }
        }

        // Rule 4: Total Questions and Mark Allocations
        if (totalQuestions < 5) {
            list.add("• Structure: Paper contains only " + totalQuestions + " questions. Consider broadening subject coverage across more topics.");
        }

        if (list.isEmpty()) {
            list.add("• Excellent! The examination paper adheres closely to target difficulty distributions and Bloom's Revised Taxonomy levels.");
        }

        return String.join("\n", list);
    }
}
