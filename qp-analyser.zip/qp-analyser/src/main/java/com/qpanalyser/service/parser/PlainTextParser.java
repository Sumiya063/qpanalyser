// File: src/main/java/com/qpanalyser/service/parser/PlainTextParser.java
package com.qpanalyser.service.parser;

import com.qpanalyser.exception.InvalidPaperException;
import com.qpanalyser.exception.ParsingException;

import java.io.File;
import java.io.IOException;
import java.nio.charset.MalformedInputException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;

/**
 * OOP Concept: Strategy Pattern Implementation
 * Author: DSA & Database Lead
 * 
 * Extracts text from standard plain-text (.txt) question papers.
 * Time Complexity: O(N) where N is the character count of the file.
 */
public class PlainTextParser implements DocumentParser {

    @Override
    public String parse(File file) throws ParsingException, InvalidPaperException {
        if (file == null || !file.exists()) {
            throw new InvalidPaperException("File does not exist or was not selected.");
        }

        try {
            String content;
            try {
                // Attempt standard UTF-8 read
                content = Files.readString(file.toPath(), StandardCharsets.UTF_8);
            } catch (MalformedInputException e) {
                // Fallback to ISO-8859-1 for legacy text files
                content = Files.readString(file.toPath(), StandardCharsets.ISO_8859_1);
            }

            if (content == null || content.trim().isEmpty()) {
                throw new InvalidPaperException("The uploaded text file is completely empty.");
            }

            // Normalize Windows CRLF and Mac CR to standard LF
            return content.replace("\r\n", "\n").replace("\r", "\n").trim();

        } catch (IOException e) {
            throw new ParsingException("Failed to read plain text question paper: " + e.getMessage(), e);
        }
    }

    @Override
    public boolean supports(String fileExtension) {
        return fileExtension != null && fileExtension.equalsIgnoreCase("txt");
    }
}
