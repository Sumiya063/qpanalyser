// File: src/main/java/com/qpanalyser/service/undo/AddQuestionCommand.java
package com.qpanalyser.service.undo;

import com.qpanalyser.model.Question;

import java.util.List;

/**
 * Command: Add Question
 * Author: DSA & Database Lead
 */
public class AddQuestionCommand implements EditCommand {

    private final List<Question> questionList;
    private final Question questionToAdd;
    private final int insertIndex;

    public AddQuestionCommand(List<Question> questionList, Question questionToAdd, int insertIndex) {
        this.questionList = questionList;
        this.questionToAdd = questionToAdd;
        this.insertIndex = insertIndex;
    }

    @Override
    public void execute() {
        if (insertIndex >= 0 && insertIndex <= questionList.size()) {
            questionList.add(insertIndex, questionToAdd);
        } else {
            questionList.add(questionToAdd);
        }
    }

    @Override
    public void undo() {
        questionList.remove(questionToAdd);
    }

    @Override
    public String getDescription() {
        return "Add " + questionToAdd.getQuestionNumber();
    }
}
