// File: src/main/java/com/qpanalyser/service/undo/EditCommand.java
package com.qpanalyser.service.undo;

/**
 * OOP Concept: Command Design Pattern (Behavioral Pattern)
 * Author: DSA & Database Lead
 * 
 * Represents an undoable editing action performed on questions in the review table.
 */
public interface EditCommand {

    /**
     * Executes the editing action.
     */
    void execute();

    /**
     * Reverses the action, restoring the previous state.
     */
    void undo();

    /**
     * Re-applies the action after an undo.
     */
    default void redo() {
        execute();
    }

    /**
     * Human-readable description of the action for the UI status label (e.g. "Delete Q3").
     */
    String getDescription();
}
