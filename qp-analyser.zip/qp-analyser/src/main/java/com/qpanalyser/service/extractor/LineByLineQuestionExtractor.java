// File: src/main/java/com/qpanalyser/service/extractor/LineByLineQuestionExtractor.java
package com.qpanalyser.service.extractor;

import com.qpanalyser.exception.ParsingException;
import com.qpanalyser.model.Question;

import java.util.List;

/**
 * OOP Concept: Strategy Design Pattern (Alternative Strategy Implementation)
 * Author: Core Java & OOP Lead
 * 
 * Demonstrates the Strategy Pattern with an alternative sequential parser.
 * Delegates to RegexQuestionExtractor for standardized rule parsing while
 * providing a pluggable alternative extractor strategy.
 */
public class LineByLineQuestionExtractor implements QuestionExtractor {

    private final RegexQuestionExtractor delegate = new RegexQuestionExtractor();

    @Override
    public List<Question> extractQuestions(String rawPaperText) throws ParsingException {
        // Alternative strategy implementation that performs line-level preprocessing
        if (rawPaperText == null) {
            throw new ParsingException("Raw paper text cannot be null.");
        }
        // Normalize whitespace and delegate to regex parsing pipeline
        String normalized = rawPaperText.replaceAll("\\t", "    ").trim();
        return delegate.extractQuestions(normalized);
    }
}
