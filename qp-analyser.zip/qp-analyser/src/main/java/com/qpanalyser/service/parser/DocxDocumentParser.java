// File: src/main/java/com/qpanalyser/service/parser/DocxDocumentParser.java
package com.qpanalyser.service.parser;

import com.qpanalyser.exception.InvalidPaperException;
import com.qpanalyser.exception.ParsingException;
import org.apache.poi.xwpf.extractor.XWPFWordExtractor;
import org.apache.poi.xwpf.usermodel.XWPFDocument;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

/**
 * OOP Concept: Strategy Pattern Implementation & POI Library Integration
 * Author: DSA & Database Lead
 * 
 * Extracts text from Microsoft Word (.docx) question papers using Apache POI.
 * Time Complexity: O(P * W) where P is paragraphs and W is words per paragraph.
 */
public class DocxDocumentParser implements DocumentParser {

    @Override
    public String parse(File file) throws ParsingException, InvalidPaperException {
        if (file == null || !file.exists()) {
            throw new InvalidPaperException("Selected DOCX file does not exist.");
        }

        // OOP Concept: Try-with-resources for multiple stream & document handles
        try (FileInputStream fis = new FileInputStream(file);
             XWPFDocument document = new XWPFDocument(fis);
             XWPFWordExtractor extractor = new XWPFWordExtractor(document)) {

            String text = extractor.getText();

            if (text == null || text.trim().isEmpty()) {
                throw new InvalidPaperException("The uploaded Word DOCX document contains no text.");
            }

            return text.replace("\r\n", "\n").replace("\r", "\n").trim();

        } catch (IOException e) {
            throw new ParsingException("Failed to read Word DOCX question paper: " + e.getMessage(), e);
        }
    }

    @Override
    public boolean supports(String fileExtension) {
        return fileExtension != null && fileExtension.equalsIgnoreCase("docx");
    }
}
