// File: src/main/java/com/qpanalyser/exception/AuthenticationException.java
package com.qpanalyser.exception;

/**
 * OOP Concept: Custom Exception
 * Author: Core Java & OOP Lead
 * 
 * Thrown when an authentication or authorization failure occurs,
 * such as invalid credentials, disabled accounts, or unauthorized role access.
 */
public class AuthenticationException extends Exception {
    
    public AuthenticationException(String message) {
        super(message);
    }

    public AuthenticationException(String message, Throwable cause) {
        super(message, cause);
    }
}
