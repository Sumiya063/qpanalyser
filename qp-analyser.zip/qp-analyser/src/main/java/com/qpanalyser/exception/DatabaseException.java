// File: src/main/java/com/qpanalyser/exception/DatabaseException.java
package com.qpanalyser.exception;

/**
 * OOP Concept: Custom Exception
 * Author: Core Java & OOP Lead
 * 
 * Thrown when a database persistence, connection, or query operation fails.
 * Wraps underlying SQLExceptions to isolate the service and UI layers from JDBC details.
 */
public class DatabaseException extends Exception {

    public DatabaseException(String message) {
        super(message);
    }

    public DatabaseException(String message, Throwable cause) {
        super(message, cause);
    }
}
