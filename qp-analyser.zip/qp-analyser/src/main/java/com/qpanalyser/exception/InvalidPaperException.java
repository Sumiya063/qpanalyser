// File: src/main/java/com/qpanalyser/exception/InvalidPaperException.java
package com.qpanalyser.exception;

/**
 * OOP Concept: Custom Exception
 * Author: Core Java & OOP Lead
 * 
 * Thrown when an uploaded question paper file fails structural or business validation
 * (e.g., empty content, invalid file size, unsupported format, zero questions found).
 */
public class InvalidPaperException extends Exception {

    public InvalidPaperException(String message) {
        super(message);
    }

    public InvalidPaperException(String message, Throwable cause) {
        super(message, cause);
    }
}
