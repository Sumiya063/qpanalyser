// File: src/main/java/com/qpanalyser/exception/ParsingException.java
package com.qpanalyser.exception;

/**
 * OOP Concept: Custom Exception
 * Author: Core Java & OOP Lead
 * 
 * Thrown when an error occurs during parsing and tokenizing of question paper text,
 * PDF streams, or DOCX documents.
 */
public class ParsingException extends Exception {

    public ParsingException(String message) {
        super(message);
    }

    public ParsingException(String message, Throwable cause) {
        super(message, cause);
    }
}
