// File: src/main/java/com/qpanalyser/db/DatabaseInitializer.java
package com.qpanalyser.db;

import com.qpanalyser.exception.DatabaseException;
import com.qpanalyser.model.Role;
import com.qpanalyser.model.User;
import com.qpanalyser.util.PasswordUtil;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Database Auto-Initialization & Seeding
 * Author: DSA & Database Lead
 * 
 * Automatically verifies and runs schema.sql DDL migrations on application startup.
 * Seeds default administrator and teacher accounts with salted SHA-256 passwords
 * if the database is newly created.
 */
public class DatabaseInitializer {

    /**
     * Initializes the database tables and populates default records if empty.
     * 
     * @throws DatabaseException if schema execution fails
     */
    public static void initialize() throws DatabaseException {
        Connection conn = DatabaseConnection.getInstance().getConnection();
        executeSchemaFile(conn);
        seedDefaultUsers(conn);
    }

    /**
     * Reads schema.sql from classpath and executes non-empty SQL statements.
     */
    private static void executeSchemaFile(Connection conn) throws DatabaseException {
        try (InputStream in = DatabaseInitializer.class.getClassLoader().getResourceAsStream("schema.sql")) {
            if (in == null) {
                throw new DatabaseException("Could not find 'schema.sql' in classpath resources.");
            }

            try (BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
                 Statement statement = conn.createStatement()) {

                StringBuilder sqlBuilder = new StringBuilder();
                String line;

                while ((line = reader.readLine()) != null) {
                    String trimmed = line.trim();
                    // Skip comments and empty lines
                    if (trimmed.startsWith("--") || trimmed.startsWith("//") || trimmed.isEmpty()) {
                        continue;
                    }
                    sqlBuilder.append(line).append("\n");

                    // SQL statement terminator
                    if (trimmed.endsWith(";")) {
                        String sql = sqlBuilder.toString().trim();
                        // Remove trailing semicolon for JDBC statement
                        if (sql.endsWith(";")) {
                            sql = sql.substring(0, sql.length() - 1);
                        }
                        if (!sql.isEmpty()) {
                            try {
                                statement.execute(sql);
                            } catch (SQLException e) {
                                // Continue if duplicate key or table exists
                                if (!e.getMessage().toLowerCase().contains("already exists") &&
                                    !e.getMessage().toLowerCase().contains("duplicate")) {
                                    System.err.println("[DatabaseInitializer] SQL Notice: " + e.getMessage());
                                }
                            }
                        }
                        sqlBuilder.setLength(0);
                    }
                }
            }
        } catch (Exception e) {
            throw new DatabaseException("Failed to execute schema initialization script: " + e.getMessage(), e);
        }
    }

    /**
     * Checks if any users exist; if not, seeds default Admin and Teacher credentials.
     */
    private static void seedDefaultUsers(Connection conn) throws DatabaseException {
        String countSql = "SELECT COUNT(*) FROM users";
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(countSql)) {

            if (rs.next() && rs.getInt(1) == 0) {
                // Seed Admin: username=admin, password=admin123
                createSeedUser(conn, "admin", "admin123", "System Administrator", "admin@college.edu", Role.ADMIN);
                // Seed Teacher: username=teacher, password=teacher123
                createSeedUser(conn, "teacher", "teacher123", "Prof. CSE Faculty", "teacher@college.edu", Role.TEACHER);
                System.out.println("[DatabaseInitializer] Default accounts created: 'admin/admin123' and 'teacher/teacher123'");
            }
        } catch (SQLException e) {
            throw new DatabaseException("Failed to seed default user accounts: " + e.getMessage(), e);
        }
    }

    /**
     * Helper to insert a seeded user with salted SHA-256 password using PreparedStatement.
     */
    private static void createSeedUser(Connection conn, String username, String plainPassword,
                                       String fullName, String email, Role role) throws SQLException {
        String salt = PasswordUtil.generateSalt();
        String hash = PasswordUtil.hashPassword(plainPassword, salt);

        String insertSql = "INSERT INTO users (username, password_hash, salt, full_name, email, role) VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement pstmt = conn.prepareStatement(insertSql)) {
            pstmt.setString(1, username);
            pstmt.setString(2, hash);
            pstmt.setString(3, salt);
            pstmt.setString(4, fullName);
            pstmt.setString(5, email);
            pstmt.setString(6, role.name());
            pstmt.executeUpdate();
        }
    }
}
