// File: src/main/java/com/qpanalyser/db/DatabaseConnection.java
package com.qpanalyser.db;

import com.qpanalyser.exception.DatabaseException;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

/**
 * OOP Concept: Singleton Design Pattern
 * Author: DSA & Database Lead
 * 
 * Manages a single shared JDBC connection to the MySQL database.
 * Uses lazy initialization with thread-safe double-checked locking.
 * Reads database credentials dynamically from db.properties to prevent hardcoding.
 */
public class DatabaseConnection {

    private static volatile DatabaseConnection instance;
    private Connection connection;
    private final Properties properties = new Properties();

    // Private Constructor prevents direct instantiation from outside
    private DatabaseConnection() throws DatabaseException {
        loadProperties();
        initConnection();
    }

    /**
     * OOP Concept: Singleton Pattern (Double-checked locking)
     * 
     * @return The single active instance of DatabaseConnection
     * @throws DatabaseException if connection initialization fails
     */
    public static DatabaseConnection getInstance() throws DatabaseException {
        if (instance == null) {
            synchronized (DatabaseConnection.class) {
                if (instance == null) {
                    instance = new DatabaseConnection();
                }
            }
        }
        return instance;
    }

    /**
     * Reads database properties from src/main/resources/db.properties.
     */
    private void loadProperties() throws DatabaseException {
        try (InputStream input = getClass().getClassLoader().getResourceAsStream("db.properties")) {
            if (input == null) {
                throw new DatabaseException("Configuration file 'db.properties' not found in classpath.");
            }
            properties.load(input);
        } catch (IOException e) {
            throw new DatabaseException("Failed to read 'db.properties' file: " + e.getMessage(), e);
        }
    }

    /**
     * Initializes a new JDBC connection using driver manager.
     */
    private void initConnection() throws DatabaseException {
        String driver = properties.getProperty("db.driver", "com.mysql.cj.jdbc.Driver");
        String url = properties.getProperty("db.url");
        String user = properties.getProperty("db.user");
        String password = properties.getProperty("db.password", "");

        try {
            Class.forName(driver);
            this.connection = DriverManager.getConnection(url, user, password);
        } catch (ClassNotFoundException e) {
            throw new DatabaseException("MySQL JDBC Driver class not found: " + driver, e);
        } catch (SQLException e) {
            // Provide descriptive troubleshooting message for students
            throw new DatabaseException("Could not connect to MySQL at [" + url + "] as user [" + user + "].\n" +
                    "Troubleshooting: Please ensure your MySQL server is running and the 'qpanalyser' database exists. " +
                    "Verify credentials in src/main/resources/db.properties.\nError: " + e.getMessage(), e);
        }
    }

    /**
     * Returns an active SQL connection. Automatically reconnects if the previous connection was closed.
     * 
     * @return java.sql.Connection
     * @throws DatabaseException if unable to obtain a valid connection
     */
    public synchronized Connection getConnection() throws DatabaseException {
        try {
            if (this.connection == null || this.connection.isClosed() || !this.connection.isValid(2)) {
                initConnection();
            }
            return this.connection;
        } catch (SQLException e) {
            throw new DatabaseException("Failed to validate or reconnect to MySQL database: " + e.getMessage(), e);
        }
    }

    /**
     * Closes the active database connection when the application exits.
     */
    public synchronized void closeConnection() {
        if (this.connection != null) {
            try {
                if (!this.connection.isClosed()) {
                    this.connection.close();
                }
            } catch (SQLException ignored) {
                // Ignore closing exceptions on shutdown
            }
        }
    }

    /**
     * Quick status check for UI status bar.
     */
    public static boolean isConnected() {
        try {
            DatabaseConnection db = getInstance();
            return db.connection != null && !db.connection.isClosed();
        } catch (Exception e) {
            return false;
        }
    }
}
