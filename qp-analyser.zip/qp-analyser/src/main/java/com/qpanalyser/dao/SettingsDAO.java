// File: src/main/java/com/qpanalyser/dao/SettingsDAO.java
package com.qpanalyser.dao;

import com.qpanalyser.db.DatabaseConnection;
import com.qpanalyser.exception.DatabaseException;
import com.qpanalyser.model.Setting;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * OOP Concept: DAO Pattern & Interface Implementation
 * Author: DSA & Database Lead
 * 
 * Manages runtime configurable settings (weights, targets, thresholds) in MySQL.
 */
public class SettingsDAO implements Repository<Setting> {

    @Override
    public Optional<Setting> findById(int id) throws DatabaseException {
        String sql = "SELECT id, setting_key, setting_value, description FROM settings WHERE id = ?";
        Connection conn = DatabaseConnection.getInstance().getConnection();

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(mapResultSet(rs));
                }
            }
        } catch (SQLException e) {
            throw new DatabaseException("Failed to find setting by ID [" + id + "]: " + e.getMessage(), e);
        }
        return Optional.empty();
    }

    @Override
    public List<Setting> findAll() throws DatabaseException {
        String sql = "SELECT id, setting_key, setting_value, description FROM settings ORDER BY setting_key ASC";
        Connection conn = DatabaseConnection.getInstance().getConnection();
        List<Setting> settings = new ArrayList<>();

        try (PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            while (rs.next()) {
                settings.add(mapResultSet(rs));
            }
        } catch (SQLException e) {
            throw new DatabaseException("Failed to retrieve settings: " + e.getMessage(), e);
        }
        return settings;
    }

    @Override
    public Setting save(Setting setting) throws DatabaseException {
        String sql = "INSERT INTO settings (setting_key, setting_value, description) VALUES (?, ?, ?)";
        Connection conn = DatabaseConnection.getInstance().getConnection();

        try (PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            pstmt.setString(1, setting.getKey());
            pstmt.setString(2, setting.getValue());
            pstmt.setString(3, setting.getDescription());
            pstmt.executeUpdate();

            try (ResultSet keys = pstmt.getGeneratedKeys()) {
                if (keys.next()) {
                    setting.setId(keys.getInt(1));
                }
            }
            return setting;
        } catch (SQLException e) {
            throw new DatabaseException("Failed to save setting [" + setting.getKey() + "]: " + e.getMessage(), e);
        }
    }

    @Override
    public boolean update(Setting setting) throws DatabaseException {
        String sql = "UPDATE settings SET setting_value = ?, description = ? WHERE setting_key = ?";
        Connection conn = DatabaseConnection.getInstance().getConnection();

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, setting.getValue());
            pstmt.setString(2, setting.getDescription());
            pstmt.setString(3, setting.getKey());
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new DatabaseException("Failed to update setting [" + setting.getKey() + "]: " + e.getMessage(), e);
        }
    }

    @Override
    public boolean deleteById(int id) throws DatabaseException {
        String sql = "DELETE FROM settings WHERE id = ?";
        Connection conn = DatabaseConnection.getInstance().getConnection();

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new DatabaseException("Failed to delete setting ID [" + id + "]: " + e.getMessage(), e);
        }
    }

    public Optional<Setting> findByKey(String key) throws DatabaseException {
        String sql = "SELECT id, setting_key, setting_value, description FROM settings WHERE setting_key = ?";
        Connection conn = DatabaseConnection.getInstance().getConnection();

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, key);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(mapResultSet(rs));
                }
            }
        } catch (SQLException e) {
            throw new DatabaseException("Failed to query setting key [" + key + "]: " + e.getMessage(), e);
        }
        return Optional.empty();
    }

    public String getValue(String key, String defaultValue) {
        try {
            Optional<Setting> opt = findByKey(key);
            return opt.map(Setting::getValue).orElse(defaultValue);
        } catch (DatabaseException e) {
            return defaultValue;
        }
    }

    public Map<String, String> getAllAsMap() throws DatabaseException {
        List<Setting> list = findAll();
        Map<String, String> map = new HashMap<>();
        for (Setting s : list) {
            map.put(s.getKey(), s.getValue());
        }
        return map;
    }

    private Setting mapResultSet(ResultSet rs) throws SQLException {
        return new Setting(
                rs.getInt("id"),
                rs.getString("setting_key"),
                rs.getString("setting_value"),
                rs.getString("description")
        );
    }
}
