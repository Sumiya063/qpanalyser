// File: src/main/java/com/qpanalyser/dao/PaperDAO.java
package com.qpanalyser.dao;

import com.qpanalyser.db.DatabaseConnection;
import com.qpanalyser.exception.DatabaseException;
import com.qpanalyser.model.Paper;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * OOP Concept: DAO Pattern & Interface Implementation
 * Author: DSA & Database Lead
 * 
 * Handles persistence and querying for Question Papers.
 * Uses PreparedStatement and try-with-resources.
 */
public class PaperDAO implements Repository<Paper> {

    @Override
    public Optional<Paper> findById(int id) throws DatabaseException {
        String sql = "SELECT id, title, subject_code, academic_year, semester, total_marks, " +
                     "target_easy, target_medium, target_hard, created_by, created_at " +
                     "FROM papers WHERE id = ?";
        Connection conn = DatabaseConnection.getInstance().getConnection();

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(mapResultSetToPaper(rs));
                }
            }
        } catch (SQLException e) {
            throw new DatabaseException("Failed to find paper by ID [" + id + "]: " + e.getMessage(), e);
        }
        return Optional.empty();
    }

    @Override
    public List<Paper> findAll() throws DatabaseException {
        String sql = "SELECT id, title, subject_code, academic_year, semester, total_marks, " +
                     "target_easy, target_medium, target_hard, created_by, created_at " +
                     "FROM papers ORDER BY created_at DESC";
        Connection conn = DatabaseConnection.getInstance().getConnection();
        List<Paper> papers = new ArrayList<>();

        try (PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            while (rs.next()) {
                papers.add(mapResultSetToPaper(rs));
            }
        } catch (SQLException e) {
            throw new DatabaseException("Failed to load question papers: " + e.getMessage(), e);
        }
        return papers;
    }

    public List<Paper> findByCreatedBy(int userId) throws DatabaseException {
        String sql = "SELECT id, title, subject_code, academic_year, semester, total_marks, " +
                     "target_easy, target_medium, target_hard, created_by, created_at " +
                     "FROM papers WHERE created_by = ? ORDER BY created_at DESC";
        Connection conn = DatabaseConnection.getInstance().getConnection();
        List<Paper> papers = new ArrayList<>();

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, userId);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    papers.add(mapResultSetToPaper(rs));
                }
            }
        } catch (SQLException e) {
            throw new DatabaseException("Failed to load papers for user [" + userId + "]: " + e.getMessage(), e);
        }
        return papers;
    }

    @Override
    public Paper save(Paper paper) throws DatabaseException {
        String sql = "INSERT INTO papers (title, subject_code, academic_year, semester, total_marks, " +
                     "target_easy, target_medium, target_hard, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        Connection conn = DatabaseConnection.getInstance().getConnection();

        try (PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            pstmt.setString(1, paper.getTitle());
            pstmt.setString(2, paper.getSubjectCode());
            pstmt.setString(3, paper.getAcademicYear());
            pstmt.setString(4, paper.getSemester());
            pstmt.setDouble(5, paper.getTotalMarks());
            pstmt.setDouble(6, paper.getTargetEasy());
            pstmt.setDouble(7, paper.getTargetMedium());
            pstmt.setDouble(8, paper.getTargetHard());
            pstmt.setInt(9, paper.getCreatedBy());

            pstmt.executeUpdate();
            try (ResultSet keys = pstmt.getGeneratedKeys()) {
                if (keys.next()) {
                    paper.setId(keys.getInt(1));
                }
            }
            return paper;
        } catch (SQLException e) {
            throw new DatabaseException("Failed to persist paper [" + paper.getTitle() + "]: " + e.getMessage(), e);
        }
    }

    @Override
    public boolean update(Paper paper) throws DatabaseException {
        String sql = "UPDATE papers SET title = ?, subject_code = ?, academic_year = ?, " +
                     "semester = ?, total_marks = ?, target_easy = ?, target_medium = ?, " +
                     "target_hard = ? WHERE id = ?";
        Connection conn = DatabaseConnection.getInstance().getConnection();

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, paper.getTitle());
            pstmt.setString(2, paper.getSubjectCode());
            pstmt.setString(3, paper.getAcademicYear());
            pstmt.setString(4, paper.getSemester());
            pstmt.setDouble(5, paper.getTotalMarks());
            pstmt.setDouble(6, paper.getTargetEasy());
            pstmt.setDouble(7, paper.getTargetMedium());
            pstmt.setDouble(8, paper.getTargetHard());
            pstmt.setInt(9, paper.getId());

            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new DatabaseException("Failed to update paper ID [" + paper.getId() + "]: " + e.getMessage(), e);
        }
    }

    @Override
    public boolean deleteById(int id) throws DatabaseException {
        String sql = "DELETE FROM papers WHERE id = ?";
        Connection conn = DatabaseConnection.getInstance().getConnection();

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new DatabaseException("Failed to delete paper ID [" + id + "]: " + e.getMessage(), e);
        }
    }

    private Paper mapResultSetToPaper(ResultSet rs) throws SQLException {
        Paper paper = new Paper(
                rs.getInt("id"),
                rs.getString("title"),
                rs.getString("subject_code"),
                rs.getString("academic_year"),
                rs.getString("semester"),
                rs.getDouble("total_marks"),
                rs.getDouble("target_easy"),
                rs.getDouble("target_medium"),
                rs.getDouble("target_hard"),
                rs.getInt("created_by"),
                null
        );

        Timestamp ts = rs.getTimestamp("created_at");
        if (ts != null) {
            paper.setCreatedAt(ts.toLocalDateTime());
        }
        return paper;
    }
}
