// File: src/main/java/com/qpanalyser/dao/Repository.java
package com.qpanalyser.dao;

import com.qpanalyser.exception.DatabaseException;

import java.util.List;
import java.util.Optional;

/**
 * OOP Concept: Generics & Interface Abstraction
 * Author: DSA & Database Lead
 * 
 * Generic Data Access Object (DAO) interface.
 * Defines standard CRUD operations parameterized by entity type T.
 * 
 * @param <T> The domain entity type managed by this repository
 */
public interface Repository<T> {

    /**
     * Retrieves an entity by its unique primary key identifier.
     * 
     * @param id The entity ID
     * @return Optional containing the entity if found, or Optional.empty()
     * @throws DatabaseException if SQL query fails
     */
    Optional<T> findById(int id) throws DatabaseException;

    /**
     * Retrieves all entities belonging to this repository.
     * 
     * @return List of entities
     * @throws DatabaseException if SQL query fails
     */
    List<T> findAll() throws DatabaseException;

    /**
     * Persists a new entity record into the database.
     * 
     * @param entity The entity to save
     * @return The saved entity with its generated primary key
     * @throws DatabaseException if SQL insert fails
     */
    T save(T entity) throws DatabaseException;

    /**
     * Updates an existing entity record in the database.
     * 
     * @param entity The entity containing updated values
     * @return true if updated successfully, false if not found
     * @throws DatabaseException if SQL update fails
     */
    boolean update(T entity) throws DatabaseException;

    /**
     * Deletes an entity record by its unique primary key.
     * 
     * @param id The entity ID to delete
     * @return true if deleted, false if not found
     * @throws DatabaseException if SQL delete fails
     */
    boolean deleteById(int id) throws DatabaseException;
}
