// File: src/main/java/com/qpanalyser/dao/QuestionDAO.java
package com.qpanalyser.dao;

import com.qpanalyser.db.DatabaseConnection;
import com.qpanalyser.exception.DatabaseException;
import com.qpanalyser.model.*;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * OOP Concept: DAO Pattern & Polymorphic Entity Mapping
 * Author: DSA & Database Lead
 * 
 * Manages database persistence for polymorphic Question subclasses.
 * Uses PreparedStatement, transaction handling, and QuestionFactory.
 */
public class QuestionDAO implements Repository<Question> {

    @Override
    public Optional<Question> findById(int id) throws DatabaseException {
        String sql = "SELECT id, paper_id, question_number, question_text, question_type, " +
                     "marks, sub_part_count, bloom_level, difficulty_level, difficulty_score, " +
                     "section, created_at FROM questions WHERE id = ?";
        Connection conn = DatabaseConnection.getInstance().getConnection();

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(mapResultSetToQuestion(rs));
                }
            }
        } catch (SQLException e) {
            throw new DatabaseException("Failed to find question by ID [" + id + "]: " + e.getMessage(), e);
        }
        return Optional.empty();
    }

    @Override
    public List<Question> findAll() throws DatabaseException {
        String sql = "SELECT id, paper_id, question_number, question_text, question_type, " +
                     "marks, sub_part_count, bloom_level, difficulty_level, difficulty_score, " +
                     "section, created_at FROM questions ORDER BY paper_id ASC, id ASC";
        Connection conn = DatabaseConnection.getInstance().getConnection();
        List<Question> questions = new ArrayList<>();

        try (PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            while (rs.next()) {
                questions.add(mapResultSetToQuestion(rs));
            }
        } catch (SQLException e) {
            throw new DatabaseException("Failed to retrieve all questions: " + e.getMessage(), e);
        }
        return questions;
    }

    public List<Question> findByPaperId(int paperId) throws DatabaseException {
        String sql = "SELECT id, paper_id, question_number, question_text, question_type, " +
                     "marks, sub_part_count, bloom_level, difficulty_level, difficulty_score, " +
                     "section, created_at FROM questions WHERE paper_id = ? ORDER BY id ASC";
        Connection conn = DatabaseConnection.getInstance().getConnection();
        List<Question> questions = new ArrayList<>();

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, paperId);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    questions.add(mapResultSetToQuestion(rs));
                }
            }
        } catch (SQLException e) {
            throw new DatabaseException("Failed to retrieve questions for paper [" + paperId + "]: " + e.getMessage(), e);
        }
        return questions;
    }

    @Override
    public Question save(Question question) throws DatabaseException {
        String sql = "INSERT INTO questions (paper_id, question_number, question_text, question_type, " +
                     "marks, sub_part_count, bloom_level, difficulty_level, difficulty_score, section) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        Connection conn = DatabaseConnection.getInstance().getConnection();

        try (PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            setStatementParameters(pstmt, question);
            pstmt.executeUpdate();

            try (ResultSet keys = pstmt.getGeneratedKeys()) {
                if (keys.next()) {
                    question.setId(keys.getInt(1));
                }
            }
            return question;
        } catch (SQLException e) {
            throw new DatabaseException("Failed to save question [" + question.getQuestionNumber() + "]: " + e.getMessage(), e);
        }
    }

    /**
     * Batch inserts an entire list of questions inside a single transaction.
     * Big-O: O(N) database round-trip optimization.
     */
    public void saveAll(List<Question> questions, int paperId) throws DatabaseException {
        if (questions == null || questions.isEmpty()) {
            return;
        }
        String sql = "INSERT INTO questions (paper_id, question_number, question_text, question_type, " +
                     "marks, sub_part_count, bloom_level, difficulty_level, difficulty_score, section) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        Connection conn = DatabaseConnection.getInstance().getConnection();

        try {
            boolean originalAutoCommit = conn.getAutoCommit();
            conn.setAutoCommit(false); // OOP / DB Concept: Atomic Transaction

            try (PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
                for (Question q : questions) {
                    q.setPaperId(paperId);
                    setStatementParameters(pstmt, q);
                    pstmt.addBatch();
                }
                pstmt.executeBatch();
                conn.commit();
            } catch (SQLException e) {
                conn.rollback();
                throw new DatabaseException("Transaction rolled back. Failed batch insert for questions: " + e.getMessage(), e);
            } finally {
                conn.setAutoCommit(originalAutoCommit);
            }
        } catch (SQLException e) {
            throw new DatabaseException("Failed to manage transaction for question batch: " + e.getMessage(), e);
        }
    }

    @Override
    public boolean update(Question question) throws DatabaseException {
        String sql = "UPDATE questions SET question_number = ?, question_text = ?, question_type = ?, " +
                     "marks = ?, sub_part_count = ?, bloom_level = ?, difficulty_level = ?, " +
                     "difficulty_score = ?, section = ? WHERE id = ?";
        Connection conn = DatabaseConnection.getInstance().getConnection();

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, question.getQuestionNumber());
            pstmt.setString(2, question.getQuestionText());
            pstmt.setString(3, question.getQuestionType().name());
            pstmt.setDouble(4, question.getMarks());
            pstmt.setInt(5, question.getSubPartCount());
            pstmt.setString(6, question.getBloomLevel().name());
            pstmt.setString(7, question.getDifficultyLevel().name());
            pstmt.setDouble(8, question.getDifficultyScore());
            pstmt.setString(9, question.getSection());
            pstmt.setInt(10, question.getId());

            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new DatabaseException("Failed to update question ID [" + question.getId() + "]: " + e.getMessage(), e);
        }
    }

    @Override
    public boolean deleteById(int id) throws DatabaseException {
        String sql = "DELETE FROM questions WHERE id = ?";
        Connection conn = DatabaseConnection.getInstance().getConnection();

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new DatabaseException("Failed to delete question ID [" + id + "]: " + e.getMessage(), e);
        }
    }

    private void setStatementParameters(PreparedStatement pstmt, Question q) throws SQLException {
        pstmt.setInt(1, q.getPaperId());
        pstmt.setString(2, q.getQuestionNumber());
        pstmt.setString(3, q.getQuestionText());
        pstmt.setString(4, q.getQuestionType().name());
        pstmt.setDouble(5, q.getMarks());
        pstmt.setInt(6, q.getSubPartCount());
        pstmt.setString(7, q.getBloomLevel().name());
        pstmt.setString(8, q.getDifficultyLevel().name());
        pstmt.setDouble(9, q.getDifficultyScore());
        pstmt.setString(10, q.getSection());
    }

    private Question mapResultSetToQuestion(ResultSet rs) throws SQLException {
        int id = rs.getInt("id");
        int paperId = rs.getInt("paper_id");
        String qNum = rs.getString("question_number");
        String text = rs.getString("question_text");
        QuestionType type = QuestionType.fromString(rs.getString("question_type"));
        double marks = rs.getDouble("marks");
        int subParts = rs.getInt("sub_part_count");
        BloomLevel bloom = BloomLevel.fromString(rs.getString("bloom_level"));
        DifficultyLevel diff = DifficultyLevel.fromString(rs.getString("difficulty_level"));
        double score = rs.getDouble("difficulty_score");
        String section = rs.getString("section");
        Timestamp ts = rs.getTimestamp("created_at");

        return QuestionFactory.createQuestion(
                id, paperId, qNum, text, type, marks, subParts, bloom, diff, score, section,
                ts != null ? ts.toLocalDateTime() : null
        );
    }
}
