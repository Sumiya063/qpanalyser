// File: src/main/java/com/qpanalyser/dao/BloomVerbDAO.java
package com.qpanalyser.dao;

import com.qpanalyser.db.DatabaseConnection;
import com.qpanalyser.exception.DatabaseException;
import com.qpanalyser.model.BloomLevel;
import com.qpanalyser.model.BloomVerb;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * OOP Concept: DAO Pattern & Interface Implementation
 * Author: DSA & Database Lead
 * 
 * Manages Bloom's taxonomy action verbs in MySQL.
 */
public class BloomVerbDAO implements Repository<BloomVerb> {

    @Override
    public Optional<BloomVerb> findById(int id) throws DatabaseException {
        String sql = "SELECT id, verb, bloom_level, weight FROM bloom_verbs WHERE id = ?";
        Connection conn = DatabaseConnection.getInstance().getConnection();

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(mapResultSet(rs));
                }
            }
        } catch (SQLException e) {
            throw new DatabaseException("Failed to find Bloom verb by ID [" + id + "]: " + e.getMessage(), e);
        }
        return Optional.empty();
    }

    @Override
    public List<BloomVerb> findAll() throws DatabaseException {
        String sql = "SELECT id, verb, bloom_level, weight FROM bloom_verbs ORDER BY bloom_level ASC, verb ASC";
        Connection conn = DatabaseConnection.getInstance().getConnection();
        List<BloomVerb> verbs = new ArrayList<>();

        try (PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            while (rs.next()) {
                verbs.add(mapResultSet(rs));
            }
        } catch (SQLException e) {
            throw new DatabaseException("Failed to load Bloom verbs: " + e.getMessage(), e);
        }
        return verbs;
    }

    @Override
    public BloomVerb save(BloomVerb verb) throws DatabaseException {
        String sql = "INSERT INTO bloom_verbs (verb, bloom_level, weight) VALUES (?, ?, ?)";
        Connection conn = DatabaseConnection.getInstance().getConnection();

        try (PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            pstmt.setString(1, verb.getVerb().toLowerCase().trim());
            pstmt.setString(2, verb.getBloomLevel().name());
            pstmt.setDouble(3, verb.getWeight());
            pstmt.executeUpdate();

            try (ResultSet keys = pstmt.getGeneratedKeys()) {
                if (keys.next()) {
                    verb.setId(keys.getInt(1));
                }
            }
            return verb;
        } catch (SQLException e) {
            throw new DatabaseException("Failed to save Bloom verb [" + verb.getVerb() + "]: " + e.getMessage(), e);
        }
    }

    @Override
    public boolean update(BloomVerb verb) throws DatabaseException {
        String sql = "UPDATE bloom_verbs SET bloom_level = ?, weight = ? WHERE id = ?";
        Connection conn = DatabaseConnection.getInstance().getConnection();

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, verb.getBloomLevel().name());
            pstmt.setDouble(2, verb.getWeight());
            pstmt.setInt(3, verb.getId());
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new DatabaseException("Failed to update Bloom verb [" + verb.getId() + "]: " + e.getMessage(), e);
        }
    }

    @Override
    public boolean deleteById(int id) throws DatabaseException {
        String sql = "DELETE FROM bloom_verbs WHERE id = ?";
        Connection conn = DatabaseConnection.getInstance().getConnection();

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new DatabaseException("Failed to delete Bloom verb [" + id + "]: " + e.getMessage(), e);
        }
    }

    /**
     * Loads all verbs as a HashMap for O(1) in-memory lookup.
     */
    public Map<String, BloomVerb> loadVerbMap() throws DatabaseException {
        List<BloomVerb> list = findAll();
        Map<String, BloomVerb> map = new HashMap<>();
        for (BloomVerb verb : list) {
            map.put(verb.getVerb().toLowerCase(), verb);
        }
        return map;
    }

    private BloomVerb mapResultSet(ResultSet rs) throws SQLException {
        return new BloomVerb(
                rs.getInt("id"),
                rs.getString("verb"),
                BloomLevel.fromString(rs.getString("bloom_level")),
                rs.getDouble("weight")
        );
    }
}
