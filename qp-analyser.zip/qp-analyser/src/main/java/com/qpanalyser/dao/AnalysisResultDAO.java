// File: src/main/java/com/qpanalyser/dao/AnalysisResultDAO.java
package com.qpanalyser.dao;

import com.qpanalyser.db.DatabaseConnection;
import com.qpanalyser.exception.DatabaseException;
import com.qpanalyser.model.AnalysisResult;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * OOP Concept: DAO Pattern & Interface Implementation
 * Author: DSA & Database Lead
 * 
 * Manages persistence for AnalysisResult records in MySQL.
 */
public class AnalysisResultDAO implements Repository<AnalysisResult> {

    @Override
    public Optional<AnalysisResult> findById(int id) throws DatabaseException {
        String sql = "SELECT id, paper_id, overall_difficulty_index, easy_percentage, medium_percentage, " +
                     "hard_percentage, remember_count, understand_count, apply_count, analyze_count, " +
                     "evaluate_count, create_count, balance_verdict, suggestions, generated_at " +
                     "FROM analysis_results WHERE id = ?";
        Connection conn = DatabaseConnection.getInstance().getConnection();

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(mapResultSet(rs));
                }
            }
        } catch (SQLException e) {
            throw new DatabaseException("Failed to find analysis result by ID [" + id + "]: " + e.getMessage(), e);
        }
        return Optional.empty();
    }

    public Optional<AnalysisResult> findByPaperId(int paperId) throws DatabaseException {
        String sql = "SELECT id, paper_id, overall_difficulty_index, easy_percentage, medium_percentage, " +
                     "hard_percentage, remember_count, understand_count, apply_count, analyze_count, " +
                     "evaluate_count, create_count, balance_verdict, suggestions, generated_at " +
                     "FROM analysis_results WHERE paper_id = ?";
        Connection conn = DatabaseConnection.getInstance().getConnection();

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, paperId);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(mapResultSet(rs));
                }
            }
        } catch (SQLException e) {
            throw new DatabaseException("Failed to find analysis result for paper [" + paperId + "]: " + e.getMessage(), e);
        }
        return Optional.empty();
    }

    @Override
    public List<AnalysisResult> findAll() throws DatabaseException {
        String sql = "SELECT id, paper_id, overall_difficulty_index, easy_percentage, medium_percentage, " +
                     "hard_percentage, remember_count, understand_count, apply_count, analyze_count, " +
                     "evaluate_count, create_count, balance_verdict, suggestions, generated_at " +
                     "FROM analysis_results ORDER BY generated_at DESC";
        Connection conn = DatabaseConnection.getInstance().getConnection();
        List<AnalysisResult> results = new ArrayList<>();

        try (PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            while (rs.next()) {
                results.add(mapResultSet(rs));
            }
        } catch (SQLException e) {
            throw new DatabaseException("Failed to retrieve analysis results: " + e.getMessage(), e);
        }
        return results;
    }

    @Override
    public AnalysisResult save(AnalysisResult result) throws DatabaseException {
        String sql = "INSERT INTO analysis_results (paper_id, overall_difficulty_index, easy_percentage, " +
                     "medium_percentage, hard_percentage, remember_count, understand_count, apply_count, " +
                     "analyze_count, evaluate_count, create_count, balance_verdict, suggestions) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) " +
                     "ON DUPLICATE KEY UPDATE overall_difficulty_index = VALUES(overall_difficulty_index), " +
                     "easy_percentage = VALUES(easy_percentage), medium_percentage = VALUES(medium_percentage), " +
                     "hard_percentage = VALUES(hard_percentage), remember_count = VALUES(remember_count), " +
                     "understand_count = VALUES(understand_count), apply_count = VALUES(apply_count), " +
                     "analyze_count = VALUES(analyze_count), evaluate_count = VALUES(evaluate_count), " +
                     "create_count = VALUES(create_count), balance_verdict = VALUES(balance_verdict), " +
                     "suggestions = VALUES(suggestions)";
        Connection conn = DatabaseConnection.getInstance().getConnection();

        try (PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            pstmt.setInt(1, result.getPaperId());
            pstmt.setDouble(2, result.getOverallDifficultyIndex());
            pstmt.setDouble(3, result.getEasyPercentage());
            pstmt.setDouble(4, result.getMediumPercentage());
            pstmt.setDouble(5, result.getHardPercentage());
            pstmt.setInt(6, result.getRememberCount());
            pstmt.setInt(7, result.getUnderstandCount());
            pstmt.setInt(8, result.getApplyCount());
            pstmt.setInt(9, result.getAnalyzeCount());
            pstmt.setInt(10, result.getEvaluateCount());
            pstmt.setInt(11, result.getCreateCount());
            pstmt.setString(12, result.getBalanceVerdict());
            pstmt.setString(13, result.getSuggestions());

            pstmt.executeUpdate();
            try (ResultSet keys = pstmt.getGeneratedKeys()) {
                if (keys.next()) {
                    result.setId(keys.getInt(1));
                }
            }
            return result;
        } catch (SQLException e) {
            throw new DatabaseException("Failed to save analysis result for paper [" + result.getPaperId() + "]: " + e.getMessage(), e);
        }
    }

    @Override
    public boolean update(AnalysisResult result) throws DatabaseException {
        save(result);
        return true;
    }

    @Override
    public boolean deleteById(int id) throws DatabaseException {
        String sql = "DELETE FROM analysis_results WHERE id = ?";
        Connection conn = DatabaseConnection.getInstance().getConnection();

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new DatabaseException("Failed to delete analysis result ID [" + id + "]: " + e.getMessage(), e);
        }
    }

    private AnalysisResult mapResultSet(ResultSet rs) throws SQLException {
        AnalysisResult res = new AnalysisResult();
        res.setId(rs.getInt("id"));
        res.setPaperId(rs.getInt("paper_id"));
        res.setOverallDifficultyIndex(rs.getDouble("overall_difficulty_index"));
        res.setEasyPercentage(rs.getDouble("easy_percentage"));
        res.setMediumPercentage(rs.getDouble("medium_percentage"));
        res.setHardPercentage(rs.getDouble("hard_percentage"));
        res.setRememberCount(rs.getInt("remember_count"));
        res.setUnderstandCount(rs.getInt("understand_count"));
        res.setApplyCount(rs.getInt("apply_count"));
        res.setAnalyzeCount(rs.getInt("analyze_count"));
        res.setEvaluateCount(rs.getInt("evaluate_count"));
        res.setCreateCount(rs.getInt("create_count"));
        res.setBalanceVerdict(rs.getString("balance_verdict"));
        res.setSuggestions(rs.getString("suggestions"));

        Timestamp ts = rs.getTimestamp("generated_at");
        if (ts != null) {
            res.setGeneratedAt(ts.toLocalDateTime());
        }
        return res;
    }
}
