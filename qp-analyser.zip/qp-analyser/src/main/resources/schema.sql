-- ==============================================================================
-- File: src/main/resources/schema.sql
-- Project: AI Question Paper Difficulty Analyzer (CSE203)
-- Team Role: DSA & Database Lead
-- ==============================================================================
--
-- PLANTUML ENTITY-RELATIONSHIP (ER) DIAGRAM
--
-- @startuml
-- entity "users" as users {
--   * id : INT <<PK, AI>>
--   --
--   * username : VARCHAR(50) <<UNIQUE>>
--   * password_hash : VARCHAR(255)
--   * salt : VARCHAR(64)
--   * full_name : VARCHAR(100)
--   * email : VARCHAR(100) <<UNIQUE>>
--   * role : ENUM('TEACHER', 'ADMIN')
--   * created_at : TIMESTAMP
-- }
--
-- entity "papers" as papers {
--   * id : INT <<PK, AI>>
--   --
--   * title : VARCHAR(255)
--   * subject_code : VARCHAR(50)
--   * academic_year : VARCHAR(20)
--   * semester : VARCHAR(20)
--   * total_marks : DOUBLE
--   * target_easy : DOUBLE
--   * target_medium : DOUBLE
--   * target_hard : DOUBLE
--   * created_by : INT <<FK>>
--   * created_at : TIMESTAMP
-- }
--
-- entity "questions" as questions {
--   * id : INT <<PK, AI>>
--   --
--   * paper_id : INT <<FK>>
--   * question_number : VARCHAR(20)
--   * question_text : TEXT
--   * question_type : VARCHAR(50)
--   * marks : DOUBLE
--   * sub_part_count : INT
--   * bloom_level : VARCHAR(50)
--   * difficulty_level : VARCHAR(50)
--   * difficulty_score : DOUBLE
--   * section : VARCHAR(50)
--   * created_at : TIMESTAMP
-- }
--
-- entity "analysis_results" as analysis {
--   * id : INT <<PK, AI>>
--   --
--   * paper_id : INT <<FK>>
--   * overall_difficulty_index : DOUBLE
--   * easy_percentage : DOUBLE
--   * medium_percentage : DOUBLE
--   * hard_percentage : DOUBLE
--   * remember_count : INT
--   * understand_count : INT
--   * apply_count : INT
--   * analyze_count : INT
--   * evaluate_count : INT
--   * create_count : INT
--   * balance_verdict : VARCHAR(100)
--   * suggestions : TEXT
--   * generated_at : TIMESTAMP
-- }
--
-- entity "bloom_verbs" as verbs {
--   * id : INT <<PK, AI>>
--   --
--   * verb : VARCHAR(50) <<UNIQUE>>
--   * bloom_level : ENUM(...)
--   * weight : DOUBLE
-- }
--
-- entity "settings" as settings {
--   * id : INT <<PK, AI>>
--   --
--   * setting_key : VARCHAR(100) <<UNIQUE>>
--   * setting_value : VARCHAR(255)
--   * description : VARCHAR(255)
-- }
--
-- users ||--o{ papers : "creates"
-- papers ||--|{ questions : "contains"
-- papers ||--o| analysis : "evaluated by"
-- @enduml
--
-- TEXT-BASED ASCII ER DIAGRAM:
-- +---------------+       1 : N       +---------------+       1 : N       +---------------+
-- |     users     | ----------------> |    papers     | ----------------> |   questions   |
-- +---------------+                   +---------------+                   +---------------+
-- | id (PK)       |                   | id (PK)       |                   | id (PK)       |
-- | username (UQ) |                   | created_by(FK)|                   | paper_id (FK) |
-- | password_hash |                   | title         |                   | q_text        |
-- | role          |                   | total_marks   |                   | bloom_level   |
-- +---------------+                   +---------------+                   | diff_score    |
--                                             |                           +---------------+
--                                             | 1 : 1
--                                             v
--                                     +--------------------+
--                                     |  analysis_results  |
--                                     +--------------------+
--                                     | id (PK)            |
--                                     | paper_id (FK)      |
--                                     | balance_verdict    |
--                                     | suggestions        |
--                                     +--------------------+
--
-- Independent lookup & configuration tables:
-- +---------------+                   +---------------+
-- |  bloom_verbs  |                   |   settings    |
-- +---------------+                   +---------------+
-- | verb (UQ)     |                   | key (UQ)      |
-- | bloom_level   |                   | value         |
-- | weight        |                   | description   |
-- +---------------+                   +---------------+
-- ==============================================================================

-- 1. USERS TABLE
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    salt VARCHAR(64) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    role ENUM('TEACHER', 'ADMIN') NOT NULL DEFAULT 'TEACHER',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user_username (username),
    INDEX idx_user_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. PAPERS TABLE
CREATE TABLE IF NOT EXISTS papers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    subject_code VARCHAR(50) NOT NULL,
    academic_year VARCHAR(20) NOT NULL,
    semester VARCHAR(20) NOT NULL,
    total_marks DOUBLE NOT NULL DEFAULT 100.0,
    target_easy DOUBLE NOT NULL DEFAULT 30.0,
    target_medium DOUBLE NOT NULL DEFAULT 50.0,
    target_hard DOUBLE NOT NULL DEFAULT 20.0,
    created_by INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_papers_subject (subject_code),
    INDEX idx_papers_user (created_by),
    CONSTRAINT fk_papers_users FOREIGN KEY (created_by) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. QUESTIONS TABLE
CREATE TABLE IF NOT EXISTS questions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    paper_id INT NOT NULL,
    question_number VARCHAR(20) NOT NULL,
    question_text TEXT NOT NULL,
    question_type VARCHAR(50) NOT NULL DEFAULT 'SHORT_ANSWER',
    marks DOUBLE NOT NULL DEFAULT 5.0,
    sub_part_count INT NOT NULL DEFAULT 1,
    bloom_level VARCHAR(50) NOT NULL DEFAULT 'REMEMBER',
    difficulty_level VARCHAR(50) NOT NULL DEFAULT 'EASY',
    difficulty_score DOUBLE NOT NULL DEFAULT 0.0,
    section VARCHAR(50) DEFAULT 'Section A',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_questions_paper (paper_id),
    INDEX idx_questions_bloom (bloom_level),
    INDEX idx_questions_diff (difficulty_level),
    CONSTRAINT fk_questions_papers FOREIGN KEY (paper_id) REFERENCES papers (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. ANALYSIS RESULTS TABLE
CREATE TABLE IF NOT EXISTS analysis_results (
    id INT AUTO_INCREMENT PRIMARY KEY,
    paper_id INT NOT NULL UNIQUE,
    overall_difficulty_index DOUBLE NOT NULL,
    easy_percentage DOUBLE NOT NULL,
    medium_percentage DOUBLE NOT NULL,
    hard_percentage DOUBLE NOT NULL,
    remember_count INT DEFAULT 0,
    understand_count INT DEFAULT 0,
    apply_count INT DEFAULT 0,
    analyze_count INT DEFAULT 0,
    evaluate_count INT DEFAULT 0,
    create_count INT DEFAULT 0,
    balance_verdict VARCHAR(100) NOT NULL,
    suggestions TEXT,
    generated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_analysis_paper (paper_id),
    CONSTRAINT fk_analysis_papers FOREIGN KEY (paper_id) REFERENCES papers (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 5. BLOOM VERBS DICTIONARY TABLE
CREATE TABLE IF NOT EXISTS bloom_verbs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    verb VARCHAR(50) NOT NULL UNIQUE,
    bloom_level ENUM('REMEMBER', 'UNDERSTAND', 'APPLY', 'ANALYZE', 'EVALUATE', 'CREATE') NOT NULL,
    weight DOUBLE NOT NULL DEFAULT 1.0,
    INDEX idx_verbs_verb (verb),
    INDEX idx_verbs_level (bloom_level)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 6. SYSTEM SETTINGS TABLE
CREATE TABLE IF NOT EXISTS settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    setting_key VARCHAR(100) NOT NULL UNIQUE,
    setting_value VARCHAR(255) NOT NULL,
    description VARCHAR(255),
    INDEX idx_settings_key (setting_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==============================================================================
-- SEED DATA: BLOOM'S TAXONOMY ACTION VERBS
-- ==============================================================================
INSERT IGNORE INTO bloom_verbs (verb, bloom_level, weight) VALUES
-- Remember (Level 1, weight 1.0)
('define', 'REMEMBER', 1.0),
('list', 'REMEMBER', 1.0),
('state', 'REMEMBER', 1.0),
('recall', 'REMEMBER', 1.0),
('name', 'REMEMBER', 1.0),
('identify', 'REMEMBER', 1.0),
('match', 'REMEMBER', 1.0),
('recognize', 'REMEMBER', 1.0),
('record', 'REMEMBER', 1.0),
('repeat', 'REMEMBER', 1.0),
('label', 'REMEMBER', 1.0),
('retrieve', 'REMEMBER', 1.0),
('tabulate', 'REMEMBER', 1.0),
('quote', 'REMEMBER', 1.0),

-- Understand (Level 2, weight 2.0)
('explain', 'UNDERSTAND', 2.0),
('describe', 'UNDERSTAND', 2.0),
('summarize', 'UNDERSTAND', 2.0),
('interpret', 'UNDERSTAND', 2.0),
('classify', 'UNDERSTAND', 2.0),
('discuss', 'UNDERSTAND', 2.0),
('distinguish', 'UNDERSTAND', 2.0),
('illustrate', 'UNDERSTAND', 2.0),
('predict', 'UNDERSTAND', 2.0),
('translate', 'UNDERSTAND', 2.0),
('paraphrase', 'UNDERSTAND', 2.0),
('exemplify', 'UNDERSTAND', 2.0),
('clarify', 'UNDERSTAND', 2.0),

-- Apply (Level 3, weight 3.0)
('apply', 'APPLY', 3.0),
('calculate', 'APPLY', 3.0),
('solve', 'APPLY', 3.0),
('compute', 'APPLY', 3.0),
('demonstrate', 'APPLY', 3.0),
('construct', 'APPLY', 3.0),
('implement', 'APPLY', 3.0),
('execute', 'APPLY', 3.0),
('use', 'APPLY', 3.0),
('operate', 'APPLY', 3.0),
('modify', 'APPLY', 3.0),
('practice', 'APPLY', 3.0),
('derive', 'APPLY', 3.0),
('simulate', 'APPLY', 3.0),

-- Analyze (Level 4, weight 4.0)
('analyze', 'ANALYZE', 4.0),
('compare', 'ANALYZE', 4.0),
('contrast', 'ANALYZE', 4.0),
('differentiate', 'ANALYZE', 4.0),
('examine', 'ANALYZE', 4.0),
('categorize', 'ANALYZE', 4.0),
('correlate', 'ANALYZE', 4.0),
('deduce', 'ANALYZE', 4.0),
('inspect', 'ANALYZE', 4.0),
('investigate', 'ANALYZE', 4.0),
('dissect', 'ANALYZE', 4.0),
('deconstruct', 'ANALYZE', 4.0),

-- Evaluate (Level 5, weight 5.0)
('evaluate', 'EVALUATE', 5.0),
('assess', 'EVALUATE', 5.0),
('justify', 'EVALUATE', 5.0),
('critique', 'EVALUATE', 5.0),
('defend', 'EVALUATE', 5.0),
('judge', 'EVALUATE', 5.0),
('rate', 'EVALUATE', 5.0),
('verify', 'EVALUATE', 5.0),
('estimate', 'EVALUATE', 5.0),
('prioritize', 'EVALUATE', 5.0),
('validate', 'EVALUATE', 5.0),
('appraise', 'EVALUATE', 5.0),

-- Create (Level 6, weight 6.0)
('create', 'CREATE', 6.0),
('design', 'CREATE', 6.0),
('develop', 'CREATE', 6.0),
('formulate', 'CREATE', 6.0),
('invent', 'CREATE', 6.0),
('compose', 'CREATE', 6.0),
('plan', 'CREATE', 6.0),
('generate', 'CREATE', 6.0),
('hypothesize', 'CREATE', 6.0),
('synthesize', 'CREATE', 6.0),
('devise', 'CREATE', 6.0),
('propose', 'CREATE', 6.0);

-- ==============================================================================
-- SEED DATA: DEFAULT CALCULATION WEIGHTS & TARGET RATIOS
-- ==============================================================================
INSERT IGNORE INTO settings (setting_key, setting_value, description) VALUES
('weight.bloom', '0.35', 'Weight factor for Bloom cognitive taxonomy level (0.0 to 1.0)'),
('weight.length', '0.20', 'Weight factor for text word count and avg length (0.0 to 1.0)'),
('weight.subparts', '0.15', 'Weight factor for number of sub-questions (0.0 to 1.0)'),
('weight.marks', '0.15', 'Weight factor for allocated marks (0.0 to 1.0)'),
('weight.complexity', '0.15', 'Weight factor for technical term density & formulas (0.0 to 1.0)'),
('target.easy', '30.0', 'Target percentage of easy questions in paper'),
('target.medium', '50.0', 'Target percentage of medium questions in paper'),
('target.hard', '20.0', 'Target percentage of hard questions in paper'),
('threshold.easy_max', '35.0', 'Maximum difficulty score cutoff for Easy questions'),
('threshold.medium_max', '65.0', 'Maximum difficulty score cutoff for Medium questions');
