# AI Question Paper Difficulty Analyzer
**Course:** CSE203: Object-Oriented Programming using Java  
**Architecture:** Desktop Application (JavaFX + Core Java + JDBC + MySQL)  
**Tools:** Java 21, Maven, IntelliJ IDEA, Git

---

## 1. Project Overview
The **AI Question Paper Difficulty Analyzer** is a comprehensive academic application built strictly using pure Java (without Python, web frameworks, or Spring). It enables teachers and examination controllers to:
1. Ingest question papers from diverse document formats (**TXT**, **PDF** via Apache PDFBox, and **DOCX** via Apache POI).
2. Automatically parse and extract question text, numbering hierarchies, section splits, mark allocations, and sub-part structures using an NLP regular expression engine.
3. Review and curate questions with an interactive **Review Studio** supporting in-place editing, question splitting/merging, and an unlimited **Undo/Redo** facility backed by a hand-written linked LIFO Stack.
4. Perform rule-based cognitive profiling using **Bloom's Revised Taxonomy** via a hand-written **Prefix Trie** ($O(M)$ lookup).
5. Compute a normalized multi-factor **Difficulty Score** (0–100) combining cognitive depth, sentence length, sub-part scaffolding, mark allocation, and technical keyword density.
6. Rank and filter questions using hand-written **Merge Sort** ($O(N \log N)$), **Binary Search** ($O(\log N)$), and a **PriorityQueue Min-Heap** ($O(K \log N)$).
7. Flag near-duplicate questions using Dynamic Programming (**Levenshtein Distance** $O(MN)$ and **Jaccard Similarity**).
8. Visualize analytical distributions with interactive JavaFX `PieChart` and `BarChart` components, and export dossiers to **CSV**, **Plain Text**, and **PDF**.

---

## 2. Prerequisites & Setup

### Environment Requirements
- **Operating System:** Windows, macOS, or Linux
- **JDK:** OpenJDK 21 or Oracle JDK 21 (configured as `JAVA_HOME`)
- **Build Tool:** Apache Maven 3.8+
- **Database:** MySQL Server 8.0+

### Database Configuration
1. Start your local MySQL instance.
2. Verify or create the database schema:
   ```sql
   CREATE DATABASE IF NOT EXISTS qpanalyser;
   ```
3. Update connection credentials in [`src/main/resources/db.properties`](file:///c:/Projects/qp-analyser/src/main/resources/db.properties):
   ```properties
   db.url=jdbc:mysql://localhost:3306/qpanalyser?createDatabaseIfNotExist=true&useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC
   db.user=root
   db.password=root
   db.poolSize=5
   ```
4. *Note:* Upon initial launch, [`DatabaseInitializer.java`](file:///c:/Projects/qp-analyser/src/main/java/com/qpanalyser/db/DatabaseInitializer.java) will automatically create all tables, indexes, and seed default user accounts (`admin/admin123`, `teacher/teacher123`) as well as the 36+ Bloom taxonomy action verbs.

---

## 3. How to Build & Run

### A. Command Line (Maven)
```powershell
# 1. Clean and run all 66 test suites
mvn clean test

# 2. Package the standalone JAR
mvn package -DskipTests

# 3. Launch the JavaFX Application
mvn javafx:run
```

### B. Running in IntelliJ IDEA
1. Open the project folder (`qp-analyser`) in IntelliJ IDEA (`File -> Open...`).
2. Ensure the Project SDK is configured to **Java 21** (`Project Structure -> Project -> SDK`).
3. Set VM Options if running via an Application run configuration:
   ```text
   --module-path ${PATH_TO_FX} --add-modules javafx.controls,javafx.fxml
   ```
4. Execute [`com.qpanalyser.app.MainApp`](file:///c:/Projects/qp-analyser/src/main/java/com/qpanalyser/app/MainApp.java).

---

## 4. Default Credentials

| Username | Password | Role | Description |
|---|---|---|---|
| `teacher` | `teacher123` | **TEACHER** | Standard faculty access: Load paper, review, AI analyze, export reports |
| `admin` | `admin123` | **ADMIN** | Administrative privileges: Modify weights, manage Bloom verbs, compare papers |

---

## 5. Object-Oriented Programming (OOP) Showcase

- **Encapsulation:** Private fields, immutable properties where appropriate, standard accessor patterns across entities ([`User`](file:///c:/Projects/qp-analyser/src/main/java/com/qpanalyser/model/User.java), [`Paper`](file:///c:/Projects/qp-analyser/src/main/java/com/qpanalyser/model/Paper.java), [`Question`](file:///c:/Projects/qp-analyser/src/main/java/com/qpanalyser/model/Question.java)).
- **Inheritance & Polymorphism:** Abstract base class [`Question`](file:///c:/Projects/qp-analyser/src/main/java/com/qpanalyser/model/Question.java) extended by:
  - [`McqQuestion`](file:///c:/Projects/qp-analyser/src/main/java/com/qpanalyser/model/McqQuestion.java)
  - [`ShortAnswerQuestion`](file:///c:/Projects/qp-analyser/src/main/java/com/qpanalyser/model/ShortAnswerQuestion.java)
  - [`LongAnswerQuestion`](file:///c:/Projects/qp-analyser/src/main/java/com/qpanalyser/model/LongAnswerQuestion.java)
  - [`ProblemQuestion`](file:///c:/Projects/qp-analyser/src/main/java/com/qpanalyser/model/ProblemQuestion.java)
- **Design Patterns:**
  - **Singleton Pattern:** [`DatabaseConnection`](file:///c:/Projects/qp-analyser/src/main/java/com/qpanalyser/db/DatabaseConnection.java) (thread-safe double-checked locking) and [`SessionManager`](file:///c:/Projects/qp-analyser/src/main/java/com/qpanalyser/service/SessionManager.java).
  - **Factory Pattern:** [`QuestionFactory`](file:///c:/Projects/qp-analyser/src/main/java/com/qpanalyser/model/QuestionFactory.java) and [`DocumentParserFactory`](file:///c:/Projects/qp-analyser/src/main/java/com/qpanalyser/service/parser/DocumentParserFactory.java).
  - **Strategy Pattern:** [`DocumentParser`](file:///c:/Projects/qp-analyser/src/main/java/com/qpanalyser/service/parser/DocumentParser.java), [`BloomClassifier`](file:///c:/Projects/qp-analyser/src/main/java/com/qpanalyser/analyzer/BloomClassifier.java), [`DifficultyScorer`](file:///c:/Projects/qp-analyser/src/main/java/com/qpanalyser/analyzer/DifficultyScorer.java), and [`ReportExporter`](file:///c:/Projects/qp-analyser/src/main/java/com/qpanalyser/report/ReportExporter.java).
  - **Command Pattern:** Command hierarchy ([`EditCommand`](file:///c:/Projects/qp-analyser/src/main/java/com/qpanalyser/service/undo/EditCommand.java), [`DeleteQuestionCommand`](file:///c:/Projects/qp-analyser/src/main/java/com/qpanalyser/service/undo/DeleteQuestionCommand.java), etc.) powering Undo/Redo.
  - **DAO Pattern:** [`Repository<T>`](file:///c:/Projects/qp-analyser/src/main/java/com/qpanalyser/dao/Repository.java) generic interface implemented by entity DAOs.
- **Generics & Collections:** Type-safe repositories, generic custom data structures, and functional Java Streams for aggregations and filtering.

---

## 6. Hand-Written Data Structures & Algorithms

All required algorithms are implemented directly in code without relying solely on `java.util`:
1. **[`UndoStack<T>`](file:///c:/Projects/qp-analyser/src/main/java/com/qpanalyser/dsa/UndoStack.java):** Hand-written singly-linked LIFO Stack with $O(1)$ push, pop, and peek, with bounded capacity management.
2. **[`BloomTrie`](file:///c:/Projects/qp-analyser/src/main/java/com/qpanalyser/dsa/BloomTrie.java):** Hand-written Prefix Tree for fast action-verb matching ($O(M)$ where $M$ is verb length) with longest-prefix and cognitive-level resolution.
3. **[`QuestionSort`](file:///c:/Projects/qp-analyser/src/main/java/com/qpanalyser/dsa/QuestionSort.java):** Hand-written **Merge Sort** ($O(N \log N)$) and **Binary Search** ($O(\log N)$) for threshold boundary lookups.
4. **[`DuplicateDetector`](file:///c:/Projects/qp-analyser/src/main/java/com/qpanalyser/dsa/DuplicateDetector.java):** Dynamic Programming **Levenshtein Distance** ($O(MN)$) and **Jaccard Similarity** for detecting near-duplicate questions.
5. **[`QuestionRanker`](file:///c:/Projects/qp-analyser/src/main/java/com/qpanalyser/dsa/QuestionRanker.java):** PriorityQueue Min-Heap for extracting Top-$K$ hardest questions in $O(N \log K)$ time.

---

## 7. Multi-Tier Architecture & Package Map
```
com.qpanalyser
├── app           -> MainApp, AppConfig
├── model         -> Question hierarchy, Paper, User, BloomLevel, DifficultyLevel
├── analyzer      -> BloomClassifier, DifficultyScorer, FeatureExtractor
├── dsa           -> BloomTrie, UndoStack, QuestionSort, DuplicateDetector, QuestionRanker
├── service       -> AuthService, PaperService, PaperAnalysisService, QuestionReviewService
│   ├── extractor -> QuestionExtractor, RegexQuestionExtractor
│   ├── parser    -> DocumentParser, PdfDocumentParser, DocxDocumentParser
│   └── undo      -> UndoManager, EditCommand hierarchy
├── dao           -> Repository, UserDAO, PaperDAO, QuestionDAO, BloomVerbDAO, SettingsDAO
├── db            -> DatabaseConnection, DatabaseInitializer
├── report        -> ReportExporter, CsvReportExporter, TextReportExporter, PdfReportExporter
├── exception     -> Custom exception classes
├── util          -> PasswordUtil, ValidationUtil
└── ui
    ├── controller-> LoginController, DashboardController, ReviewController, ResultsController, ...
    ├── util      -> SceneNavigator, AlertHelper
    └── view      -> FXML files and CSS stylesheets
```
