# Technical Documentation & System Design
**Project:** AI Question Paper Difficulty Analyzer  
**Course:** CSE203 Object-Oriented Programming using Java

---

## 1. Problem Statement
In tertiary academic assessment, educators frequently design question papers that disproportionately favor rote memorization (Bloom's *Remember* and *Understand* levels) while under-representing analytical problem-solving and critical evaluation. Existing tools lack localized rule-based cognitive profiling, paper-level difficulty balance auditing, and immediate pedagogical feedback.

This system provides a native Java desktop application to analyze question papers, quantify cognitive distribution, score difficulty using multi-factor heuristics, and recommend pedagogical adjustments.

---

## 2. Use-Case Diagram (PlantUML / Text Format)

```text
+--------------------------------------------------------------------------+
|                 AI Question Paper Difficulty Analyzer                    |
+--------------------------------------------------------------------------+
                                     |
               +---------------------+---------------------+
               |                                           |
         [ TEACHER ]                                   [ ADMIN ]
               |                                           |
               +--> (1. Authenticate / Login) <------------+
               |                                           |
               +--> (2. Load Document TXT/PDF/DOCX)        +--> (7. Manage Bloom Verbs)
               |                                           |
               +--> (3. Extract & Review Questions)        +--> (8. Configure Weights)
               |        ^                                  |
               |        |-- <<include>> (Undo / Redo)      +--> (9. Compare Papers)
               |                                           |
               +--> (4. Run AI Cognitive & Difficulty Engine)
               |                                           |
               +--> (5. View Visual Charts & Suggestions)  |
               |                                           |
               +--> (6. Export Report CSV / TXT / PDF) <---+
```

---

## 3. Entity-Relationship (ER) Diagram

```text
+------------------+         1 : N         +----------------------+
|      USERS       | --------------------> |        PAPERS        |
+------------------+                       +----------------------+
| PK id            |                       | PK id                |
|    username      |                       | FK created_by        |
|    password_hash |                       |    title             |
|    salt          |                       |    subject_code      |
|    role          |                       |    total_marks       |
+------------------+                       +----------------------+
                                                      |
                                                      | 1 : N
                                                      v
+------------------+         1 : 1         +----------------------+
| ANALYSIS_RESULTS | <-------------------- |      QUESTIONS       |
+------------------+                       +----------------------+
| PK id            |                       | PK id                |
| FK paper_id      |                       | FK paper_id          |
|    difficulty_idx|                       |    question_number   |
|    easy_pct      |                       |    question_text     |
|    med_pct       |                       |    marks             |
|    hard_pct      |                       |    bloom_level       |
|    verdict       |                       |    difficulty_score  |
+------------------+                       +----------------------+
```

---

## 4. Class Inheritance & Design Pattern Map

```text
                              <<abstract>>
                                Question
                                   ▲
         +-----------------+-------+-------+-----------------+
         |                 |               |                 |
    McqQuestion    ShortAnswerQuestion   LongAnswerQuestion   ProblemQuestion
 (Choice options)   (Direct recall)       (Sub-parts count)  (Algorithmic complexity)

[Design Patterns]
1. Singleton:       DatabaseConnection, SessionManager
2. Factory:         QuestionFactory, DocumentParserFactory
3. Strategy:        DocumentParser (Txt, Pdf, Docx)
                    BloomClassifier (TrieBloomClassifier, KeywordBloomClassifier)
                    DifficultyScorer (WeightedDifficultyScorer, LinearDifficultyScorer)
                    ReportExporter (CsvReportExporter, TextReportExporter, PdfReportExporter)
4. Command:         EditCommand -> AddQuestionCommand, DeleteQuestionCommand, ...
5. DAO Pattern:     Repository<T> -> UserDAO, PaperDAO, QuestionDAO, SettingsDAO, BloomVerbDAO
```

---

## 5. Data Flow Diagram (DFD - Level 1)

```text
[Teacher / Faculty]
       |
       |  (1. Uploads Paper: TXT / PDF / DOCX)
       v
[DocumentParserFactory] ---> [PlainTextParser / PdfParser / DocxParser]
       |
       |  (Normalized Text Stream)
       v
[RegexQuestionExtractor] ---> [Interactive Review Studio (TableView + UndoStack)]
       |
       |  (Validated Question Model List)
       v
[PaperAnalysisService]
       |
       +---> [BloomTrie] -------------> (Action Verb Match & Cognitive Level)
       +---> [FeatureExtractor] ------> (Length, Keywords, Formulae, Sub-parts)
       +---> [WeightedDifficultyScorer] (Computes 0-100 Difficulty Score)
       +---> [DuplicateDetector] -----> (DP Levenshtein Near-Duplicate Check)
       |
       v
[Aggregated AnalysisResult]
       |
       +---> [MySQL Database] (Persistent Storage via JDBC DAO)
       +---> [ResultsController] (PieChart, BarChart, Ranked MergeSort Table)
       +---> [ReportExporter] (CSV, TXT, PDF Dossier Generation)
```
